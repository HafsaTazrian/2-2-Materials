package test;

import java.util.List;
import jdbc.Person;
import jdbc.PersonDao;
import org.apache.logging.log4j.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Commit;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;
import service.PersonService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:datasource-test.xml", "classpath:applicationContext.xml"})
public class TestPersonService {

    private final Logger logger = LogManager.getRootLogger();

    @Autowired
    private PersonService personService;

    @Test
    @Transactional
    @Commit
    public void testTransactions() {
        try {
            System.out.println();
            logger.info("Start of test testTransactions");

            Person person1 = new Person();
            //person1.setName("Samatha1111111111111111111111111111111111111111111111111111");
            person1.setName("Samantha");
            person1.setEmail("samantha@mail.com");

            personService.addPerson(person1);
            
            logger.info("Person to add:" + person1);

            //We update the person with id = 1
            Person person2 = personService.findPerson(new Person(1));
            person2.setEmail("administrator@mail.com");
            personService.modifyPerson(person2);
            logger.info("Modify Person : " + person2);
            logger.info("List People:");
            this.displayPeople();
            logger.info("End of test testTransactions");
            System.out.println();
        } catch (Exception e) {
            logger.error("Error Service: ", e);
        }
    }

    private int displayPeople() {
        List<Person> persons = personService.listPeople();
        int counPeople = 0;
        for (Person person : persons) {
            logger.info("Person: " + person);
            counPeople++;
        }
        return counPeople;
    }
}
