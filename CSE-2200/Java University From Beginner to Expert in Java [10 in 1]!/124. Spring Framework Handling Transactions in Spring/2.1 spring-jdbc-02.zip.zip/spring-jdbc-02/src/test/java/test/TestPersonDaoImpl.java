package test;

import java.util.List;
import jdbc.Person;
import jdbc.PersonDao;
import org.apache.logging.log4j.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:datasource-test.xml",
    "classpath:applicationContext.xml"})
public class TestPersonDaoImpl {

    private final Logger logger = LogManager.getRootLogger();

    @Autowired
    private PersonDao personDao;

    @Test
    public void shouldShowPeople() {
        try {
            System.out.println();
            logger.info("Start of the test shouldShowPeople");

            List<Person> people = personDao.findAllPeople();

            int peopleCounter = 0;
            for (Person person : people) {
                logger.info("Person: " + person);
                peopleCounter++;
            }

            //According to the number of people recovered, it should be the same as the table
            assertEquals(peopleCounter, personDao.countPeople());

            logger.info("End of the test shouldShowPeople");
        } catch (Exception e) {
            logger.error("Error JBDC", e);
        }
    }

    @Test
    public void shouldFindPersonById() {
        try {
            System.out.println();
            logger.info("Start of test shouldFindPersonById");
            int idPerson = 1;
            Person person = personDao.findPersonById(idPerson);

            //According to the recovered person, it should be the same as the record 1
            assertEquals("Admin", person.getName());

            //Print the object
            logger.info("Person found (id=" + idPerson + "): " + person);
            logger.info("End of test shouldFindPersonById");
        } catch (Exception e) {
            logger.error("Error JBDC", e);
        }
    }

    @Test
    public void shouldInsertPerson() {
        try {
            System.out.println();
            logger.info("Start oftest shouldInsertPerson");
            // The data script has 3 records
            assertEquals(3, personDao.countPeople());
            Person person = new Person();
            person.setName("Katty");
            person.setEmail("katty@mail.com");
            personDao.insertPerson(person);

            //We retrieve the newly inserted person by email
            person = personDao.getPersonByEmail(person);
            logger.info("Newly inserted person (recovered by email): \n" + person);
            // There should already be four people
            assertEquals(4, personDao.countPeople());
            logger.info("End of test shouldInsertPerson");
        } catch (Exception e) {
            logger.error("Error JBDC", e);
        }
    }
    
    @Test
    public void shouldUpdatePerson() {
        try {
            System.out.println();
            logger.info("Start of test shouldUpdatePerson");
            int idPerson = 1;
            Person person = personDao.findPersonById(idPerson);
            logger.info("Person to modify (id=" + idPerson + "): \n" + person);
            //Update the email
            person.setEmail("admin@mail.com");
            personDao.updatePerson(person);
            //We read the user again
            person = personDao.findPersonById(idPerson);
            //According to the person recovered, it should be the same as the record 1
            assertEquals("admin@mail.com", person.getEmail());
            //We print the whole object
            logger.info("Modified person (id=" + idPerson + "): \n" + person);
            logger.info("End of test shouldUpdatePerson");
        } catch (Exception e) {
            logger.error("Error JBDC", e);
        }
    }
}
