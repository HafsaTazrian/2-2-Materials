insert into person (name, email) values ('Admin', 'admin@icursos.net');
insert into person (name, email) values ('Jhon', 'jsmith@mail.com');
insert into person (name, email) values ('Charly', 'ctyler@mail.com');