package jdbc;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

@Repository
public class PersonDaoImpl implements PersonDao {

    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setDataSource(DataSource dataSource) {
        //It is not common to use the 2 templates, however if possible. 
        //The difference is the handling of parameters by index or by name        
        this.jdbcTemplate = new JdbcTemplate(dataSource);
        this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
    }

    // Query with Parameters by name
    // We omit the PK since it is autoincrementable
    private static final String SQL_INSERT_PERSON = "INSERT INTO person (name, email) values (:name, :email)";

    private static final String SQL_UPDATE_PERSON = "UPDATE person set name = :name, email = :email WHERE id_person = :idPerson";

    private static final String SQL_DELETE_PERSON = "DELETE FROM person WHERE id_person = :idPerson";

    private static final String SQL_SELECT_PERSON = "SELECT id_person, name, email FROM person";

    // Parameters by index
    private static final String SQL_SELECT_PERSON_BY_ID = SQL_SELECT_PERSON + " WHERE id_person = ?";

    @Override
    public List<Person> findAllPeople() {
        RowMapper<Person> personRowMapper = BeanPropertyRowMapper.newInstance(Person.class);
        return this.jdbcTemplate.query(SQL_SELECT_PERSON, personRowMapper);
    }

    @Override
    public int countPeople() {
        String sql = "SELECT count(*) FROM person";
        return this.jdbcTemplate.queryForObject(sql, Integer.class);
    }

    @Override
    public Person findPersonById(int idPerson) {
        Person person;
        try {
            //Utilizamos la clase PersonaRowMapper
            person = jdbcTemplate.queryForObject(SQL_SELECT_PERSON_BY_ID, new PersonRowMapper(), idPerson);
        } catch (EmptyResultDataAccessException e) {
            e.printStackTrace(System.out);
            person = null;
        }
        return person;
    }

    @Override
    public void insertPerson(Person person) {
        SqlParameterSource parameterSource = new BeanPropertySqlParameterSource(person);
        this.namedParameterJdbcTemplate.update(SQL_INSERT_PERSON, parameterSource);
    }

    @Override
    public void updatePerson(Person person) {
        SqlParameterSource parameterSource = new BeanPropertySqlParameterSource(person);
        this.namedParameterJdbcTemplate.update(SQL_UPDATE_PERSON, parameterSource);
    }

    @Override
    public void deletePerson(Person person) {
        SqlParameterSource parameterSource = new BeanPropertySqlParameterSource(person);
        this.namedParameterJdbcTemplate.update(SQL_DELETE_PERSON, parameterSource);
    }

    @Override
    public Person getPersonByEmail(Person person) {
        String sql = "SELECT * FROM person WHERE email = :email";
        SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(person);
        return this.namedParameterJdbcTemplate.queryForObject(sql, namedParameters, new PersonRowMapper());
    }
    
}
