package service;

import java.util.List;
import jdbc.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.*;

@Service
@Transactional(propagation=Propagation.SUPPORTS, readOnly=true) 
public class PersonServiceImpl implements PersonService {

	@Autowired
	private PersonDao personDao;

        @Override
	public List<Person> listPeople() {
		return personDao.findAllPeople();
	}

        @Override
	public Person findPerson(Person person) {
		return personDao.findPersonById(person.getIdPerson());
	}

	@Transactional(propagation=Propagation.REQUIRED, readOnly=false) 
        @Override
	public void addPerson(Person person) {
		personDao.insertPerson(person);
	}

	@Transactional(propagation=Propagation.REQUIRED, readOnly=false) 
        @Override
	public void modifyPerson(Person person) {
		personDao.updatePerson(person);
	}

	@Transactional(propagation=Propagation.REQUIRED, readOnly=false) 
        @Override
	public void deletePerson(Person person) {
		personDao.deletePerson(person);
	}
}