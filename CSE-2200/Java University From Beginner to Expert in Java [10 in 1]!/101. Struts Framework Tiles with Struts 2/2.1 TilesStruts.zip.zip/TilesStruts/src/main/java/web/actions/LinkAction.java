package web.actions;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.convention.annotation.*;

@Results({
    @Result(name = "welcomeResult", location = "welcomeTile", type = "tiles"),
    @Result(name = "peopleResult", location = "peopleTile", type = "tiles")}
)
public class LinkAction extends ActionSupport {

    @Action(value = "welcomeAction")
    public String welcome() {
        return "welcomeResult";
    }

    @Action(value = "peopleAction")
    public String people() {
        return "peopleResult";
    }
}
