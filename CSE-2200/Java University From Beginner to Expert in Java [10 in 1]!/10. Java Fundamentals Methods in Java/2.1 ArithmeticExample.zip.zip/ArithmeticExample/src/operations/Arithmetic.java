package operations;

public class Arithmetic {
    //add operation
    int add(int a, int b) {
        return a + b;
    }
}

