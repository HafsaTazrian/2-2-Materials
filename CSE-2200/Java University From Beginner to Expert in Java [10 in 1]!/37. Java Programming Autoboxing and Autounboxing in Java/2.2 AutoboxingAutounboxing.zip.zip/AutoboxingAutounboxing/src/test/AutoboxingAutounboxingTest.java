package test;

public class AutoboxingAutounboxingTest {

    public static void main(String[] args) {

        //Autoboxing (they are converted from primitive types to Object types)
        Integer intObj = 10;
        Float floatObj = 15.2F;
        Double doubleObj = 40.1;
        System.out.println("Autoboxing");
        System.out.println("Integer Obj:" + intObj.intValue());
        System.out.println("Float Obj:" + floatObj.floatValue());
        System.out.println("Double Obj:" + doubleObj.doubleValue());

        //Autounboxing (they are converted from Object types to primitive types)
        int entero = intObj;
        float flotante = floatObj;
        double doble = doubleObj;
        System.out.println("\nAutounboxing");
        System.out.println("Integer:" + entero);
        System.out.println("Float:" + flotante);
        System.out.println("Double:" + doble);

    }
}
