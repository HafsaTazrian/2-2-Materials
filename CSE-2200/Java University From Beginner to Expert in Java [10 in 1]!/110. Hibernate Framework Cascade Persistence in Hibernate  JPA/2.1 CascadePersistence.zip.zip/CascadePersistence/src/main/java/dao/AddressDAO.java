package dao;

import static dao.GenericDAO.em;
import java.util.List;
import javax.persistence.Query;
import model.Address;

public class AddressDAO extends GenericDAO{
    
      public List<Address> list() {
        String hql = "SELECT a FROM Address a";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<Address> list = query.getResultList();
        for(Address a : list){
            System.out.println(a);
        }
        return list; 
    }

    public void insert(Address address) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(address);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error inserting object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void update(Address address) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(address);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error updating object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void delete(Address address) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.remove(em.merge(address));
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error removing object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public Address findById(Address address) {
        em = getEntityManager();
        return em.find(Address.class, address.getIdAddress());
    }
}