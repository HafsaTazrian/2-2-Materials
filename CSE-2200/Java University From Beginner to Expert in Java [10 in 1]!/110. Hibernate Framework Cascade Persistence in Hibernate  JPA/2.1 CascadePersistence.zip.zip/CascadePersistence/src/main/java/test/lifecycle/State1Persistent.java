package test.lifecycle;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import model.Address;

public class State1Persistent {

    public static void main(String[] args) {
        /*We use the JPA Persistence Unit*/
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("HibernateJpaPU");
        EntityManager em = factory.createEntityManager();
        /**
         * Objective: Transient to persistent state
         */

        //1. We create the object (new or transitive state)
        Address address = new Address();
        address.setStreetName("Star Avenue");
        address.setStreetNumber("51");
        address.setCountry("USA");

        //2. We persist the object (it changes state to persistent)
        //We start the transaction
        //We will not use the DAO classes in these exercises
        try {
            // We start a transaction
            em.getTransaction().begin();
            // Insert the new address
            em.persist(address);
            // We finish the transaction
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error inserting object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
            }
        }

        //The address object changes from persistent state to detached
        //at the close of the session
        System.out.println("New contact:" + address);
    }
}