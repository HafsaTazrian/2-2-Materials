package test.lifecycle;

import javax.persistence.*;
import javax.persistence.Persistence;
import model.Address;

public class State2RetrivePersistentObject {
    
    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("HibernateJpaPU");
        EntityManager em = factory.createEntityManager();
        /**
         * Objective: Recover a persistent object with Hibernate / JPA
         */

        //There are 2 ways to perform this action
        //1. Method get, return null if you can not find the object
        Address address1 = null;

        try {
            em.getTransaction().begin();
            //We provide the ID to recover, in JPA we use find instead of get
            address1 = (Address) em.find(Address.class, 2);
            System.out.println("Address retrieved with find:" + address1);
            em.getTransaction().commit(); //we make flush
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace(System.out);
        } 

        //The object of address1 changes to edo. detached at the close of the session
        
        //2. Method load, return ObjectNotFoundException
        //if you can not find the id provided
        Address address2 = null;
        //We create a second transaction
        try {
            em.getTransaction().begin();

            //We provide the id to recover, it does not get relationships (lazy)
            //In JPA we have getReference as another option
            address2 = (Address) em.getReference(Address.class, 2);
            System.out.println("Address retrieved with getReference:" + address2);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace(System.out);
        } finally {
            if (em != null) {
                em.close();
            }
        }

        //The address2 object changes to detached state
        //when closing transaction 2
    }
}