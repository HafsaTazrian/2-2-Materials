package test.cascade;

import javax.persistence.*;
import model.*;

public class CascadePersistenceTest {

    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("HibernateJpaPU");
        EntityManager em = factory.createEntityManager();

        // We create an Address object
        Address address = new Address();
        address.setStreetName("Merside");
        address.setStreetNumber("419");
        address.setCountry("England");

        // We create a Student object
        Student student = new Student();
        student.setName("Charly");
        
        //We add the relationship and its persistence in cascade
        student.setAddress(address);

        try {
            em.getTransaction().begin();
            //We only persist the student, and the associated 
            //relationships marked as cascading persistence are added automatically
            em.persist(student);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace(System.out);
        } finally {
            if (em != null) {
                em.close();
            }
        }

        // Embedded objects
        System.out.println("Student inserted:" + student);
    }
}