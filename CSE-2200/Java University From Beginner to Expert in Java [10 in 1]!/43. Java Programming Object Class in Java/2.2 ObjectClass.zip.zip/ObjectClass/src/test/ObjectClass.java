package test;

public class ObjectClass {
    
    public static void main(String[] args) {
        
        Employee emp1 = new Employee("John",1000);
        Employee emp2 = new Employee("John",1000);
        
        compareObjects(emp1,emp2);
    }
    
    private static void compareObjects(Employee emp1, Employee emp2){
        //Calling the method toString
        //By default the toString method is called within println method
        System.out.println("Object Content:" + emp1);
        
        //Revision by reference
        if( emp1 == emp2)
            System.out.println("Objects have same memory address");
        else
            System.out.println("Objects have different memory address");
        
        //Revision by the equals method
        if(emp1.equals(emp2))
            System.out.println("The objects have the same content, they are the same");
        else
            System.out.println("The objects do NOT have the same content, they are NOT the same");
        
        //We review the hashCode method
        if(emp1.hashCode() == emp2.hashCode())
            System.out.println("The objects have the same hash code");
        else
            System.out.println("The objects do NOT have the same hash code");    
    }
}