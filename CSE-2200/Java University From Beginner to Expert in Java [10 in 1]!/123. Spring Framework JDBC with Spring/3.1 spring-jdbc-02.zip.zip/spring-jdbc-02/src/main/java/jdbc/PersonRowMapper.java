package jdbc;

import java.sql.*;
import org.springframework.jdbc.core.RowMapper;

public class PersonRowMapper implements RowMapper<Person> {

    // Method that is called by the Spring template. This is a callback method
    @Override
    public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
        //Creation of the person object for each record found in the resultSet
        Person person = new Person();
        person.setIdPerson(rs.getInt("id_person"));
        person.setName(rs.getString("name"));
        person.setEmail(rs.getString("email"));
        return person;
    }
}