package test;

import org.apache.logging.log4j.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:datasource-test.xml"})
public class TestJdbc {

    private final Logger logger = LogManager.getRootLogger();
    
    @Autowired
    JdbcTemplate jdbcTemplate;

    @Test
    public void testJdbc() {
        logger.info("Start of the Jdbc test");
        String sql = "select count(*) from person";
        int noPersonas = jdbcTemplate.queryForObject(sql, Integer.class);

        logger.info("Number of people:" + noPersonas);

        assertEquals(3, noPersonas);

        logger.info("End of the Jdbc test");

    }
}
