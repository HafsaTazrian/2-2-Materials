package test;

public class Person {

    private final int personId;
    private static int peopleCounter;

    static {
        System.out.println("Execute the static block");
        peopleCounter = 10;
    }

    {
        System.out.println("Execute the initializer block");
        personId = ++peopleCounter;
    }

    Person() {
        System.out.println("Run the Constructor");
    }

    public int getPersonId() {
        return personId;
    }

}
