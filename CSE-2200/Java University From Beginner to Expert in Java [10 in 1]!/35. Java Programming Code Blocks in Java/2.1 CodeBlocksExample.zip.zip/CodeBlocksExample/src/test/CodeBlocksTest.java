package test;

public class CodeBlocksTest {
    
    public static void main(String[] args) {

        Person p1 = new Person();
        int id = p1.getPersonId();
        System.out.println("Person id:" + id);
    }
    
}
