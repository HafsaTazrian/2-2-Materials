package person.test;

import java.sql.SQLException;
import java.util.List;
import person.dto.PersonDTO;
import person.jdbc.*;

public class PersonTest {
        public static void main(String[] args) {
        //We use the interface type as reference to a specific class
        DaoPerson personaDao = new DaoPersonJdbc();

        //We create a new record
        //We use the DTO person class which is used
        //to transfer the information between the layers   
        //it is not necessary to specify the primary key
        //since in this case it is of the autonumeric type 
        //and the DB is in charge to assign a new value
        PersonDTO personDto = new PersonDTO();
        personDto.setName("Charly");
        //Utilizamos la capa DAO para persistir el objeto DTO
        try {
            //personaDao.insert(personDto);

            //we remove a record, the id 3
//            personaDao.delete( new PersonDTO(3));
            
            //update a record
//             PersonDTO personDto2= new PersonDTO();
//             personDto2.setIdPerson(2);//updated the record 2
//             personDto2.setName("Katty2");
//             personaDao.update(personDto2);
            
            //Seleccionamos todos los registros
            List<PersonDTO> personas = personaDao.select();
            for (PersonDTO personaDTO : personas) {
                System.out.print( personaDTO );
                System.out.println();
            }

        } catch (SQLException e) {
            System.out.println("Data Layer Exception");
            e.printStackTrace(System.out);
        }
    }

}