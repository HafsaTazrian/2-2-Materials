package person.dto;

public class PersonDTO {

    private int idPerson;
    private String name;
    
    public PersonDTO(){}
    
    public PersonDTO(int personId){
        this.idPerson = personId;
    }

    public int getIdPerson() {
        return idPerson;
    }

    public void setIdPerson(int idPerson) {
        this.idPerson = idPerson;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

     @Override
    public String toString() {
        return "PersonDTO{" + "idPerson=" + idPerson + ", name=" + name + '}';
    }
}