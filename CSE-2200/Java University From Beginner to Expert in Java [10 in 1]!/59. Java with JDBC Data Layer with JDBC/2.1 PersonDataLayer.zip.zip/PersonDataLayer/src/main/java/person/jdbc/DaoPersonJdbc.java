package person.jdbc;

import java.sql.*;
import java.util.*;
import person.dto.PersonDTO;

public class DaoPersonJdbc implements DaoPerson{
    
    private java.sql.Connection userConn;
    private final String SQL_INSERT = "INSERT INTO person(name) VALUES(?)";
    private final String SQL_UPDATE = "UPDATE person SET name=? WHERE id_person=?";
    private final String SQL_DELETE = "DELETE FROM person WHERE id_person = ?";
    private final String SQL_SELECT = "SELECT id_person, name FROM person ORDER BY id_person";

    /*
     * Add the empty constructor
     */
    public DaoPersonJdbc() {
    }

    /**
     * Constructor that assigns an existing connection to be used in the queries
     * of this class
     *
     * @param conn Connection to the DB previously created
     */
    public DaoPersonJdbc(Connection conn) {
        this.userConn = conn;
    }

    /**
     * Method that inserts a record in the PersonDTO table
     *
     * @param personDTO
     * @return int the number of modified rows
     * @throws java.sql.SQLException
     */
    @Override
    public int insert(PersonDTO personDTO) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0; //affected rows
        try {
            //If the connection to reuse is different from null, it is used, if not
            //create a new connection
            conn = (this.userConn != null) ? this.userConn : JConnection.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, personDTO.getName());//param 1 => ? name
            System.out.println("Executing query:" + SQL_INSERT);
            rows = stmt.executeUpdate();
            System.out.println("Affected records:" + rows);
        } finally {
            if (this.userConn == null) {
                JConnection.close(conn);
            }
        }
        return rows;
    }

    /**
     * Method that updates an existing record
     *
     * @param idPersonDTO Primary key
     * @param name Name value
     * @return int modified rows
     * @throws java.sql.SQLException
     */
    @Override
    public int update(PersonDTO personDTO) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = (this.userConn != null) ? this.userConn : JConnection.getConnection();
            System.out.println("Executing query:" + SQL_UPDATE);
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, personDTO.getName());//param 1 => ?  name
            stmt.setInt(2, personDTO.getIdPerson());//param 2 => ? id_person
            rows = stmt.executeUpdate();
            System.out.println("Updated records:" + rows);
        } finally {
           if (this.userConn == null) {
                JConnection.close(conn);
            }
        }
        return rows;
    }

    /**
     * Method that deletes an existing record
     *
     * @param personDTO
     * @return int rows affected
     * @throws java.sql.SQLException
     */
    @Override
    public int delete(PersonDTO personDTO) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int rows = 0;
        try {
            conn = (this.userConn != null) ? this.userConn : JConnection.getConnection();
            System.out.println("Executing query:" + SQL_DELETE);
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, personDTO.getIdPerson());//param 1 => ? id_person
            rows = stmt.executeUpdate();
            System.out.println("Deleted records:" + rows);
        } finally {
            if (this.userConn == null) {
                JConnection.close(conn);
            }
        }
        return rows;
    }

    /**
     * Method that returns the contents of the PersonDTO table
     *
     * @return list of person objects
     * @throws java.sql.SQLException
     */
    @Override
    public List<PersonDTO> select() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        PersonDTO persona = null;
        List<PersonDTO> personas = new ArrayList<>();
        try {
            conn = (this.userConn != null) ? this.userConn : JConnection.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_persona = rs.getInt(1);
                String nombre = rs.getString(2);
                persona = new PersonDTO();
                persona.setIdPerson(id_persona);
                persona.setName(nombre);
                personas.add(persona);
            }
        } finally {
            if (this.userConn == null) {
                JConnection.close(conn);
            }
        }
        return personas;
    }
}