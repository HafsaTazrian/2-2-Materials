package person.jdbc;

import java.sql.SQLException;
import java.util.List;
import person.dto.PersonDTO;

public interface DaoPerson {

    public int insert(PersonDTO persona) throws SQLException;

    public int update(PersonDTO persona) throws SQLException;

    public int delete(PersonDTO persona) throws SQLException;

    public List<PersonDTO> select() throws SQLException;
}
