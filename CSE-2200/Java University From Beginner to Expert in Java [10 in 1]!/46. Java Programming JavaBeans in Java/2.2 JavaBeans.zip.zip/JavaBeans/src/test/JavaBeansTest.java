package test;

import javabean.PersonBean;

public class JavaBeansTest {
    
    public static void main(String[] args) {

        PersonBean bean = new PersonBean();
        bean.setName("John");
        bean.setAge(29);
        
        System.out.println("Name:" + bean.getName());
        System.out.println("Age:" + bean.getAge());

    }
}
