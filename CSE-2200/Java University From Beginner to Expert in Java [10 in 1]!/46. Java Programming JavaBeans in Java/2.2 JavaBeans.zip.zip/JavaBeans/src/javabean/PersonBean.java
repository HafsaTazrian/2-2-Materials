package javabean;

//1. Implement the Serializable interface of the java.io package
public class PersonBean implements java.io.Serializable {

    //2. Each property is of private type
    private String name;
    private int age;

    //3. Always have a Constructor without arguments
    //Other Constructors are optional
    public PersonBean() {
    }

    //Constructor of the JavaBean with 2 arguments (Not required)
    public PersonBean(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    //4. For each property add a get and set
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}