/**
 * @author ubaldo
 */
window.onload = loadImages;

/*
 *Function that loads all the images that work
 * as a link, in particular those that are involved
 * with a "A" tag. A stands for anchor
 */
function loadImages() {
    for (var i = 0; i < document.images.length; i++) {
        if (document.images[i].parentNode.tagName == "A"){
            configureRollover(document.images[i]);
        }
    }
}

/**
 * This function is executed when the page is started, and it is used
 * to associate the rollover images with the links
 * that will work as such
 * @param {Object} image - The image that works as a rollover
*/
function configureRollover(imagen) {
    imagen.imagenOff = new Image();
    imagen.imagenOff.src = "button_off.jpg";
    imagen.onmouseout = changeOff;

    imagen.imagenOn = new Image();
    imagen.imagenOn.src = "button_on.jpg";
    imagen.onmouseover = changeOn;
}

/**
 * These functions are executed according to the event that is triggered
 * but it is not at the start of the page, but depends on the
 * Button that is pressed, they are known as handlers
*/
// It was associated with the onmouseout event
function changeOff() {
    this.src = this.imagenOff.src;//we take the values already associated
}

//It was associated with the onmouseover event
function changeOn() {
    this.src = this.imagenOn.src;//we take the values already associated
}