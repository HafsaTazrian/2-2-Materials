/**
 * @author ubaldo
 */
window.onload = startData;

/**
 * Function that is sent to call when HTML page is loaded
 */
function startData() {
    document.getElementById("link").onclick = validateExit;
    document.getElementById("searchLink").onclick = search;
}

/**
 * Function that validates if the user wants to leave the site or not
 */
function validateExit() {
    if (confirm("Do you want to leave the site?")) {
        alert("We're going to google");
        return true; //We return true to leave
    } else {
        alert("We stay on the site");
        return false;//We return false to stay 

    }
}

/**
 * Function that asks for a string to search in google
 */
function search() {
    //With the prompt function we capture user information
    var answer = prompt("Write the string to search:", "");
    //if there was an answer we concatenated the String to look for the google link
    if (answer) {
        alert("Your answer was:" + answer);
        // the this operator helps us to reference
        // to the element that caused the event, in this case
        // the element with identifier "searchLink"
        // and we concatenate the response as a parameter
        // of a request get
        var newLink = this + "search?q=" + answer;
        alert("New link:" + newLink);
        //redirect the link
        window.location = newLink;
        //we return false, but it takes us to the link originally
        //registered in the "searchLink" element
        return false;
    } else {
        alert("You did not provide any string to search");
        return false;
    }
}