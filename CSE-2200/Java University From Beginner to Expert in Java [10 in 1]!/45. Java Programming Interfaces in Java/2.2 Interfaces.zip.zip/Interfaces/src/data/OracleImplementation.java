package data;

public class OracleImplementation implements DataAccess{
    
    @Override
    public void insert() {
        System.out.println("Insert from Oracle");
    }

    @Override
    public void list() {
        System.out.println("List from Oracle");
    }

}
