package data;

public interface DataAccess {
    
    public static int MAX_RECORDS = 10;

    public abstract void insert();
    
    public abstract void list();
    
}
