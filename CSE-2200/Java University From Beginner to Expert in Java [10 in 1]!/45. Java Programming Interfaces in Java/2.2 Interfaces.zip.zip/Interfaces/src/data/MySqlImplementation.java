package data;

public class MySqlImplementation implements DataAccess{
    
    @Override
    public void insert() {
        System.out.println("Insert from MySql");
    }

    @Override
    public void list() {
           System.out.println("List from MySql");
    }
}
