package test;

import data.*;

public class InterfacesTest {
    
    public static void main(String[] args) {
        
        DataAccess data;
        String action;
        
        //Oracle Test
        data = new OracleImplementation();
        action="list";
        ejecutar(data,action);
        
        //MySql Test
        data = new MySqlImplementation();
        action="insert";
        ejecutar(data, action);
    }
    
    private static void ejecutar(DataAccess data, String action){
        if("list".equals(action)){
            data.list();
        }
        else if("insert".equals(action)){
            data.insert();
        }
    }   
}
