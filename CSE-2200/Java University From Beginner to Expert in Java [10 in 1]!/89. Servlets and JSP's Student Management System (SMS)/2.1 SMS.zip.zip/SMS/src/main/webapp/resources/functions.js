var hidden = true;

function seeDetail() {
    if (hidden == true) {
        showDetail();
    } else {
        hideDetail();
    }
}

function showDetail() {
    document.getElementById("detail").style.display = "inline";
    document.getElementById("btnDetail").value = "Hide Detail";
    hidden = false;
}

function hideDetail() {
    document.getElementById("detail").style.display = "none";
    document.getElementById("btnDetail").value = "See Detail";
    hidden = true;
}

//Function to select or deselect all the checkboxes of a form
function selectAllCheckboxes(checkboxController) {
    //alert("checkboxController:" + checkboxController.checked);

    //We recover the form and array of checkboxes
    var form = document.getElementById("form1");
    var people = form.people;

    //The checkboxController defines whether individual elements are activated or deactivated
    //We verify that it is an array
    if (people.length > 0) {
        for (i = 0; i < people.length; i++) {
            people[i].checked = checkboxController.checked;
        }
    } else {
        if (people != null) {
            people.checked = checkboxController.checked;
        }
    }

}

//Validation of the People form
function validateFormPeopleList(button) {
    //alert(button.value);
    //We recover the form and the action to modify it
    var form = document.getElementById("form1");
    var action = document.getElementById("action");

    if (button.value == "Add") {
        action.value = "addPerson";
    } else if (button.value == "Edit") {
        //There should only be one item selected
        if (this.validSingleCheckbox()) {
            action.value = "editPerson";
        } else {
            alert("You must select only one item to Edit");
            return false;
        }
    } else if (button.value == "Delete") {
        action.value = "deletePerson";
    }

    //We send the form
    form.submit();
}

//Validation of only one selected checkbox
function validSingleCheckbox() {
    //We recover the form and arrangement of checkboxes
    var form = document.getElementById("form1");
    var people = form.people;

    //Verify if more than one element is selected
    var checkboxesCounter = 0;

    //We verify that it is an arrangement
    if (people.length > 0) {
        //We increase the counter for each element
        for (i = 0; i < people.length; i++) {
            if (people[i].checked) {
                checkboxesCounter++;
            }
        }
    } else {
        //This happens when there is only one element in the table, you have to remember
        // that dynamically people could be eliminated and only leave a record
        // so it no longer generates a javascript fix, but an isolated checkbox
        if (people != null && people.checked) {
            checkboxesCounter++;
        }
    }

    //Solo se debio haber seleccionado un elemento
    if (checkboxesCounter == 1)
        return true;
    else
        return false;
}

/*We return to the list*/
function cancel() {
    var form = document.getElementById("form1");
    //We update the URL that was assigned to the form
    //To request again the list of people, since we are canceling the modification
    window.location = form.context.value + "/ControllerServlet";
    form.action.value = "peopleList";
    form.submit();
}

//This event allows us to detect when we click on a cell
function editRow(selectedRow) {
    //alert(selectedRow);
    
    //We recover the form and the action to modify it
    var form = document.getElementById("form1");
    var action = document.getElementById("action");

    action.value = "editPerson";
    form.people[selectedRow - 1].checked = true;

    //We send the form
    form.submit();
}
