package sms.eis.jdbc;

import java.sql.*;
import java.util.*;
import sms.eis.dao.PersonDao;
import sms.eis.dto.Person;
import sms.eis.dto.PersonPk;
import sms.eis.exceptions.PersonDaoException;

public class PersonDaoImpl extends AbstractDAO implements PersonDao {

    /**
     * The factory class for this DAO has two versions of the create() method -
     * one that takes no arguments and one that takes a Connection argument. If
     * the Connection version is chosen then the connection will be stored in
     * this attribute and will be used by all calls to this DAO, otherwise a new
     * Connection will be allocated for each operation.
     */
    private java.sql.Connection userConn;

    /**
     * All finder methods in this class use this SELECT constant to build their
     * queries
     */
    protected final String SQL_SELECT = "SELECT id_person, first_name, last_name FROM " + getTableName() + "";

    /**
     * Finder methods will pass this value to the JDBC setMaxRows method
     */
    protected int maxRows;

    /**
     * SQL INSERT statement for this table
     */
    protected final String SQL_INSERT = "INSERT INTO " + getTableName() + " ( id_person, first_name, last_name ) VALUES ( ?, ?, ? )";

    /**
     * SQL UPDATE statement for this table
     */
    protected final String SQL_UPDATE = "UPDATE " + getTableName() + " SET id_person = ?, first_name = ?, last_name = ? WHERE id_person = ?";

    /**
     * SQL DELETE statement for this table
     */
    protected final String SQL_DELETE = "DELETE FROM " + getTableName() + " WHERE id_person = ?";

    /**
     * Index of column id_person
     */
    protected static final int COLUMN_ID_PERSON = 1;

    /**
     * Index of column first_name
     */
    protected static final int COLUMN_FIRST_NAME = 2;

    /**
     * Index of column last_name
     */
    protected static final int COLUMN_LAST_NAME = 3;

    /**
     * Number of columns
     */
    protected static final int NUMBER_OF_COLUMNS = 3;

    /**
     * Index of primary-key column id_person
     */
    protected static final int PK_COLUMN_ID_PERSON = 1;

    /**
     * Inserts a new row in the person table.
     */
    public PersonPk insert(Person dto) throws PersonDaoException {
        long t1 = System.currentTimeMillis();
        // declare variables
        final boolean isConnSupplied = (userConn != null);
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // get the user-specified connection or get a connection from the ResourceManager
            conn = isConnSupplied ? userConn : ResourceManager.getConnection();

            stmt = conn.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS);
            int index = 1;
            if (dto.getIdPerson() != null) {
                stmt.setInt(index++, dto.getIdPerson().intValue());
            } else {
                stmt.setNull(index++, java.sql.Types.INTEGER);
            }

            stmt.setString(index++, dto.getFirstName());
            stmt.setString(index++, dto.getLastName());
            System.out.println("Executing " + SQL_INSERT + " with DTO: " + dto);
            int rows = stmt.executeUpdate();
            long t2 = System.currentTimeMillis();
            System.out.println(rows + " rows affected (" + (t2 - t1) + " ms)");

            // retrieve values from auto-increment columns
            rs = stmt.getGeneratedKeys();
            if (rs != null && rs.next()) {
                dto.setIdPerson(new Integer(rs.getInt(1)));
            }

            reset(dto);
            return dto.createPk();
        } catch (Exception _e) {
            _e.printStackTrace();
            throw new PersonDaoException("Exception: " + _e.getMessage(), _e);
        } finally {
            ResourceManager.close(stmt);
            if (!isConnSupplied) {
                ResourceManager.close(conn);
            }

        }

    }

    /**
     * Updates a single row in the person table.
     */
    public void update(PersonPk pk, Person dto) throws PersonDaoException {
        long t1 = System.currentTimeMillis();
        // declare variables
        final boolean isConnSupplied = (userConn != null);
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // get the user-specified connection or get a connection from the ResourceManager
            conn = isConnSupplied ? userConn : ResourceManager.getConnection();

            System.out.println("Executing " + SQL_UPDATE + " with DTO: " + dto);
            stmt = conn.prepareStatement(SQL_UPDATE);
            int index = 1;
            if (dto.getIdPerson() != null) {
                stmt.setInt(index++, dto.getIdPerson().intValue());
            } else {
                stmt.setNull(index++, java.sql.Types.INTEGER);
            }

            stmt.setString(index++, dto.getFirstName());
            stmt.setString(index++, dto.getLastName());
            if (pk.getIdPerson() != null) {
                stmt.setInt(4, pk.getIdPerson().intValue());
            } else {
                stmt.setNull(4, java.sql.Types.INTEGER);
            }

            int rows = stmt.executeUpdate();
            reset(dto);
            long t2 = System.currentTimeMillis();
            System.out.println(rows + " rows affected (" + (t2 - t1) + " ms)");
        } catch (Exception _e) {
            _e.printStackTrace();
            throw new PersonDaoException("Exception: " + _e.getMessage(), _e);
        } finally {
            ResourceManager.close(stmt);
            if (!isConnSupplied) {
                ResourceManager.close(conn);
            }

        }

    }

    /**
     * Deletes a single row in the person table.
     */
    public void delete(PersonPk pk) throws PersonDaoException {
        long t1 = System.currentTimeMillis();
        // declare variables
        final boolean isConnSupplied = (userConn != null);
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // get the user-specified connection or get a connection from the ResourceManager
            conn = isConnSupplied ? userConn : ResourceManager.getConnection();

            System.out.println("Executing " + SQL_DELETE + " with PK: " + pk);
            stmt = conn.prepareStatement(SQL_DELETE);
            if (pk.getIdPerson() != null) {
                stmt.setInt(1, pk.getIdPerson().intValue());
            } else {
                stmt.setNull(1, java.sql.Types.INTEGER);
            }

            int rows = stmt.executeUpdate();
            long t2 = System.currentTimeMillis();
            System.out.println(rows + " rows affected (" + (t2 - t1) + " ms)");
        } //Agregamos esta validacion para poder recueparar la excepcion si es que
        //ocurrio un error por integridad referencial
        /*
    catch(MySQLIntegrityConstraintViolationException ex){
      ex.printStackTrace();
			throw new PersonDaoException( "Exception: " + ex.getMessage(), ex );
    }
         */ catch (Exception _e) {
            _e.printStackTrace();
            throw new PersonDaoException("Exception: " + _e.getMessage(), _e);
        } finally {
            ResourceManager.close(stmt);
            if (!isConnSupplied) {
                ResourceManager.close(conn);
            }

        }

    }

    /**
     * Returns the rows from the person table that matches the specified
     * primary-key value.
     */
    public Person findByPrimaryKey(PersonPk pk) throws PersonDaoException {
        return findByPrimaryKey(pk.getIdPerson());
    }

    /**
     * Returns all rows from the person table that match the criteria 'id_person
     * = :idPerson'.
     */
    public Person findByPrimaryKey(Integer idPerson) throws PersonDaoException {
        Person ret[] = findByDynamicSelect(SQL_SELECT + " WHERE id_person = ?", new Object[]{idPerson});
        return ret.length == 0 ? null : ret[0];
    }

    /**
     * Returns all rows from the person table that match the criteria ''.
     */
    public Person[] findAll() throws PersonDaoException {
        return findByDynamicSelect(SQL_SELECT + " ORDER BY id_person", null);
    }

    /**
     * Method 'PersonDaoImpl'
     *
     */
    public PersonDaoImpl() {
    }

    /**
     * Method 'PersonDaoImpl'
     *
     * @param userConn
     */
    public PersonDaoImpl(final java.sql.Connection userConn) {
        this.userConn = userConn;
    }

    /**
     * Sets the value of maxRows
     */
    public void setMaxRows(int maxRows) {
        this.maxRows = maxRows;
    }

    /**
     * Gets the value of maxRows
     */
    public int getMaxRows() {
        return maxRows;
    }

    /**
     * Method 'getTableName'
     *
     * @return String
     */
    public String getTableName() {
        return "person";
    }

    /**
     * Fetches a single row from the result set
     */
    protected Person fetchSingleResult(ResultSet rs) throws SQLException {
        if (rs.next()) {
            Person dto = new Person();
            populateDto(dto, rs);
            return dto;
        } else {
            return null;
        }

    }

    /**
     * Fetches multiple rows from the result set
     */
    protected Person[] fetchMultiResults(ResultSet rs) throws SQLException {
        Collection resultList = new ArrayList();
        while (rs.next()) {
            Person dto = new Person();
            populateDto(dto, rs);
            resultList.add(dto);
        }

        Person ret[] = new Person[resultList.size()];
        resultList.toArray(ret);
        return ret;
    }

    /**
     * Populates a DTO with data from a ResultSet
     */
    protected void populateDto(Person dto, ResultSet rs) throws SQLException {
        dto.setIdPerson(new Integer(rs.getInt(COLUMN_ID_PERSON)));
        dto.setFirstName(rs.getString(COLUMN_FIRST_NAME));
        dto.setLastName(rs.getString(COLUMN_LAST_NAME));
    }

    /**
     * Resets the modified attributes in the DTO
     */
    protected void reset(Person dto) {
    }

    /**
     * Returns all rows from the person table that match the specified arbitrary
     * SQL statement
     */
    public Person[] findByDynamicSelect(String sql, Object[] sqlParams) throws PersonDaoException {
        // declare variables
        final boolean isConnSupplied = (userConn != null);
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // get the user-specified connection or get a connection from the ResourceManager
            conn = isConnSupplied ? userConn : ResourceManager.getConnection();

            // construct the SQL statement
            final String SQL = sql;

            System.out.println("Executing " + SQL);
            // prepare statement
            stmt = conn.prepareStatement(SQL);
            stmt.setMaxRows(maxRows);

            // bind parameters
            for (int i = 0; sqlParams != null && i < sqlParams.length; i++) {
                stmt.setObject(i + 1, sqlParams[i]);
            }

            rs = stmt.executeQuery();

            // fetch the results
            return fetchMultiResults(rs);
        } catch (Exception _e) {
            _e.printStackTrace();
            throw new PersonDaoException("Exception: " + _e.getMessage(), _e);
        } finally {
            ResourceManager.close(rs);
            ResourceManager.close(stmt);
            if (!isConnSupplied) {
                ResourceManager.close(conn);
            }

        }

    }

    /**
     * Returns all rows from the person table that match the specified arbitrary
     * SQL statement
     */
    public Person[] findByDynamicWhere(String sql, Object[] sqlParams) throws PersonDaoException {
        // declare variables
        final boolean isConnSupplied = (userConn != null);
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // get the user-specified connection or get a connection from the ResourceManager
            conn = isConnSupplied ? userConn : ResourceManager.getConnection();

            // construct the SQL statement
            final String SQL = SQL_SELECT + " WHERE " + sql;

            System.out.println("Executing " + SQL);
            // prepare statement
            stmt = conn.prepareStatement(SQL);
            stmt.setMaxRows(maxRows);

            // bind parameters
            for (int i = 0; sqlParams != null && i < sqlParams.length; i++) {
                stmt.setObject(i + 1, sqlParams[i]);
            }

            rs = stmt.executeQuery();

            // fetch the results
            return fetchMultiResults(rs);
        } catch (Exception _e) {
            _e.printStackTrace();
            throw new PersonDaoException("Exception: " + _e.getMessage(), _e);
        } finally {
            ResourceManager.close(rs);
            ResourceManager.close(stmt);
            if (!isConnSupplied) {
                ResourceManager.close(conn);
            }

        }

    }

    //Agregamos estos metodos para poder recuperar o settear una conexion externa
    /**
     * @return the userConn
     */
    public java.sql.Connection getUserConn() {
        return userConn;
    }

    /**
     * @param userConn the userConn to set
     */
    public void setUserConn(java.sql.Connection userConn) {
        this.userConn = userConn;
    }

}
