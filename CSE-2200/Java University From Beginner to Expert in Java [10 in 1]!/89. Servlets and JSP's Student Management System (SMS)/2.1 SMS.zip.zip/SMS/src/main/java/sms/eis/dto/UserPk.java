package sms.eis.dto;

import java.io.Serializable;

/** 
 * This class represents the primary key of the user table.
 */
public class UserPk implements Serializable
{
	protected Integer idUser;

	/** 
	 * Sets the value of idUser
	 */
	public void setIdUser(Integer idUser)
	{
		this.idUser = idUser;
	}

	/** 
	 * Gets the value of idUser
	 */
	public Integer getIdUser()
	{
		return idUser;
	}

	/**
	 * Method 'UserPk'
	 * 
	 */
	public UserPk()
	{
	}

	/**
	 * Method 'UserPk'
	 * 
	 * @param idUser
	 */
	public UserPk(final Integer idUser)
	{
		this.idUser = idUser;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof UserPk)) {
			return false;
		}
		
		final UserPk _cast = (UserPk) _other;
		if (idUser == null ? _cast.idUser != idUser : !idUser.equals(_cast.idUser )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (idUser != null) {
			_hashCode = 29 * _hashCode + idUser.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "ap.eis.dto.UserPk: " );
		ret.append("idUser=" + idUser );
		return ret.toString();
	}

}
