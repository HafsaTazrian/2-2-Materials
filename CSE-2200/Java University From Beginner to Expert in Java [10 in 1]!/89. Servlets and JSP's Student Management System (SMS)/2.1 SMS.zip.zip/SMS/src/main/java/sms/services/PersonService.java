package sms.services;

import sms.eis.dto.Person;
import java.util.List;

/**
 *
 * @author Ubaldo
 */
public interface PersonService {

  public List<Person> getAllPeople();

  public Person getPersonById(Integer idPerson);

  public boolean deletePeople(List<Integer> idPeople);

  public boolean savePerson(Person person);

}
