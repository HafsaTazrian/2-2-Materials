package sms.eis.factory;

import java.sql.Connection;
import sms.eis.dao.UserDao;
import sms.eis.jdbc.UserDaoImpl;

public class UserDaoFactory
{
	/**
	 * Method 'create'
	 * 
	 * @return UserDao
	 */
	public static UserDao create()
	{
		return new UserDaoImpl();
	}

	/**
	 * Method 'create'
	 * 
	 * @param conn
	 * @return UserDao
	 */
	public static UserDao create(Connection conn)
	{
		return new UserDaoImpl( conn );
	}

}
