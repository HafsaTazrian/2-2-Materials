package sms.services;

import sms.eis.dto.User;

/**
 *
 * @author Ubaldo
 */
public interface UserService {

    public boolean existingUser(User user);
    
}
