package sms.eis.factory;

import java.sql.Connection;
import sms.eis.dao.PersonDao;
import sms.eis.jdbc.PersonDaoImpl;

public class PersonDaoFactory
{
	/**
	 * Method 'create'
	 * 
	 * @return PersonDao
	 */
	public static PersonDao create()
	{
		return new PersonDaoImpl();
	}

	/**
	 * Method 'create'
	 * 
	 * @param conn
	 * @return PersonDao
	 */
	public static PersonDao create(Connection conn)
	{
		return new PersonDaoImpl( conn );
	}

}
