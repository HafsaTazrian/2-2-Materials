package sms.eis.dto;

import java.io.Serializable;

/** 
 * This class represents the primary key of the person table.
 */
public class PersonPk implements Serializable
{
	protected Integer idPerson;

	/** 
	 * Sets the value of idPerson
	 */
	public void setIdPerson(Integer idPerson)
	{
		this.idPerson = idPerson;
	}

	/** 
	 * Gets the value of idPerson
	 */
	public Integer getIdPerson()
	{
		return idPerson;
	}

	/**
	 * Method 'PersonPk'
	 * 
	 */
	public PersonPk()
	{
	}

	/**
	 * Method 'PersonPk'
	 * 
	 * @param idPerson
	 */
	public PersonPk(final Integer idPerson)
	{
		this.idPerson = idPerson;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PersonPk)) {
			return false;
		}
		
		final PersonPk _cast = (PersonPk) _other;
		if (idPerson == null ? _cast.idPerson != idPerson : !idPerson.equals(_cast.idPerson )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (idPerson != null) {
			_hashCode = 29 * _hashCode + idPerson.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "ap.eis.dto.PersonPk: " );
		ret.append("idPerson=" + idPerson );
		return ret.toString();
	}

}
