/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sms.web;

import sms.eis.dto.Person;
import sms.eis.dto.User;
import sms.services.impl.PersonServiceImpl;
import sms.services.impl.UserServiceImpl;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sms.services.PersonService;
import sms.services.UserService;

/**
 *
 * @author Ubaldo
 */
@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("listPeople".equals(action)) {
            this.confirmUserInSession(request, response);
        } else if ("validateUser".equals(action)) {
            this.validateUser(request, response);
        } else if ("addPerson".equals(action)) {
            this.addPerson(request, response);
        } else if ("editPerson".equals(action)) {
            this.editPerson(request, response);
        } else if ("deletePerson".equals(action)) {
            this.deletePerson(request, response);
        } else if ("savePerson".equals(action)) {
            this.savePerson(request, response);
        } else if ("exit".equals(action)) {
            this.exit(request, response);
        } else {
            this.actionByDefault(request, response);
        }

    }

    //Method to process validate if the user is already logged in
    private void confirmUserInSession(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //We check if the user is already in session
        HttpSession session = request.getSession();

        String username = (String) session.getAttribute("username");
        if (username != null) {
            //If a user already exists in session, we redirect them to the list of people
            this.listPeople(request, response);
        } else {
            request.getRequestDispatcher("/WEB-INF/pages/sms/login.jsp").forward(request, response);
        }
    }

    //Method to process the use case of listPersonas
    private void listPeople(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //We check if the user is already in session
        HttpSession session = request.getSession();

        String username = (String) session.getAttribute("username");

        //If the user is already in session, we redirect them to the list of people
        if (username != null) {
            //We recover the list of people, we use the People service
            PersonService personService = PersonServiceImpl.getInstance();
            List<Person> people = personService.getAllPeople();

            //Si se encontraron personas, las compartimos en la pagina Web
            if (people != null && people.size() > 0) {
                request.setAttribute("peopleList", people);
            }

            request.getRequestDispatcher("/WEB-INF/pages/sms/peopleList.jsp").forward(request, response);
        }
    }

    //Method to validate if the user and password provided are correct
    private void validateUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //We retrieve the parameters of the form
        String usernameParam = request.getParameter("username");
        String passwordParam = request.getParameter("password");

        //We create the DTO object to be sent to the service layer
        User userDto = new User();
        userDto.setUsername(usernameParam);
        userDto.setPassword(passwordParam);

        //We check if the user and the password exist in the DB
        //We use the Users service
        UserService userService = UserServiceImpl.getInstance();
        boolean validUser = userService.existingUser(userDto);

        //If the user is valid, we redirect it to the case of listPeople
        if (validUser) {
            //We add the user to the session
            HttpSession session = request.getSession();
            session.setAttribute("username", userDto.getUsername());

            this.listPeople(request, response);
        } else {
            //If the user is not valid, we send it to the login page again
            request.setAttribute("message", "The user or password is incorrect");
            request.getRequestDispatcher("/WEB-INF/pages/sga/login.jsp").forward(request, response);
        }
    }

    private void exit(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //We removed the session from the server and redirected to the index page
        request.getSession().invalidate();
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }

    private void actionByDefault(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //Redirect to the home page
        String message = "Action not provided or unknown";
        request.setAttribute("message", message);
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }

    private void addPerson(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //We do not process any parameter, but only redirect to the view
        //to add a new person
        request.getRequestDispatcher("/WEB-INF/pages/sms/personDetail.jsp").forward(request, response);
    }

    private void editPerson(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String message = null;

        //we retrieve the identifier to be processed and send it back to the detail page
        String idPersonParam = request.getParameter("people");
        Integer idPerson = null;

        if (idPersonParam != null && !idPersonParam.trim().equals("")) {
            idPerson = new Integer(idPersonParam);

            //We use the person service to retrieve the object of the DB
            PersonService personService = PersonServiceImpl.getInstance();
            Person person = personService.getPersonById(idPerson);

            //we share the object obtained person, to be able to modify it
            request.setAttribute("person", person);
            request.getRequestDispatcher("/WEB-INF/pages/sms/personDetail.jsp").forward(request, response);

        } else {
            message = "You must select an item to Edit";
            request.setAttribute("message", message);
            //We reuse the case of listPeople
            this.listPeople(request, response);
        }

    }

     //This method allows us to insert or modify a person
    //The difference will be whether or not we receive a primary key from the form
    private void savePerson(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String message = null;

        //1. We process the parameters
        String idPersonParam = request.getParameter("idPerson");
        String firstNameParam = request.getParameter("firstName");
        String lastNameParam = request.getParameter("lastName");

        //We validate the PK
        Integer idPerson = null;
        if (idPersonParam != null && !idPersonParam.trim().equals("")) {
            idPerson = new Integer(idPersonParam);
        }

        //2. We use the Model object
        Person person = new Person();
        person.setIdPerson(idPerson); //If it did not come in the parameters, set it to null
        person.setFirstName(firstNameParam);
        person.setLastName(lastNameParam);

        //3. We use the service layer
        PersonService personService = PersonServiceImpl.getInstance();
        boolean savedElement = personService.savePerson(person);

        //4. We redirect depending on the result
        if (savedElement) {
            message = "the item has been saved correctly";
            request.setAttribute("message", message);

        } else {
            message = "The item has not been saved correctly";
            request.setAttribute("message", message);
        }

        //We reuse the case of listPeople
        request.setAttribute("message", message);
        this.listPeople(request, response);

    }

    private void deletePerson(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String message = null;

        //1. We process the parameters
        //We retrieve ALL the selected objects
        String[] idPersonParams = request.getParameterValues("people");
        List<Integer> idPeople = new ArrayList<>();

        //2. We use the objects of Model (Person)
        //We validate the parameters to be eliminated
        if (idPersonParams != null && idPersonParams.length > 0) {
            for (String person : idPersonParams) {
                idPeople.add(new Integer(person));
            }

            //3.We use the service layer to eliminate the objects
            PersonService personService = PersonServiceImpl.getInstance();
            boolean deletedRows = personService.deletePeople(idPeople);

            if (deletedRows) {
                message = "The records were successfully deleted";
            }
        } else {
            message = "You must select one or more items to Delete";
        }

        //4. Redirect to the list of people (you should no longer show the deleted records)
        request.setAttribute("message", message);
        this.listPeople(request, response);
    }

   
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "ControllerServlet";
    }
}