package sms.eis.dao;

import java.sql.Connection;
import sms.eis.dto.Person;
import sms.eis.dto.PersonPk;
import sms.eis.exceptions.PersonDaoException;

public interface PersonDao
{
	/** 
	 * Inserts a new row in the person table.
	 */
	public PersonPk insert(Person dto) throws PersonDaoException;

	/** 
	 * Updates a single row in the person table.
	 */
	public void update(PersonPk pk, Person dto) throws PersonDaoException;

	/** 
	 * Deletes a single row in the person table.
	 */
	public void delete(PersonPk pk) throws PersonDaoException;

	/** 
	 * Returns the rows from the person table that matches the specified primary-key value.
	 */
	public Person findByPrimaryKey(PersonPk pk) throws PersonDaoException;

	/** 
	 * Returns all rows from the person table that match the criteria 'id_person = :idPerson'.
	 */
	public Person findByPrimaryKey(Integer idPerson) throws PersonDaoException;

	/** 
	 * Returns all rows from the person table that match the criteria ''.
	 */
	public Person[] findAll() throws PersonDaoException;

	/** 
	 * Sets the value of maxRows
	 */
	public void setMaxRows(int maxRows);

	/** 
	 * Gets the value of maxRows
	 */
	public int getMaxRows();

	/** 
	 * Returns all rows from the person table that match the specified arbitrary SQL statement
	 */
	public Person[] findByDynamicSelect(String sql, Object[] sqlParams) throws PersonDaoException;

	/** 
	 * Returns all rows from the person table that match the specified arbitrary SQL statement
	 */
	public Person[] findByDynamicWhere(String sql, Object[] sqlParams) throws PersonDaoException;


  public Connection getUserConn();

  public void setUserConn(Connection userConn);
}
