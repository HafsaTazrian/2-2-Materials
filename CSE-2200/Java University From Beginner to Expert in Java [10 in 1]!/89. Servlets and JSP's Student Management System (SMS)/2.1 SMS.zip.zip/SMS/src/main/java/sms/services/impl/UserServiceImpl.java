package sms.services.impl;

import sms.eis.dao.UserDao;
import sms.eis.dto.User;
import sms.eis.exceptions.UserDaoException;
import sms.eis.factory.UserDaoFactory;
import sms.services.exceptions.BusinessException;
import sms.services.UserService;

/**
 *
 * @author Ubaldo
 */
public class UserServiceImpl implements UserService {

    //We use the singleton pattern, there is only one UserService object in Memory
    private static UserService userServiceInstance;

    //We create a userDao attribute to communicate with the data layer
    UserDao userDao;

    //Private Constructor without arguments, to implement the singleton pattern
    private UserServiceImpl() {
    }

    //We create a new and only instance if it does not exist
    public static UserService getInstance() {
        if (userServiceInstance == null) {
            userServiceInstance = new UserServiceImpl();
        }
        return userServiceInstance;
    }

    public boolean existingUser(User usuarioDto) {
        try {

            this.userDao = UserDaoFactory.create();

            //We search for the object by UserName and password
            final String SQL_WHERE = "username = ? and password = ?";

            Object[] sqlParams = {usuarioDto.getUsername(), usuarioDto.getPassword()};
            User[] users = this.userDao.findByDynamicWhere(SQL_WHERE, sqlParams);

            if (users.length > 0) {
                return true;
            }

        } catch (UserDaoException ex) {
            throw new BusinessException("There is a problem when getting the user in the BD", ex);
        }

        //In any other case, return false
        return false;
    }
}
