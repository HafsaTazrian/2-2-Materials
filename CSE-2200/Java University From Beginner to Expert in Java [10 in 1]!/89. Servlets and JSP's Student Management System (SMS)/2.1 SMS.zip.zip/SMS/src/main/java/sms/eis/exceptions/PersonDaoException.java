package sms.eis.exceptions;

public class PersonDaoException extends DaoException
{
	/**
	 * Method 'PersonDaoException'
	 * 
	 * @param message
	 */
	public PersonDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PersonDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PersonDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
