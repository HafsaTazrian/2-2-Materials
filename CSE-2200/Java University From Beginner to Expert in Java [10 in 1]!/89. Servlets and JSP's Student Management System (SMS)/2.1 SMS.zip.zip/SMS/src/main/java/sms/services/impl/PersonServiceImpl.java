package sms.services.impl;

import sms.services.exceptions.BusinessException;
import sms.eis.dao.PersonDao;
import sms.eis.dto.Person;
import sms.eis.dto.PersonPk;
import sms.eis.exceptions.PersonDaoException;
import sms.eis.factory.PersonDaoFactory;
import sms.eis.jdbc.ResourceManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import sms.services.PersonService;

/**
 *
 * @author Ubaldo
 */
public class PersonServiceImpl implements PersonService {

    //We use the singleton pattern, there is only one UserService type object in Memory
    private static PersonService personServiceInstance;
    //We create a personDao attribute to communicate with the data layer
    PersonDao personDao;

    //private Constructor without arguments, to implement the singleton pattern
    private PersonServiceImpl() {
    }

    //We create a new and only instance if it does not exist
    public static PersonService getInstance() {
        if (personServiceInstance == null) {
            personServiceInstance = new PersonServiceImpl();
        }
        return personServiceInstance;
    }

    public List<Person> getAllPeople() {
        try {
            this.personDao = PersonDaoFactory.create();
            return Arrays.asList(this.personDao.findAll());
        } catch (PersonDaoException ex) {
            throw new BusinessException("There is a problem getting the array of people in the DB", ex);
        }
    }

    public Person getPersonById(Integer idPerson) {
        try {
            return this.personDao.findByPrimaryKey(idPerson);
        } catch (PersonDaoException ex) {
            throw new BusinessException("There is a problem getting the person by id:" + idPerson, ex);
        }
    }

    //We make this transactional method, since it eliminates all or none
    //and could leave affected the state of the Database
    public boolean deletePeople(List<Integer> idPeople) {

        Connection conn = null;

        try {
            // We begin the transaction, if some element is not removed
            // then none is removed
            // We get a pool connection

            conn = ResourceManager.getConnection();
            // Activate transaction management
            conn.setAutoCommit(false);

            this.personDao.setUserConn(conn);
            //We have two possible options, create an SQL with the id's to be deleted
            //or delete record to record. We choose the second option
            for (Integer person : idPeople) {
                this.personDao.delete(new PersonPk(person));
            }

            // We keep the changes in the BD
            conn.commit();
            //We return the flag indicating that the records were deleted
            return true;

        } catch (PersonDaoException ex) {
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                throw new BusinessException("The status of the Database could not be restored", ex1);
            }
            throw new BusinessException("There is a problem to remove the elements: " + idPeople, ex);
        } catch (SQLException ex) {
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                throw new BusinessException("The status of the Database could not be restored", ex1);
            }
            throw new BusinessException("There is a problem with the Database", ex);
        } finally {
            // We closed the connection to return it to the pool
            ResourceManager.close(conn);
        }
    }

    //We make the transactional method, since the status of the Database may be affected
    public boolean savePerson(Person person) {
        Connection conn = null;

        try {
            //We start the transaction

            // We get a pool connection
            conn = ResourceManager.getConnection();
            // Activate transaction management
            conn.setAutoCommit(false);

            this.personDao.setUserConn(conn);

            //We check if it is an insert or an update, depending on whether or not the value of the PK is available
            if (person.getIdPerson() == null) {
                this.personDao.insert(person);
            } else {
                this.personDao.update(person.createPk(), person);
            }

            // We keep the changes in the BD
            conn.commit();
            //We return the flag indicating that the records were deleted
            return true;

        } catch (PersonDaoException ex) {
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                throw new BusinessException("The status of the Database could not be restored", ex1);
            }
            throw new BusinessException("I can not add the Person:" + person + " a la BD", ex);
        } catch (SQLException ex) {
            try {
                conn.rollback();
            } catch (SQLException ex1) {
                throw new BusinessException("The status of the Database could not be restored", ex1);
            }
            throw new BusinessException("There is a problem with the Database", ex);
        } finally {
            // We closed the connection to return it to the pool
            ResourceManager.close(conn);
        }
    }
}
