package sms.eis.dto;

import java.io.Serializable;

public class User implements Serializable
{
	/** 
	 * This attribute maps to the column id_user in the user table.
	 */
	protected Integer idUser;

	/** 
	 * This attribute maps to the column id_person in the user table.
	 */
	protected Integer idPerson;

	/** 
	 * This attribute maps to the column username in the user table.
	 */
	protected String username;

	/** 
	 * This attribute maps to the column password in the user table.
	 */
	protected String password;

	/**
	 * Method 'User'
	 * 
	 */
	public User()
	{
	}

	/**
	 * Method 'getIdUser'
	 * 
	 * @return Integer
	 */
	public Integer getIdUser()
	{
		return idUser;
	}

	/**
	 * Method 'setIdUser'
	 * 
	 * @param idUser
	 */
	public void setIdUser(Integer idUser)
	{
		this.idUser = idUser;
	}

	/**
	 * Method 'getIdPerson'
	 * 
	 * @return Integer
	 */
	public Integer getIdPerson()
	{
		return idPerson;
	}

	/**
	 * Method 'setIdPerson'
	 * 
	 * @param idPerson
	 */
	public void setIdPerson(Integer idPerson)
	{
		this.idPerson = idPerson;
	}

	/**
	 * Method 'getUsername'
	 * 
	 * @return String
	 */
	public String getUsername()
	{
		return username;
	}

	/**
	 * Method 'setUsername'
	 * 
	 * @param username
	 */
	public void setUsername(String username)
	{
		this.username = username;
	}

	/**
	 * Method 'getPassword'
	 * 
	 * @return String
	 */
	public String getPassword()
	{
		return password;
	}

	/**
	 * Method 'setPassword'
	 * 
	 * @param password
	 */
	public void setPassword(String password)
	{
		this.password = password;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof User)) {
			return false;
		}
		
		final User _cast = (User) _other;
		if (idUser == null ? _cast.idUser != idUser : !idUser.equals(_cast.idUser )) {
			return false;
		}
		
		if (idPerson == null ? _cast.idPerson != idPerson : !idPerson.equals(_cast.idPerson )) {
			return false;
		}
		
		if (username == null ? _cast.username != username : !username.equals( _cast.username )) {
			return false;
		}
		
		if (password == null ? _cast.password != password : !password.equals( _cast.password )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (idUser != null) {
			_hashCode = 29 * _hashCode + idUser.hashCode();
		}
		
		if (idPerson != null) {
			_hashCode = 29 * _hashCode + idPerson.hashCode();
		}
		
		if (username != null) {
			_hashCode = 29 * _hashCode + username.hashCode();
		}
		
		if (password != null) {
			_hashCode = 29 * _hashCode + password.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return UserPk
	 */
	public UserPk createPk()
	{
		return new UserPk(idUser);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
        @Override
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "ap.eis.dto.User: " );
		ret.append("idUser=" + idUser );
		ret.append(", idPerson=" + idPerson );
		ret.append( ", username=" + username );
		ret.append( ", password=" + password );
		return ret.toString();
	}

}
