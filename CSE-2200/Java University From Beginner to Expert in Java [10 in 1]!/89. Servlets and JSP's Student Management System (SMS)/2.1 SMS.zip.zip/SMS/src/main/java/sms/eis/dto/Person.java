package sms.eis.dto;

import java.io.Serializable;

public class Person implements Serializable
{
	/** 
	 * This attribute maps to the column id_person in the person table.
	 */
	protected Integer idPerson;

	/** 
	 * This attribute maps to the column firstName in the person table.
	 */
	protected String firstName;

	/** 
	 * This attribute maps to the column lastName in the person table.
	 */
	protected String lastName;

	/**
	 * Method 'Person'
	 * 
	 */
	public Person()
	{
	}

	/**
	 * Method 'getIdPerson'
	 * 
	 * @return Integer
	 */
	public Integer getIdPerson()
	{
		return idPerson;
	}

	/**
	 * Method 'setIdPerson'
	 * 
	 * @param idPerson
	 */
	public void setIdPerson(Integer idPerson)
	{
		this.idPerson = idPerson;
	}

	/**
	 * Method 'getFirstName'
	 * 
	 * @return String
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * Method 'setFirstName'
	 * 
	 * @param firstName
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * Method 'getLastName'
	 * 
	 * @return String
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * Method 'setLastName'
	 * 
	 * @param lastName
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof Person)) {
			return false;
		}
		
		final Person _cast = (Person) _other;
		if (idPerson == null ? _cast.idPerson != idPerson : !idPerson.equals(_cast.idPerson )) {
			return false;
		}
		
		if (firstName == null ? _cast.firstName != firstName : !firstName.equals(_cast.firstName )) {
			return false;
		}
		
		if (lastName == null ? _cast.lastName != lastName : !lastName.equals(_cast.lastName )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (idPerson != null) {
			_hashCode = 29 * _hashCode + idPerson.hashCode();
		}
		
		if (firstName != null) {
			_hashCode = 29 * _hashCode + firstName.hashCode();
		}
		
		if (lastName != null) {
			_hashCode = 29 * _hashCode + lastName.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return PersonPk
	 */
	public PersonPk createPk()
	{
		return new PersonPk(idPerson);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "ap.eis.dto.Person: " );
		ret.append("idPerson=" + idPerson );
		ret.append(", firstName=" + firstName );
		ret.append(", lastName=" + lastName );
		return ret.toString();
	}

}
