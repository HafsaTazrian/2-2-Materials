package sms.eis.dao;

import sms.eis.dto.User;
import sms.eis.dto.UserPk;
import sms.eis.exceptions.UserDaoException;

public interface UserDao
{
	/** 
	 * Inserts a new row in the user table.
	 */
	public UserPk insert(User dto) throws UserDaoException;

	/** 
	 * Updates a single row in the user table.
	 */
	public void update(UserPk pk, User dto) throws UserDaoException;

	/** 
	 * Deletes a single row in the user table.
	 */
	public void delete(UserPk pk) throws UserDaoException;

	/** 
	 * Returns the rows from the user table that matches the specified primary-key value.
	 */
	public User findByPrimaryKey(UserPk pk) throws UserDaoException;

	/** 
	 * Returns all rows from the user table that match the criteria 'id_user = :idUser'.
	 */
	public User findByPrimaryKey(Integer idUser) throws UserDaoException;

	/** 
	 * Returns all rows from the user table that match the criteria ''.
	 */
	public User[] findAll() throws UserDaoException;

	/** 
	 * Returns all rows from the user table that match the criteria 'id_person = :idPerson'.
	 */
	public User[] findByPerson(Integer idPerson) throws UserDaoException;

	/** 
	 * Sets the value of maxRows
	 */
	public void setMaxRows(int maxRows);

	/** 
	 * Gets the value of maxRows
	 */
	public int getMaxRows();

	/** 
	 * Returns all rows from the user table that match the specified arbitrary SQL statement
	 */
	public User[] findByDynamicSelect(String sql, Object[] sqlParams) throws UserDaoException;

	/** 
	 * Returns all rows from the user table that match the specified arbitrary SQL statement
	 */
	public User[] findByDynamicWhere(String sql, Object[] sqlParams) throws UserDaoException;

}
