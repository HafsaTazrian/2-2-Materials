package data;

import domain.Person;
import java.util.List;
import javax.persistence.*;
import org.springframework.stereotype.Repository;
import org.apache.logging.log4j.*;
import javax.persistence.Query;

@Repository
public class PersonDaoImpl implements PersonDao {

    Logger log = LogManager.getRootLogger();

    @PersistenceContext
    private EntityManager em;

    @Override
    public void insertPerson(Person person) {
        em.persist(person);
    }

    @Override
    public void updatePerson(Person person) {
        em.merge(person);
    }

    @Override
    public void deletePerson(Person person) {
         em.remove(em.merge(person));
    }

    @Override
    public Person findPersonById(int idPerson) {
        return em.find(Person.class, idPerson);
    }

    @Override
    public List<Person> findAllPeople() {
        String jpql = "SELECT p FROM Person p";
        Query query = em.createQuery(jpql);
        return query.getResultList();
    }

    @Override
    public long countPeople() {
        String consulta = "select count(p) from Person p";
        Query q = em.createQuery(consulta);
        return (long) q.getSingleResult();
    }
}