package web;

import domain.Person;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;
import org.primefaces.event.RowEditEvent;
import service.PersonService;

@Named
@RequestScoped
public class PersonBean {

    @Inject
    private PersonService personService;

    private Person selectedPerson;

    List<Person> people;

    public PersonBean() {
    }

    @PostConstruct
    public void init() {
        //We start the variables
        people = personService.listPeople();
        selectedPerson = new Person();
    }

    public void editListener(RowEditEvent event) {
        Person person = (Person) event.getObject();
        personService.modifyPerson(person);
    }

    public List<Person> getPeople() {
        return people;
    }

    public void setPeople(List<Person> people) {
        this.people = people;
    }

    public Person getSelectedPerson() {
        return selectedPerson;
    }

    public void setSelectedPerson(Person selectedPerson) {
        this.selectedPerson = selectedPerson;
    }

    public void restartSelectedPerson() {
        this.selectedPerson = new Person();
    }

    public void addPerson() {
        personService.addPerson(this.selectedPerson);
        //We also add it to the view (refresh the Model)
        this.people.add(this.selectedPerson);
        this.selectedPerson = null;
    }

    public void deletePerson() {
        personService.deletePerson(this.selectedPerson);
        //We also eliminate it from the view (refresh the Model)
        people.remove(this.selectedPerson);
        this.selectedPerson = null;
    }
}
