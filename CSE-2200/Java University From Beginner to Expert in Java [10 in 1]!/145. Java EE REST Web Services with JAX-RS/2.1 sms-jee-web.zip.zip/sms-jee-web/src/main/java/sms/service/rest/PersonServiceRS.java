package sms.service.rest;

import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.ws.rs.core.Response.Status;
import sms.domain.Person;
import sms.service.PersonService;

@Path("/people")
@Stateless
public class PersonServiceRS {

    @Inject
    private PersonService personService;
    
    @GET
    @Produces(value={MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> listPeople() {
        return personService.listPeople();
    }

    @GET
    @Produces(value={MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Path("{id}") //refers to /people/{id} 
    public Person findPerson(@PathParam("id") int id) {
        return personService.findPerson(new Person(id));
    }

    @POST
    @Consumes(value={MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Produces(value={MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response addPerson(Person person) {
        try {
            personService.addPerson(person);
            return Response.ok().entity(person).build();
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PUT
    @Consumes(value={MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Produces(value={MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    @Path("{id}")
    public Response modifyPerson(@PathParam("id") int id, Person modifiedPerson) {
        try {
            Person person = personService.findPerson(new Person(id));
            if (person != null) {
                personService.modifyPerson(modifiedPerson);
                return Response.ok().entity(modifiedPerson).build();
            } else {
                return Response.status(Status.NOT_FOUND).build();
            }
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DELETE
    @Path("{id}")
    public Response deletePerson(@PathParam("id") int id) {
        try {
            personService.deletePerson(new Person(id));
            return Response.ok().build();
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage());
            return Response.status(404).build();
        }
    }
}