function display(category){
  var menu = document.getElementById(category);
  if(menu.className == "show_menu"){
    menu.className = "hide_menu";
  }
  else{
    menu.className = "show_menu";
  }
}
