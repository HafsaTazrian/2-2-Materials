package test;

import java.util.List;
import javax.persistence.*;
import sms.domain.Person;
import org.apache.logging.log4j.*;

public class ClientEntityPerson {

    static Logger log = LogManager.getRootLogger();

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("PersonPU");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        //Transaction begins
        tx.begin();
        //The ID must not be specified, since it is generated automatically
        Person person1 = new Person();
        person1.setName("Maria");
        log.debug("Object to persist:" + person1);
        //Persist the object
        em.persist(person1);
        
        //Read all entities
        Query query = em.createQuery("select p from Person p");
        List<Person> people = query.getResultList();
        for(Person person : people){
            log.info(person);
        }
        
        //End of transaction
        tx.commit();
        log.debug("Persisted Object:" + person1);
        em.close();
    }
}
