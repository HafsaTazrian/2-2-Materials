package test;

import data.JConnection;
import java.sql.*;

public class MetadataTest {

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = JConnection.getConnection();

            //General Metadata information
            DatabaseMetaData dmd = conn.getMetaData();
            System.out.println("Database Name:" + dmd.getDatabaseProductName());
            System.out.println("Driver version:" + dmd.getDriverVersion());
            System.out.println("Max rows size:" + dmd.getMaxRowSize());

            //More specific metadata information from the person table 
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM person");
            //Ask for more specific metadata information
            ResultSetMetaData rsMetaData = rs.getMetaData();
            // We ask how many columns does the person table have
            int numberOfColumns = rsMetaData.getColumnCount();
            //Display the number of columns of person table
            System.out.println("\nNumber of columns of person table:" + numberOfColumns);

            for (int i = 1; i <= numberOfColumns; i++) {
                System.out.print("column: " + i);
                System.out.print(" , name: " + rsMetaData.getColumnName(i));
                System.out.print(" , type: " + rsMetaData.getColumnTypeName(i));
                System.out.print(" , table: " + rsMetaData.getTableName(i));
                System.out.print(" , autoincrementable: " + rsMetaData.isAutoIncrement(i));
                System.out.print(" , database: " + rsMetaData.getCatalogName(i));
                System.out.println("");
            }
        } catch (SQLException e) {
            e.printStackTrace(System.out);
        } finally {
            JConnection.close(conn);
        }
    }
}
