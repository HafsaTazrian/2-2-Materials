package controller;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.Rectangle;

@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.In this case there is no need to process parameters

        //2. create the model using the JavaBean
        Rectangle rec = new Rectangle(3, 6);
        //3. add the variables in a certain scope
        request.setAttribute("message", "Greetings from the servlet");

        HttpSession session = request.getSession();
        session.setAttribute("rectangle", rec);
        //4. redirect
        RequestDispatcher rd = request.getRequestDispatcher("view/showVariables.jsp");
        //The request and response objects are propagated
        // so they can be used by the selected JSP
        rd.forward(request, response);
        // You do not need to do anything more after the
        // redirect, since the flow continues with the JSP
    }
}
