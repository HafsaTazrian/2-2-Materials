package beans.domain;

public class City {

    private long cityId;
    private String name;
    private long zipCode;

    public City(long cityId, String name, long zipCode) {
        this.cityId = cityId;
        this.name = name;
        this.zipCode = zipCode;
    }

    public long getCityId() {
        return cityId;
    }

    public void setCityId(long cityId) {
        this.cityId = cityId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getZipCode() {
        return zipCode;
    }

    public void setZipCode(long zipCode) {
        this.zipCode = zipCode;
    }
}