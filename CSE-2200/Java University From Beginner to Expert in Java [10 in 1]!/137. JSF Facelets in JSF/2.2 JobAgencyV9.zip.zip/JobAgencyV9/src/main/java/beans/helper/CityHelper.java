package beans.helper;

import beans.domain.City;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.model.SelectItem;


@Named
@RequestScoped
public class CityHelper {

    public long getCityIdByName(String cityName) {
        long cityId = 0;
        List<City> cities = getCities();
        for (City city : cities) {
            if (city.getName().equals(cityName)) {
                cityId = city.getCityId();
                break;
            }
        }
        return cityId;
    }

    public long getCityIdByZipCode(long zipCode) {
        long cityId = 0;
        List<City> citys = getCities();
        for (City city : citys) {
            if (city.getZipCode() == zipCode) {
                cityId = city.getCityId();
                break;
            }
        }
        return cityId;
    }

    public List<SelectItem> getSelectItems() {
        List<SelectItem> selectItems;
        selectItems = new ArrayList<>();
        List<City> cities = getCities();
        for (City city : cities) {
            SelectItem selectItem = new SelectItem(city.getCityId(),
                    city.getName());
            selectItems.add(selectItem);
        }
        return selectItems;
    }

    public List<City> getCities() {
        List<City> citys = new ArrayList<>();
        long cityId = 1;
        City city = new City(cityId++, "Phoenix", 85001);
        citys.add(city);
        city = new City(cityId++, "Little Rock", 72201);
        citys.add(city);
        city = new City(cityId++, "Huntsville", 35801);
        citys.add(city);
        return citys;
    }
}
