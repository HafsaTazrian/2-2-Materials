package generics;

//We define a generic class with the diamond operator <>
public class GenericClass<T>{

    //We define a variable of generic type
    T object;

    //Constructor that initializes the type to be used
    public GenericClass(T object) {
        this.object = object;
    }

    public void getType() {
        System.out.println("The type T is: " + object.getClass().getName());
    }
}