package web;

import org.apache.logging.log4j.*;

public class HelloWorldAction {
    
    Logger log = LogManager.getLogger(HelloWorldAction.class);
    
    private String greetings;
    
    public String execute(){
        log.info("Struts 2 execute method");
        setGreetings("Hello from Struts2");
        return "success";
    }

    public String getGreetings() {
        return greetings;
    }

    public void setGreetings(String greetings) {
        this.greetings = greetings;
    }
}
