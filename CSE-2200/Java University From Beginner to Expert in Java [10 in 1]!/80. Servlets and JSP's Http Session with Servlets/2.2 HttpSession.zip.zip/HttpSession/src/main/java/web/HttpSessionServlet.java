package web;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/HttpSessionServlet")
public class HttpSessionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        HttpSession session = request.getSession();
        String title = null;

        //We ask for the attribute, and verify if it exists
        Integer visitCounter = (Integer) session.getAttribute("visitCounter");

        //If it is equal to null, it means that it is the first
        //time that we access the resource
        if (visitCounter == null) {
            visitCounter = 1;
            title = "Welcome for the first time...";
        } else {
            //if it is different from null, we increase the counter
            title = "Welcome again...";
            visitCounter += 1;
        }

        //In any case, we add the value of the counter
        //to the session
        session.setAttribute("visitCounter", visitCounter);

        //We show the values in the client
        PrintWriter out = response.getWriter();
        out.println("Title: " + title);
        out.println("<br>");
        out.println("Number of Accesses to the resource: " + visitCounter);
        out.println("<br>");
        out.println("ID's session: " + session.getId());
    }
}
