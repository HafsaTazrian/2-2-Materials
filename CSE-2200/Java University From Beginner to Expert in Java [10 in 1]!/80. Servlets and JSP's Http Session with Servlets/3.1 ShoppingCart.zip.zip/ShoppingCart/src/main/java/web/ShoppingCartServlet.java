package web;

import java.io.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ShoppingCartServlet")
public class ShoppingCartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        //We process the new article
        String newItem = request.getParameter("item");

        //We create or recover the http session
        HttpSession session = request.getSession();

        //We retrieve the list of previous articles
        //if they exist in the session
        List<String> items = (List<String>) session.getAttribute("items");

        //verify if the list of articles exists
        if (items == null) {
            //If they do not exist, we initialize the list
            //and we add it to the session
            items = new ArrayList<>();
            session.setAttribute("items", items);
        }

        //We already have the list of items ready to work
        //We add the new item
        //and we add it by reference to the list of items
        if (newItem != null && !newItem.trim().equals("")) {
            items.add(newItem);
        }
        try (PrintWriter out = response.getWriter()) {
            //We show the total items to the customer
            out.println("<h1>List of Items</h1>");
            out.println("<br>");

            //We iterate all the articles, including the new
            for (String item : items) {
                out.print("<LI>" + item + "</LI>");
            }

            //We add a link to return to the beginning
            out.println("<br>");
            out.println("<a href='/ShoppingCart'>Return</a>");
            out.close();
        }
    }
}