package test;

import java.util.*;
import javax.persistence.*;
import model.*;

public class TestHqlJpql {

    public static void main(String[] args) {
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("HibernateJpaPU");
        EntityManager em = fabrica.createEntityManager();

        //Auxiliary variables to execute the queries
        String queryString = null;
        Query query = null;
        List<Student> students = null;
        Student student = null;
        Iterator iter = null;
        Object[] tuple = null;

        //Query 1
        System.out.println("\nQuery 1");
        queryString = "from Student a";
        query = em.createQuery(queryString);
        students = query.getResultList();
        //We print to all Student-type objects
        for (Student s : students) {
            System.out.println(s);
        }

        //Query2
        System.out.println("\nQuery 2");
        queryString = "from Student s where s.idStudent = 2";
        query = em.createQuery(queryString);
        student = (Student) query.getSingleResult();
        System.out.println(student);

        //Query 3
        System.out.println("\nQuery 3");
        queryString = "from Student s where s.name = 'Charly'";
        query = em.createQuery(queryString);
        students = query.getResultList();
        for (Student s : students) {
            System.out.println(s);
        }

        //Query 4
        //Each tuple is returned as an array of objects
        System.out.println("\nQuery 4");
        queryString = "select a.streetName, a.streetNumber, a.country from Address a";
        query = em.createQuery(queryString);
        iter = query.getResultList().iterator();
        while (iter.hasNext()) {
            tuple = (Object[]) iter.next();
            String streetName = (String) tuple[0];
            String streetNumber = (String) tuple[1];
            String country = (String) tuple[2];
            System.out.println(streetName + " " + streetNumber + " " + country);
        }

        //Query 5
        //Each tuple is returned as an array of objects
        System.out.println("\nQuery 5");
        queryString = "select s, s.idStudent from Student s";
        query = em.createQuery(queryString);
        iter = query.getResultList().iterator();
        while (iter.hasNext()) {
            tuple = (Object[]) iter.next();
            student = (Student) tuple[0];
            Integer idStudent = (Integer) tuple[1];
            System.out.println("idStudent:" + idStudent);
            System.out.println("Student Object:" + student);
        }

        //Query 6
        System.out.println("\nQuery 6");
        queryString = "select new Student(s.idStudent) from Student s";
        query = em.createQuery(queryString);
        students = query.getResultList();
        for (Student s : students) {
            System.out.println(s);
        }

        //Query 7
        //Returns the minimum and maximum value of the idStudent (scalar result)
        System.out.println("\nQuery 7");
        queryString = "select min(s.idStudent), max(s.idStudent), count(s) from Student s";
        query = em.createQuery(queryString);
        iter = query.getResultList().iterator();
        while (iter.hasNext()) {
            tuple = (Object[]) iter.next();
            Integer idMin = (Integer) tuple[0];
            Integer idMax = (Integer) tuple[1];
            Long count = (Long) tuple[2];
            System.out.println("idMin:" + idMin + ", idMax:" + idMax + ", count:" + count);
        }

        //Query 8
        //Get the student object with id equal to the parameter
        System.out.println("\nQuery 8");
        queryString = "from Student s where s.idStudent = :id";
        query = em.createQuery(queryString);
        query.setParameter("id", 1);
        student = (Student) query.getSingleResult();
        System.out.println(student);

        //Query 9
        //Get students that contain a letter a, regardless of masuculas or lowercase
        System.out.println("\nQuery 9");
        String likeString = "%A%"; //like is used in the query
        queryString = "from Student s where upper(s.name) like upper(:param1)";
        query = em.createQuery(queryString);
        query.setParameter("param1", likeString);
        students = query.getResultList();
        for (Student s : students) {
            System.out.println(s);
        }

        //Query 10
        System.out.println("\nQuery 10");
        queryString = "from Student s join s.address a";
        query = em.createQuery(queryString);
        iter = query.getResultList().iterator();
        while (iter.hasNext()) {
            tuple = (Object[]) iter.next();
            student = (Student) tuple[0];
            Address address = (Address) tuple[1];
            System.out.println();
            System.out.println("Student:" + student);
            System.out.println("Address:" + address);
        }

        //Query 11
        System.out.println("\nQuery 11");
        queryString = "from Student s join fetch s.address a";
        query = em.createQuery(queryString);
        students = query.getResultList();
        for (Student s : students) {
            System.out.println();
            System.out.println("Student:" + s);
            System.out.println("Address:" + s.getAddress());
        }
    }
}
