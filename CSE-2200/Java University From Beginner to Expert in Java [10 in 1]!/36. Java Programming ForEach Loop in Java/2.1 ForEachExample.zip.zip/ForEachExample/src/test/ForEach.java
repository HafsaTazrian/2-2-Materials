package test;

public class ForEach {

    public static void main(String[] args) {

        //Create an array of Person type
        Person[] people = {new Person("John"), new Person("Katy")};

        //Iterate each elemento of the Person array
        for (Person p : people) {
            //We access the attributes and / or methods of the object
            int personId = p.getPersonId();
            String name = p.getName();
            System.out.println("Person id:" + personId + ", name: " + name);

        }

        System.out.println("");
        //Array of integers
        int[] ages = {15, 20, 41, 50};
        //Iterate the array
        for (int age : ages) {
            System.out.println("Age :" + age);
        }
    }
}
