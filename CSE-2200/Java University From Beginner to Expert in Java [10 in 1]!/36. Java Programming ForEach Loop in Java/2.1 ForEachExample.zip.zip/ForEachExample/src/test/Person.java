package test;

public class Person {
    
    private final int personId;
    private String name;

    private static int peopleCounter;
    
    Person(String name){
        personId = ++peopleCounter;
        this.name = name;
    }
    
     public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public int getPersonId(){
        return this.personId;
    }
}
