package test;

public class MatrixExampleTest2 {

    public static void main(String[] args) {

        //1. Matrix of type String, simplified notation
        String names[][] = {{"Linda", "John", "Peter"}, {"Samantha", "Rita", "Charly"}};

        //Length of elements of the matrix. First the no. of lines
        System.out.println("Matrix row lenght:" + names.length);
        //Selecting a valid line returns us the no. of columns
        System.out.println("Matrix columns length:" + names[0].length);

        //Print the values to the standard output
        //2. Iterate the String matrix with a nested for
        for (int i = 0; i < names.length; i++) {
            for (int j = 0; j < names[i].length; j++) {
                System.out.println("Matrix of Strings, index : " + i + "-" + j + " : " + names[i][j]);
            }
        }
    }
}
