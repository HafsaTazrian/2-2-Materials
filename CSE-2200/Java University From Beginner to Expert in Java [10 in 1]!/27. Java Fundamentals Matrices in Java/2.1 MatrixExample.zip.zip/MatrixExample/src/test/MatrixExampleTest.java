package test;

public class MatrixExampleTest {
    
    public static void main(String[] args) {
        //1. Declare a matrix of integers
        int ages[][];
        //2. instantiate a matrix of integers
        ages = new int[3][2];
        //3. Initialize the values of the matrix of integers
        ages[0][0] = 30;
        ages[0][1] = 15;
        ages[1][0] = 20;
        ages[1][1] = 45;
        ages[2][0] = 5;
        ages[2][1] = 38;

        //Print the values to the standard output
        //4. Read the values of each element of the matrix
        System.out.println("Matrix of integers, index 0-0: " + ages[0][0]);
        System.out.println("Matrix of integers, index 1-0: " + ages[1][0]);
        System.out.println("Matrix of integers, index 1-1: " + ages[1][1]);
        System.out.println("Matrix of integers, index 2-0: " + ages[2][0]);
        System.out.println("Matrix of integers, index 2-1: " + ages[2][1]);      
    }
}

