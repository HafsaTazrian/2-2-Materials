package web.actions;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.*;

public class LoginAction extends ActionSupport {

    private String user;
    private String password;

    Logger log = LogManager.getLogger(LoginAction.class);

    @Override
    public String execute() {
        //If it is valid user we show the welcome page.jsp
        if ("admin".equals(this.user)) {
            return SUCCESS;
        } else {
            //If it is user NOT valid, we return to the login
            return INPUT;
        }
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

}