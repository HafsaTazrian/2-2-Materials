package test;

public class PolymorphismExample {
    
    public static void main(String[] args) {

        Employee emp = new Employee("John", 1000);
        printDetails(emp);

        Manager ger = new Manager("Katty", 2000, "Finance");
        printDetails(ger);
    }

    //We note that the type that receives the method is a parent type (Employee)
    //However at the time of executing the method, the one of the son (Manager) is executed
    //that is the polymorphism, multiple forms but in time of execution
    public static void printDetails(Employee emp) {
        System.out.println(emp.getDetails());
    }
}
