package test;

public class Manager extends Employee {

    private String department;

    public Manager(String name, double salary, String department) {
        super(name, salary);
        this.department = department;
    }

    //Override the inherited parent method
    public String getDetails() {
        //In order not to repeat the code, we can use parent method
        //and concatenate the child attribute to complete the information
        return super.getDetails() + ", department: " + department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
