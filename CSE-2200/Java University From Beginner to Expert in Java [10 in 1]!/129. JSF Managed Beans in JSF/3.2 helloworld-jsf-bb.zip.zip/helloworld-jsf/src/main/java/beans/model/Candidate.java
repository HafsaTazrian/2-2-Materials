package beans.model;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

@Named
@RequestScoped
public class Candidate {

  private String name = "Introduce your name";

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

}
