package beans.backing;

import beans.model.Candidate;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;

@Named
@RequestScoped
public class VacantForm {

  @Inject
  private Candidate candidate;

  public void setCandidate(Candidate candidate) {
    this.candidate = candidate;
  }

  public String send() {
    if (this.candidate.getName().equals("John")) {
      return "success";
    } else {
      return "failure";
    }
  }
}
