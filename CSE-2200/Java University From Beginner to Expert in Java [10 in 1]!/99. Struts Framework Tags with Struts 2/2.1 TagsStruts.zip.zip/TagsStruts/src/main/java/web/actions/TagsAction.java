package web.actions;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.*;

public class TagsAction extends ActionSupport {

    Logger log = LogManager.getLogger(TagsAction.class);

    private String name;

    @Override
    public String execute() {
        log.info("Name value:" + name);
        return SUCCESS;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
