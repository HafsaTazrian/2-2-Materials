package test;

public class Person {
    String firstName;
    
    public String getFirstName(){
        return firstName;
    }
    
    public void setFirstName(String argFirstName){
        firstName = argFirstName;
    }
}
