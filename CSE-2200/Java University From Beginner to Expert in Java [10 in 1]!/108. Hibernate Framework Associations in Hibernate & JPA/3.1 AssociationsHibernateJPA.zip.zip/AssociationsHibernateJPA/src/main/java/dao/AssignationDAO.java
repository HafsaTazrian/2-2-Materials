package dao;

import static dao.GenericDAO.em;
import java.util.List;
import javax.persistence.Query;
import model.Assignation;

public class AssignationDAO extends GenericDAO{
    
      public List<Assignation> list() {
        String hql = "SELECT a FROM Assignation a";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<Assignation> list = query.getResultList();
        for(Assignation a : list){
            System.out.println(a);
        }
        return list; 
    }

    public void insert(Assignation assignation) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(assignation);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error inserting object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void update(Assignation assignation) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(assignation);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error updating object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void delete(Assignation assignation) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.remove(em.merge(assignation));
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error removing object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public Assignation findById(Assignation assignation) {
        em = getEntityManager();
        return em.find(Assignation.class, assignation.getIdAssignation());
    }
}