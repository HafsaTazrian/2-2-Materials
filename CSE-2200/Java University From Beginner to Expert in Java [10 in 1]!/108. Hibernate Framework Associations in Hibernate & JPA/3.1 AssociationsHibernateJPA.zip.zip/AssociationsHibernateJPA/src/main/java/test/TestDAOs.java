package test;

import dao.*;
import java.util.Date;
import model.*;

public class TestDAOs {

    public static void main(String[] args) {

        AddressDAO addressDao = new AddressDAO();
        StudentDAO studentDao = new StudentDAO();
        UserDAO userDao = new UserDAO();
        CourseDAO courseDao = new CourseDAO();
        AssignationDAO assignationDao = new AssignationDAO();
        
        //Insert Address object
        Address address = new Address();
        address.setStreetName("Estrella");
        address.setStreetNumber("109");
        address.setCountry("Mexico");
        addressDao.insert(address);

        //Insert User object
        User user = new User();
        user.setUsername("john");
        user.setPassword("1234");
        userDao.insert(user);
        
        //Insert Student Object
        Student student = new Student();
        student.setName("Jhon Smith");
        student.setUser(user);
        student.setAddress(address);
        studentDao.insert(student);

        //Insert Course Object
        Course course = new Course();
        course.setName("Java Fundamentals");
        course.setPrice(1000F);
        course.setSchedule("Morning");
        courseDao.insert(course);
        
        //Insert Assignation Object
        Assignation assignation = new Assignation();
        assignation.setStudent(student);
        assignation.setCourse(course);
        assignation.setStartDate(new Date());
        assignation.setFinishDate(new Date());
        assignationDao.insert(assignation);
        
        //List all objects
        addressDao.list();
        userDao.list();
        studentDao.list();
        courseDao.list();
        assignationDao.list();
    }
}
