package dao;

import static dao.GenericDAO.em;
import java.util.List;
import javax.persistence.Query;
import model.Student;

public class StudentDAO extends GenericDAO{
    
      public List<Student> list() {
        String hql = "SELECT s FROM Student s";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<Student> list = query.getResultList();
        for(Student s : list){
            System.out.println(s);
        }
        return list; 
    }

    public void insert(Student student) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(student);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error inserting object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void update(Student student) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(student);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error updating object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void delete(Student student) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.remove(em.merge(student));
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error removing object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public Student findById(Student student) {
        em = getEntityManager();
        return em.find(Student.class, student.getIdStudent());
    }
}