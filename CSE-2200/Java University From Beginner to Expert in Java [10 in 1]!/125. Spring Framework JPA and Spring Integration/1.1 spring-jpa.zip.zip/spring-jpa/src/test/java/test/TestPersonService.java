package test;

import domain.Person;
import java.util.List;
import org.apache.logging.log4j.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import service.PersonService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class TestPersonService {

    private final Logger logger = LogManager.getRootLogger();

    @Autowired
    private PersonService personService;

    @Test
    public void testShoudShowPeople() {
        try {
            System.out.println();
            logger.info("Start of test testTransactions");
            logger.info("List People:");
            this.displayPeople();
            logger.info("End of test testTransactions");
            System.out.println();
        } catch (Exception e) {
            logger.error("Error Service: ", e);
        }
    }

    private int displayPeople() {
        List<Person> persons = personService.listPeople();
        int counPeople = 0;
        for (Person person : persons) {
            logger.info("Person: " + person);
            counPeople++;
        }
        return counPeople;
    }
}
