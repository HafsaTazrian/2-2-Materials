package test;

import data.PersonDao;
import domain.Person;
import java.util.List;
import org.apache.logging.log4j.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class TestPersonDaoImpl {

    private final Logger logger = LogManager.getRootLogger();

    @Autowired
    private PersonDao personDao;

    @Test
    public void shouldShowPeople() {
        try {
            System.out.println();
            logger.info("Start of the test shouldShowPeople");

            List<Person> people = personDao.findAllPeople();

            int peopleCounter = 0;
            for (Person person : people) {
                logger.info("Person: " + person);
                peopleCounter++;
            }

            //According to the number of people recovered, it should be the same as the table
            assertEquals(peopleCounter, personDao.countPeople());

            logger.info("End of the test shouldShowPeople");
        } catch (Exception e) {
            logger.error("Error JBDC", e);
        }
    }
}
