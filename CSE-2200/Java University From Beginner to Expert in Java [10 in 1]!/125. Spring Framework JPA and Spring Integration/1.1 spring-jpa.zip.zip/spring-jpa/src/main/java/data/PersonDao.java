package data;

import domain.Person;
import java.util.List;

public interface PersonDao {

    void insertPerson(Person person);

    void updatePerson(Person person);

    void deletePerson(Person person);

    Person findPersonById(int idPerson);

    List<Person> findAllPeople();

    long countPeople();
}