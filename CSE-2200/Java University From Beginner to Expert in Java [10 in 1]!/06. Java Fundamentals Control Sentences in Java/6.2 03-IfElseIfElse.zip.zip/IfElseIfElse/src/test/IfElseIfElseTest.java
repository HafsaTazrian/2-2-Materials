package test;

public class IfElseIfElseTest {

    public static void main(String[] args) {
        //If/ElseIf/Else Example
        int x = 30;
        if (x == 10) {
            System.out.print("X equals to 10\n");
        } else if (x == 20) {
            System.out.print("X equals to 20\n");
        } else if (x == 30) {
            System.out.print("X equals to 30\n");
        } else {
            System.out.print("X is not equal to 10, 20 or 30\n");
        }
    }
}
