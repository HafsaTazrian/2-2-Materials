package test;

public class IfElseTest {

    public static void main(String[] args) {
        //If-Else Example
        int x = 30;
        if (x < 20) {
            System.out.print("X less than 20\n");
        } else {
            System.out.print("X greater than 20\n");
        }
    }
}
