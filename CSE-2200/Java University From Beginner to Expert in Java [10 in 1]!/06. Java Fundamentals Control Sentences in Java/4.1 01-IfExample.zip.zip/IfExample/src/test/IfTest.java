package test;

public class IfTest {

    public static void main(String[] args) {
        //If Example
        int x = 10;

        if (x < 20) {
            System.out.print("X less than 20\n");
        }
    }
}
