package com.gm.pcworld;

public class Mouse extends InputDevice {

    private final int mouseId;
    private static int mouseCounter;

    //Full constructor
    public Mouse(String brand) {
        super( brand);
        mouseId = ++mouseCounter;
    }

    @Override
    public String toString() {
        return "Mouse{" + "mouseId=" + mouseId + ", " + "brand=" + super.getBrand() + '}';
    }
}
