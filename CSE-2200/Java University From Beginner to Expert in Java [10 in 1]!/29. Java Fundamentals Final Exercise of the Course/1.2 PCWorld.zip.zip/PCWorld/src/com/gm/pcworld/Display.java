package com.gm.pcworld;

//Creation of the class
public class Display {
    //Variable declaration
    private final int displayId;
    private String brand;
    private static int displayCounter;

    private Display(){
         displayId = ++displayCounter;
   }
    
    //Full constructor
    public Display(String brand) {
        this();
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }
    
    @Override
    public String toString() {
        return "Display{" + " displayId=" + displayId + ", brand=" + brand + '}';
    }

}
