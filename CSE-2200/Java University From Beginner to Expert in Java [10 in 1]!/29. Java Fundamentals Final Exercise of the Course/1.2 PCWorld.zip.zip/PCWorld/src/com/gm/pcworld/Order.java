package com.gm.pcworld;

public class Order {

    private final int orderId;
    //Array of computers declaration
    private final PC computers[];
    private static int ordersCounter;
    private int pcCounter;
    //Define the max of pc to create
    private static final int MAX_PC = 10;

    public Order() {
        this.orderId = ++ordersCounter;
        //Instantiate the array of PCs
        computers = new PC[MAX_PC];
    }

    public void addPC(PC pc) {
        //Add the pc to the array if possible
        if (pcCounter < MAX_PC) {
            //Add the new pc to the array an increment the pcCounter
            computers[pcCounter++] = pc;
        }
        else{
            System.out.println("The maximum of products has been exceeded: " + MAX_PC);
        }
    }

    public void showOrder() {
        System.out.println("Orden #:" + orderId);
        System.out.println("Num. of PCs:" + pcCounter + ":");
        for (int i = 0; i < pcCounter; i++) {
            System.out.println(computers[i]);
        }
    }
}
