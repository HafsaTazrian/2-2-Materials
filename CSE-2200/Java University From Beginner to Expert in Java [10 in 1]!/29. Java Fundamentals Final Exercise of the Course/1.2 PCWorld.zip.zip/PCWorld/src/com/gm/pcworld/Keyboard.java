package com.gm.pcworld;

public class Keyboard extends InputDevice {

    private final int keyboardId;
    private static int keyboardCounter;

    //Full constrcutor
    public Keyboard(String brand) {
        super(brand);
        keyboardId = ++keyboardCounter;
    }

    @Override
    public String toString() {
        return "Keyboard{" + "keyboardId=" + keyboardId + ", " + "brand=" + super.getBrand() + '}';
    }
    
}
