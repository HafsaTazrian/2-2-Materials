package com.gm.pcworld;

public class InputDevice {

    private String brand;

    //Full constructor
    public InputDevice(String brand) {
        this.brand = brand;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    @Override
    public String toString() {
        return "InputDevice{ brand=" + brand + "}";
    }
}
