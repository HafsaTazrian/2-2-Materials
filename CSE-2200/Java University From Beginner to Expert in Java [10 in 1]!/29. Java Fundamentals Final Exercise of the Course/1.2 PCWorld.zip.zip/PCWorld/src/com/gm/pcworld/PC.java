package com.gm.pcworld;

public class PC {

    private int computerId;
    private String name;
    private Display display;
    private Keyboard keyboard;
    private Mouse mouse;
    private static int pcCounter;

    //Empty Constructor
    private PC() {
        computerId = ++pcCounter;
    }

    //Full constructor
    public PC(String name, Display display, Keyboard keyboard, Mouse mouse) {
        this();
        this.name = name;
        this.display = display;
        this.mouse = mouse;
        this.keyboard = keyboard;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Display getDisplay() {
        return display;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public Keyboard getKeyboard() {
        return keyboard;
    }

    public void setKeyboard(Keyboard keyboard) {
        this.keyboard = keyboard;
    }

    public Mouse getMouse() {
        return mouse;
    }

    public void setMouse(Mouse mouse) {
        this.mouse = mouse;
    }

    @Override
    public String toString() {
        return "PC{ computerId=" + computerId + ", name=" + name + ", display=" + display + ", keyboard=" + keyboard + ", mouse=" + mouse + '}';
    }
}
