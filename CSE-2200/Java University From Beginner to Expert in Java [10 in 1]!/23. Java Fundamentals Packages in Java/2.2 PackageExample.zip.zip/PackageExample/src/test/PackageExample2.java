package test;

//Import the static method to use
import static com.gm.Utility.print;

public class PackageExample2 {
    
    public static void main(String[] args) {
        print("Hello");
    } 
}
