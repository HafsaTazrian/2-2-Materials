package test;

import com.gm.Utility;

public class PackageExample {
    
    public static void main(String[] args) {
        Utility.print("Hello");
    }
}
