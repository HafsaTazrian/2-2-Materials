package com.gm;

public class Utility {
    
    public static void print(String message){
        System.out.println("Print message: " + message);
    }
}
