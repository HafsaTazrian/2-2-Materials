package test;

import abstractclasses.*;

public class AbstractClassesExample {

    public static void main(String args[]) {
        //Creation of objects
        GeometricFigure rectangle = new Rectangle("Rectangle");
        GeometricFigure triangle = new Triangle("Triangle");
        GeometricFigure circle = new Circle("Circle");

        System.out.println(rectangle);
        rectangle.draw();

        System.out.println("");
        System.out.println(triangle);
        triangle.draw();

        System.out.println("");
        System.out.println(circle);
        circle.draw();
    }
}
