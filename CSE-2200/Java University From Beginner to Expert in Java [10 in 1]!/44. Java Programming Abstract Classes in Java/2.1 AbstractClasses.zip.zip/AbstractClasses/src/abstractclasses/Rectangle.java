package abstractclasses;

public class Rectangle extends GeometricFigure{
    
    public Rectangle(String figureType) {
        super(figureType);
    }

    @Override
    public void draw() {
        //Implementation of the inherit drawing method of the GeometricFigure class
        System.out.println("Here it should draw a:" + this.getClass().getSimpleName());
    }
}
