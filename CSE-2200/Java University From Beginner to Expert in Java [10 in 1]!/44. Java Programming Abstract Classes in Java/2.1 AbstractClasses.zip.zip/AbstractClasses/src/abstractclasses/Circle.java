package abstractclasses;

public class Circle extends GeometricFigure{
    
    public Circle(String figureType) {
        super(figureType);
    }

    @Override
    public void draw() {
        //Implementation of the inherit drawing method of the GeometricFigure class
        System.out.println("Here it should draw a:" + this.getClass().getSimpleName());
    }
}