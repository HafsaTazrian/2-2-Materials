package beans;
import java.util.ArrayList;
import java.util.List;
/**
 * Class to generate a JavaBean from the list of rectangles
 *  and that can be used with jsp:useBean from a JSP
 * @author Ubaldo
 */
public class RectangleList {
  //Attribute that will store the rectangle objects
  private List<Rectangle> list = new ArrayList<>();

  /**
   * This method allows us to simulate a property called
   * "rectangle" from the action jsp:setProperty in a JSP
   * @param rec Rectangle
   */
  public void setRectangle(Rectangle rec){
    this.list.add( rec );
  }

  public List<Rectangle> getList() {
    return list;
  }

  public void setList(List<Rectangle> list) {
    this.list = list;
  }
}
