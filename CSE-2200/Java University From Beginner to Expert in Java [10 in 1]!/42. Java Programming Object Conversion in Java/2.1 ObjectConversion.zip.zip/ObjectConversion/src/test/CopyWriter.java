package test;

public class CopyWriter extends Employee{
    
    //We can use an enumeration for writing type options
    final WritingType writingType;

    public CopyWriter(String name, double salary, WritingType writingType) {
        super(name, salary);
        this.writingType = writingType;
    }

    public String getDetails(){
        //In order not to repeat code, we can use
        //the parent method and only add the child attribute
        return super.getDetails()+ ", writingType: " + writingType.getDescription();
    }

    public WritingType getWritingType() {
        return writingType;
    }

    public String getWritingTypeInText() {
        return writingType.getDescription();
    }
}

