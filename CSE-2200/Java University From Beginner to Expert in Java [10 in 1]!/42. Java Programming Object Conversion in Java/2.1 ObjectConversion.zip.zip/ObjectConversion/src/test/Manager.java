package test;

public class Manager extends Employee{
    
    private String department;

    public Manager(String name, double salary, String department ){
        super(name, salary);
        this.department = department;
    }
    
    //overwrite the inherited parent method
    public String getDetails(){
        //In order not to repeat code, we can use
        //the parent method and only add the child attribute
        return super.getDetails()+ ", department: " + department;
    }
    
     public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
}
