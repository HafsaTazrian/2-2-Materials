package test;

public class ObjectConversion {
    
    public static void main(String[] args) {

        //1. First, we create a type of higher hierarchy
        Employee employee;
        //We assign a reference of a lower hierarchy object
        //This is upcasting, there is no need for a special notation
        employee = new CopyWriter("John", 1500, WritingType.CLASSIC);

        //However, if we want to access the detail of the CopyWriter class
        //It is not possible, since these characteristics are not in common
        //between all classes in the class hierarchy
        //employee.getWritingTypeInText();
        
        //We print the details in a generic method
        printDetails(employee);

        //2. We can do the same with the Manager class
        //This is upcasting, so it does not require special syntax
        employee = new Manager("Katty", 1800, "Systems");
        
        //But if we want direct access to the employee variable
        //the detail of the Manager object is not possible
        //employee.getDepartment();

        //We use the same method to print the details
        printDetails(employee);
    }

    //Generic method to print the details of the Employee hierarchy
    private static void printDetails(Employee employee) {

        String result = null;
        
        //Print details is general for everyone, since it is polymorph
        //no conversion is needed, we can call the method directly 
        System.out.println("\nDetails: " + employee.getDetails());
        
        //But the details of each class we must do a downcasting
        if (employee instanceof CopyWriter) {
            //We convert the object to the desired lower type
            //Convert object - Downcasting
            CopyWriter writer = (CopyWriter) employee;
            //Finally we can access the methods of the CopyWriter class
            result = writer.getWritingTypeInText();

            //Another way is to make the conversion in the same line of code.
            //This is very compun to find in Java
            //to avoid the creation of unnecessary variables
            result = ((CopyWriter) employee).writingType.getDescription();

            System.out.println("typeWriting result:" + result);

        } else if (employee instanceof Manager) {
            //We do the downcasting in the same line of code
            //we saved a variable
            result = ((Manager) employee).getDepartment();
            System.out.println("department result:" + result);
        }
    }
}