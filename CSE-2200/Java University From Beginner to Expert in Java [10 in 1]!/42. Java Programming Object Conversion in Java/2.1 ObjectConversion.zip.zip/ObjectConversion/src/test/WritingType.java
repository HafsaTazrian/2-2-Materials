package test;

public enum WritingType {
    
    CLASSIC("Writing by hand"),
    MODERN("Digital writing");

    private final String description;

    private WritingType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
