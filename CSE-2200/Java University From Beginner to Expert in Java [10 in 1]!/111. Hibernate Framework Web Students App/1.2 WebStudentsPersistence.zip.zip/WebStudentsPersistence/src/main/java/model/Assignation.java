package model;

import java.io.Serializable;
import java.util.*;
import javax.persistence.*;

@Entity
@Table(name = "assignation")
@NamedQueries({
    @NamedQuery(name = "Assignation.findAll", query = "SELECT a FROM Assignation a")})
public class Assignation implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_assignation")
    private Integer idAssignation;

    @Column(name = "start_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date startDate;

    @Column(name = "finish_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date finishDate;

    private int version = 0;

    private int deleted = 0;

    @JoinColumn(name = "id_student", referencedColumnName = "id_student")
    @ManyToOne
    private Student student;

    @JoinColumn(name = "id_course", referencedColumnName = "id_course")
    @ManyToOne
    private Course course;

    public Assignation() {
    }

    public Assignation(Integer idAssignation) {
        this.idAssignation = idAssignation;
    }

    public Assignation(Integer idAssignation, int version, int deleted) {
        this.idAssignation = idAssignation;
        this.version = version;
        this.deleted = deleted;
    }

    public Integer getIdAssignation() {
        return idAssignation;
    }

    public void setIdAssignation(Integer idAssignation) {
        this.idAssignation = idAssignation;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getFinishDate() {
        return finishDate;
    }

    public void setFinishDate(Date finishDate) {
        this.finishDate = finishDate;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getDeleted() {
        return deleted;
    }

    public void setDeleted(int deleted) {
        this.deleted = deleted;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAssignation != null ? idAssignation.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Assignation)) {
            return false;
        }
        Assignation other = (Assignation) object;
        if ((this.idAssignation == null && other.idAssignation != null) || (this.idAssignation != null && !this.idAssignation.equals(other.idAssignation))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Assignation{" + "idAssignation=" + idAssignation + ", startDate=" + startDate + ", finishDate=" + finishDate + ", version=" + version + ", deleted=" + deleted + ", student=" + student + ", course=" + course + '}';
    }

    
}