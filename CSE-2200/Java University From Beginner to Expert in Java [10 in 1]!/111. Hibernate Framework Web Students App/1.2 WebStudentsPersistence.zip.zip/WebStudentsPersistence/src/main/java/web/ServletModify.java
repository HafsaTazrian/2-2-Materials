package web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.Student;
import service.StudentService;

@WebServlet("/ServletModify")
public class ServletModify extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // This get method is going to take charge of recovering 
        // the object to modify to show it in the form
        //1. We retrieve the idStudent of the request
        String idStudent = request.getParameter("idStudent");

        //2. We rely on the service class to recover the object to be modified
        StudentService studentService = new StudentService();
        Student student = studentService.findStudent(Integer.parseInt(idStudent));

        //3. We share the found object with the view
        //Let's share it in the session
        HttpSession session = request.getSession();
        session.setAttribute("student", student);

        //4. Redirect in view of modifying
        request.getRequestDispatcher("/WEB-INF/modifyStudent.jsp").forward(request, response);
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //This post method will be responsible for modifying 
        //the values that are sent from the form
        //We check if the button to modify or delete is pressed
        String action = request.getParameter("modify");
        if ("modify".equals(action)) {

            //1. We retrieve the parameters
            String name = request.getParameter("name");
            String streetName = request.getParameter("streetName");
            String streetNumber = request.getParameter("streetNumber");
            String country = request.getParameter("country");

            //2. We recover the object of the session
            HttpSession session = request.getSession();
            Student student = (Student) session.getAttribute("student");

            //3. We update the values of the modification of the student
            student.setName(name);
            //We update the values of the embedded object of Address
            student.getAddress().setStreetName(streetName);
            student.getAddress().setStreetNumber(streetNumber);
            student.getAddress().setCountry(country);
            
            //4. We communicate with the service layer to save the changes
            StudentService studentService = new StudentService();
            studentService.saveStudent(student);

            //5. We eliminated the modified object from the session 
            //since we only used it while modifying the student
            session.removeAttribute("student");

        } //else if("delete".equals( accion )){
        else { //delete was selected
            //We eliminate the student object

            //1. We retrieve the id of the student to be eliminated
            String idStudent = request.getParameter("idStudent");

            //2. We rely on the service layer to eliminate the Student object
            StudentService studentService = new StudentService();
            studentService.deleteStudent(Integer.parseInt(idStudent));
        }

        //6.Redirect to the index page
        request.getRequestDispatcher("/index.jsp").forward(request, response);

    }

}