package web;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.Student;
import service.StudentService;

@WebServlet("/ServletController")
public class ServletController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //1. We communicate with the service layer
        StudentService studentService =  new StudentService();

        //2. We recover all the students
        List<Student> students = studentService.listStudents();

        //3. We share the information (Model) with the view
        request.setAttribute("students", students);

        //4. We select the view to show the information of students
        request.getRequestDispatcher("/WEB-INF/listStudents.jsp").forward(request, response);
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        this.doGet(request, response);
    }
}