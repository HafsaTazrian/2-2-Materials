package web;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/DateServlet")
public class DateServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try (PrintWriter out = response.getWriter()) {
            response.setContentType("text/html;charset=UTF-8");
            response.setHeader("refresh", "1");//given in seconds
            //We obtain the current date and apply a format 
            Date fecha = new Date();
            //API to use the SimpleDateFormat class
            //https://docs.oracle.com/javase/8/docs/api/java/text/SimpleDateFormat.html
            //SimpleDateFormat formatter = new SimpleDateFormat("dd 'of' MMMM 'of' yyyy 'at' HH:mm:ss");
            SimpleDateFormat formatter = new SimpleDateFormat("'Updated time' HH:mm:ss");
            String dateWithFormat = formatter.format(fecha);
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet FechaServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1> " + dateWithFormat + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}