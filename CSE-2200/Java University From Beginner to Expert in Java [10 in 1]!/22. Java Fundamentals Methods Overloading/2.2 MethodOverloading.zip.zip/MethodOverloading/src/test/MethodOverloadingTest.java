package test;

public class MethodOverloadingTest {
    
    public static void main(String[] args) {
        System.out.println("Result 1: " + Operations.add(3, 4) + "\n");
        
        System.out.println("Resultado 2: " + Operations.add(5, 4.1) + "\n");

        System.out.println("Resultado 3: " + Operations.add(7.1, 3) + "\n");

        System.out.println("Resultado 4: " + Operations.add(2.2, 6.8) + "\n");

        //Which method is called?
        System.out.println("Resultado 5: " + Operations.add(3, 1L) + "\n");//L or l means Long

        //Which method is called?
        System.out.println("Resultado 6: " + Operations.add(3F, 'A') + "\n");//F or f means Float
    }

}
