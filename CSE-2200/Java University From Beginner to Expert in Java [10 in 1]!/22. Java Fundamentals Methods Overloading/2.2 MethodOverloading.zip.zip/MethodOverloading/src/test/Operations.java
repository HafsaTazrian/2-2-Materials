package test;

public class Operations {
    
    //add Method
    public static int add(int a, int b) {
        System.out.println("add (int, int) method");
        return a + b;
    }

    //add method overloading
    public static double add(double a, double b) {
        System.out.println("add (double, double) method");
        return a + b;
    }

    //add method overloading
    public static double add(int a, double b) {
        System.out.println("add (int, double) method:");
        return a + b;
    }

    //add method overloading
    public static double add(double a, int b) {
        System.out.println("add (double, int) method:");
        return a + b;
    }
}
