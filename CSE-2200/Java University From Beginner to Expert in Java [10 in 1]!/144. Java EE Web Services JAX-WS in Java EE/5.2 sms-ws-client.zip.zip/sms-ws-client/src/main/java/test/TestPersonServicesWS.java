package test;

import java.util.List;
import sms.ws.*;

public class TestPersonServicesWS {

    public static void main(String[] args) {
        PersonServiceWS personService = new PersonServiceImplService().getPersonServiceImplPort();

        System.out.println("Running List People Web Service");
        List<Person> people = personService.listPeople();
        for (Person person : people) {
            System.out.println("Person: " + person.getIdPerson() + " " + person.getName()) ;
        }
        System.out.println("End Service List People WS");
    }
}
