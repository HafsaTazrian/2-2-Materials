package sms.service;

import java.util.List;
import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebService;
import sms.data.PersonDao;
import sms.domain.Person;

@Stateless
@WebService(endpointInterface = "sms.service.PersonServiceWS")
public class PersonServiceImpl implements PersonServiceRemote, PersonService, PersonServiceWS {

    @Resource
    private SessionContext context;

    @Inject
    private PersonDao personDao;

    @Override
    public List<Person> listPeople() {
        return personDao.findAllPeople();
    }

    @Override
    public Person findPerson(Person person) {
        return personDao.findPerson(person);
    }

    @Override
    public void addPerson(Person person) {
        personDao.insertPerson(person);
    }

    @Override
    public void modifyPerson(Person person) {
        try {
            personDao.updatePerson(person);
        } catch (Throwable t) {
            context.setRollbackOnly();
            t.printStackTrace(System.out);
        }
    }

    @Override
    public void deletePerson(Person person) {
        personDao.deletePerson(person);
    }
}
