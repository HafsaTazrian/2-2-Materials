package beans;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface ServiceAddWS {

    @WebMethod
    public int add(int a, int b);
}
