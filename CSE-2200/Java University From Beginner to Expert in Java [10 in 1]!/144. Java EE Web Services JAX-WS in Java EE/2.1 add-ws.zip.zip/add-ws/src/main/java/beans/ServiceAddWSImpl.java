package beans;

import javax.ejb.Stateless;
import javax.jws.WebService;

@Stateless
@WebService(endpointInterface = "beans.ServiceAddWS")
public class ServiceAddWSImpl implements ServiceAddWS {

    @Override
    public int add(int a, int b) {
        return a + b;
    }
}
