package test;

import wsclient.ServiceAddWS;
import wsclient.ServiceAddWSImplService;

public class TestServiceAddWS {

    public static void main(String[] args) {
        ServiceAddWS addWSService = new ServiceAddWSImplService().getServiceAddWSImplPort();
        System.out.println("Running WS Add Service");
        int x = 1;
        int y = 2;
        System.out.println("Add:" + "x: " + x + " y: " + y);
        System.out.println("Result: " + addWSService.add(x, y));
        System.out.println("End of Add Service WS");
    }
}
