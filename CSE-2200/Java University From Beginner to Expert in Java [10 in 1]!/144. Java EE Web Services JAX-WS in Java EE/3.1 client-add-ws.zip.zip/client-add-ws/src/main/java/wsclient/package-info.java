@javax.xml.bind.annotation.XmlSchema(namespace = "http://beans/")
package wsclient;
