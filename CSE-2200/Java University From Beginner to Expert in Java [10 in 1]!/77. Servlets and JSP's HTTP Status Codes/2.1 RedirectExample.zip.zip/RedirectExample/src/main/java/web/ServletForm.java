package web;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ServletForm")
public class ServletForm extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //Simulating correct values
        try (PrintWriter out = response.getWriter()) {
            //Simulating correct values
            String correctUser = "John";
            String correctPass = "123";
            String pUser = request.getParameter("user");
            String pPassword = request.getParameter("password");
            if (correctUser.equals(pUser) && correctPass.equals(pPassword)) {
                out.println("<h1>");
                out.println("Correct Data");
                out.println("<br>User:" + pUser);
                out.println("<br>Password:" + pPassword);
                out.println("</h1>");
            } else {
                //We respond to the browser with an unauthorized status code
                response.sendError(response.SC_UNAUTHORIZED, "The credentials are incorrect");
            }
            //List of error codes
            //http://docstore.mik.ua/orelly/java-ent/servlet/appc_01.htm
        }
    }
}