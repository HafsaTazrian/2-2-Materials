package web;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RedirectServlet")
public class RedirectServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // We no longer use the printwriter object to send the response
        // We use the redirect
        String url = null;
        String browserType = request.getHeader("User-Agent");
        System.out.println("browser type:" + browserType);
        if (browserType != null && browserType.contains("Trident")) {
            url = "http://www.microsoft.com";
        } else if (browserType != null && browserType.contains("Firefox")) {
            url = "http://www.firefox.com";
        } else if (browserType != null && browserType.contains("Chrome")) {
            url = "http://www.google.com";
        }

        //Redirect to the selected URL
        response.sendRedirect(url);
    }
}
