package web.actions;

import com.opensymphony.xwork2.*;
import java.util.*;
import org.apache.logging.log4j.*;

public class CountriesAction extends ActionSupport implements Preparable {

    private final String data = "Mexico, United States, Colombia, Argentina, China, Japan";
    private List<String> countries;
    private String country;
    Logger log = LogManager.getLogger(CountriesAction.class);

    @Override
    public void prepare() {
        log.info("We load the list of countries");
        countries = new ArrayList<>();
        StringTokenizer st = new StringTokenizer(data, ",");

        while (st.hasMoreTokens()) {
            countries.add(st.nextToken().trim());
        }
    }

    @Override
    public String execute() {
        log.info("Selected country: " + country);
        return SUCCESS;
    }

    public String getCountry() {
        return this.country;
    }

    public List<String> getCountries() {
        return countries;
    }

    public void setCountries(List<String> countries) {
        this.countries = countries;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}