package test;

public class Manager extends Employee{
    
    private String deparment;

    public Manager(String name, double salary, String deparment) {
        super(name, salary);
        this.deparment = deparment;
    }
    
    //Override the inherited method
    public String getDetails(){
        //Observe how we directly access the inherited attribute
        //because it is declared as protected in the parent class
        //and therefore the child class inherits it and accesses directly
        return "Name: " + name +
                ", sueldo: " + salary +
                ", department: " + deparment;
    }
    
     public String getDeparment() {
        return deparment;
    }

    public void setDeparment(String deparment) {
        this.deparment = deparment;
    }
}
