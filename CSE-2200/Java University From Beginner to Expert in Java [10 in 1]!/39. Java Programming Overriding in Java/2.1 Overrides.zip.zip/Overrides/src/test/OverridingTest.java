package test;

public class OverridingTest {
    
    public static void main(String[] args) {
        Employee employee = new Employee("John",1000);
        System.out.println( employee.getDetails());
        
        Manager manager = new Manager("Katty",2000,"Finance");
        System.out.println( manager.getDetails());
    }
}
