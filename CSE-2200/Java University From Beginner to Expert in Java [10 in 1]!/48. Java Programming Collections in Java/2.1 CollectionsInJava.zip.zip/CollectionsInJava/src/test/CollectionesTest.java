package test;

import java.util.*;

public class CollectionesTest {
  public static void main(String args[]) {
        List myList = new ArrayList();
        myList.add("1");
        myList.add("2");
        myList.add("3");
        myList.add("4");
        //Repeated element
        myList.add("4");
        print(myList);

        Set mySet = new HashSet();
        mySet.add("100");
        mySet.add("200");
        mySet.add("300");
        //Does not allow repeated elements, ignores it
        mySet.add("300");
        print(mySet);

        Map myMap = new HashMap();
        //Key, value
        myMap.put("1", "John");
        myMap.put("2", "Katty");
        myMap.put("3", "Charly");
        myMap.put("4", "Sara");
        //All the keys are printed
        print(myMap.keySet());
        //All values are printed
        print(myMap.values());

    }

    private static void print(Collection collection) {
        for (Object element : collection) {
            System.out.print(element + " ");
        }
        System.out.println("");
    }
}
