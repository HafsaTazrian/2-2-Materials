package test;

import java.util.Scanner;

public class DataInputScannerTest {

    public static void main(String[] args) {
        String capture;
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a data:");
        capture = scan.nextLine();
        while (capture != null) {
            System.out.println("Data entered:" + capture);
            capture = scan.nextLine();
        }
    }
}
