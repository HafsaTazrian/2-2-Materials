package dao;

import domain.Person;
import java.util.List;
import javax.persistence.*;

public class PersonDao {

    protected EntityManager em;
    private EntityManagerFactory emf = null;

    public PersonDao() {
        emf = Persistence.createEntityManagerFactory("HibernatePU");
    }

    public List<Person> listPeople() {
        String hql = "SELECT p FROM Person p";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        return query.getResultList();
    }

    public void insert(Person person) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(person);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error inserting object:" + ex.getMessage());
            ex.printStackTrace(System.out);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void update(Person person) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(person);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error updating object:" + ex.getMessage());
            ex.printStackTrace(System.out);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void delete(Person person) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.remove(em.merge(person));
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error deleting object:" + ex.getMessage());
            ex.printStackTrace(System.out);
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public Person findById(Person p) {
        em = getEntityManager();
        return em.find(Person.class, p.getIdPerson());
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

}
