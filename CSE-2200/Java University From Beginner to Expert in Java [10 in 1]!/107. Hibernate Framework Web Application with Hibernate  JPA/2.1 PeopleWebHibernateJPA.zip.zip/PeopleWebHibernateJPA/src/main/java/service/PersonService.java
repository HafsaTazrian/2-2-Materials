package service;

import dao.PersonDao;
import domain.Person;
import java.util.List;

public class PersonService {

    public List<Person> listPeople() {
        PersonDao personaDao = new PersonDao();
        return personaDao.listPeople();
    }
}
