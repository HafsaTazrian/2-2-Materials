package web;

import domain.Person;
import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import service.PersonService;

@WebServlet("/ServletController")
public class ServletController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            // 1.We connect to the service layer
            PersonService personService = new PersonService();

            // 2.We request the list of people (Model)
            List<Person> people = personService.listPeople();

            // 3.We share the list of people (Model) with the JSP (View)
            request.setAttribute("people", people);

            // 4.Redireccionamos a la vista
            request.getRequestDispatcher("/WEB-INF/people.jsp").forward(request, response);

        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
    }
}