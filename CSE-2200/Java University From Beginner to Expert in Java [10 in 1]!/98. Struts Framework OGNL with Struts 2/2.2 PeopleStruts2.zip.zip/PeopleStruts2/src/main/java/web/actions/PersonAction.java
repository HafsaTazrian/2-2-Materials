package web.actions;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.*;
import web.model.Person;

public class PersonAction extends ActionSupport {

    Logger log = LogManager.getLogger(PersonAction.class);

    private Person person;

    @Override
    public String execute() {
        if (person != null) {
            log.info("\n");
            log.info("person:" + person.getName());
            log.info("Street Name:" + person.getAddress().getStreetName());
            log.info("Street Number:" + person.getAddress().getStreetNumber());
            log.info("Country:" + person.getAddress().getCountry());
        }
        else{
            log.info("Person with null value ");
        }

        return SUCCESS;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }
}