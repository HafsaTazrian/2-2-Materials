package package1;

public class Class1 {
    
    //Definicion de atributos
    public int publicAttribute = 5;
    protected int protectedAttribute = 6;
    int packageAttribute = 7;
    private int privateAttribute = 8;

    //Constructores
    public Class1() {
    }

    public Class1(int i) {
        System.out.println("Public Constructor 1");

    }

    protected Class1(int i, int j) {
        System.out.println("Protected Constructor 2");
    }

    Class1(int i, int j, int k) {
        System.out.println("Package Constructor 3");
    }

    private Class1(int i, int j, int k, int l) {
        System.out.println("Private Constructor 4");
    }

    //Method definitions
    public int publicMethod() {
        return 9;
    }

    protected int protectedMethod() {
        return 10;
    }

    int packageMethod() {
        return 11;
    }

    private int privateMethod() {
        return 12;
    }
}