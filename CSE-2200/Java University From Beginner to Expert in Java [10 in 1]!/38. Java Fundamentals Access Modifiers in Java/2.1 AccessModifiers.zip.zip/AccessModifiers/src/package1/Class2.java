package package1;

public class Class2 {
    
    public Class2() {
        //Test Constructors of Class1
        System.out.println("");
        //Public Constructor
        new Class1(1);
        //Protected Constructor
        new Class1(1, 2);
        //Default o Package Constructor 
        new Class1(1, 2, 3);
        //Private Constructor is not accesible (has private access)
        //new Class1(1, 2, 3,4); 
        System.out.println("Access denied to private constructor");
    }

    public void testFromClass2() {
        //Access to Class1 from Class2
        Class1 c1 = new Class1();
        System.out.println("");
        System.out.println("Public Attribute: " + c1.publicAttribute);
        System.out.println("Protected Attribute: " + c1.protectedAttribute);
        System.out.println("Package attribute: " + c1.packageAttribute);
        //System.out.println("Private Attribute: " + c1.privateAttribute);//has private access
        System.out.println("Private Attribute: Access Denied");

        System.out.println("");
        System.out.println("Public Method: " + c1.publicMethod());
        System.out.println("Protected Method: " + c1.protectedMethod());
        System.out.println("Default Method: " + c1.packageMethod());
        //System.out.println("Private Method :" + c1.privateMethod());//has private access
        System.out.println("Private Method: Access Denied");
    }
}