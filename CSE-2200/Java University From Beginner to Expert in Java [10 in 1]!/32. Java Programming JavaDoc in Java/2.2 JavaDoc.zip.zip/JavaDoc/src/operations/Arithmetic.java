package operations;

/**
 * This class does many operations like add, subtract, multiply or divide
 * @author: Ubaldo Acosta
 * @version: 1.0
 */
public class Arithmetic {
    
    /**
     * First Operand
     */
    int operandA;

    /**
     * Second operand
     */
    int operandB;

    /**
     * Empty Constructor of the Class
     */
    public Arithmetic() {
    }
    
    /**
     * This methods does the addition of 2 integer operands
     * @return int add result
     */
    public int add(){
        return operandA + operandB;
    }
}
