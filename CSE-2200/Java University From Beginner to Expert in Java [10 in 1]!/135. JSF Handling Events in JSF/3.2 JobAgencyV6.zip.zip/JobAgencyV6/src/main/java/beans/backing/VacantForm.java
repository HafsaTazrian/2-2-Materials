package beans.backing;

import beans.model.Candidate;
import javax.inject.*;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.*;
import javax.faces.context.FacesContext;
import javax.faces.event.*;
import org.apache.logging.log4j.*;

@Named
@RequestScoped
public class VacantForm {

    Logger log = LogManager.getRootLogger();

    @Inject
    private Candidate candidate;

    private boolean commentSent = false;

    public VacantForm() {
        log.info("Creating VacantForm object");
    }

    public void setCandidate(Candidate candidate) {
        this.candidate = candidate;
    }

    public String send() {
        log.info("send() Name=" + this.candidate.getName());
        log.info("send() Desired Salary=" + this.candidate.getDesiredSalary());

        if (this.candidate.getName().equals("John")) {

            if (this.candidate.getLastName().equals("Smith")) {
                String msg = "Thanks, but John Smith is already working with us.";
                FacesMessage facesMessage = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg);
                FacesContext facesContext = FacesContext.getCurrentInstance();
                String componentId = null; //This is a global message
                facesContext.addMessage(componentId, facesMessage);
                return "index";
            }
            return "success";//success.xhtml
        } else {
            return "failure"; //failure.xhtml
        }
    }

    //Method of type Value Change Listener
    public void zipCodeListener(ValueChangeEvent valueChangeEvent) {
        FacesContext facesContext = FacesContext.getCurrentInstance();
        UIViewRoot uiViewRoot = facesContext.getViewRoot();
        String newZipCode = (String) valueChangeEvent.getNewValue();
        if ("85001".equals(newZipCode)) {
            log.info("Modify the city value dynamically with ValueChangeListener");
            //We use the name of the form of index.xhtml to find the component
            UIInput cityInputText = (UIInput) uiViewRoot.findComponent("vacantForm:city");
            String city = "PHOENIX";
            cityInputText.setValue(city);
            cityInputText.setSubmittedValue(city);
            //Return the response
            facesContext.renderResponse();
        }
    }

    public void hideComment(ActionEvent actionEvent) {
        this.setCommentSent(!this.commentSent);
        log.info("Executing actionEvent hideComment");

    }

    public boolean isCommentSent() {
        return commentSent;
    }

    public void setCommentSent(boolean commentSent) {
        this.commentSent = commentSent;
    }
}
