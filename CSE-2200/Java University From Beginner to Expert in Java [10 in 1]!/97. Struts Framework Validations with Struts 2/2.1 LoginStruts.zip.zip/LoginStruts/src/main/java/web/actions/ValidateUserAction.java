package web.actions;

import static com.opensymphony.xwork2.Action.INPUT;
import static com.opensymphony.xwork2.Action.SUCCESS;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.*;
import org.apache.struts2.convention.annotation.*;

@Results({
    @Result(name = "success", location = "/WEB-INF/content/welcome.jsp"),
    @Result(name = "input", location = "/WEB-INF/content/login.jsp")
})
public class ValidateUserAction extends ActionSupport {

    private String user;
    private String password;
    Logger log = LogManager.getLogger(ValidateUserAction.class);

    @Action("validateUser")
    @Override
    public String execute() {
        //If it is valid user we show the welcome.jsp page
        if (validUser()) {
            addActionMessage(getText("user.valid"));
            return SUCCESS;
        } else {
            //If it is user NOT valid, we return to the login
            return INPUT;
        }
    }

    @Override
    public void validate() {
        if (this.user == null || "".equals(this.user.trim())) {
            addFieldError("user", getText("val.user"));
        } else if (!validUser()) {
            addActionError(getText("user.invalid"));
        }

        if (this.password == null || "".equals(this.password.trim())) {
            addFieldError("password", getText("val.password"));
        } else if (this.password.length() < 3) {
            addFieldError("password", getText("val.pass.min.length"));
        }
    }

    private boolean validUser() {
        //Value of valid user = "admin" in hard code
        return "admin".equals(this.user);
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}