package domain;

public class OperationException extends Exception {

    public OperationException(String message) {
        //Initialize the error message of the parent class
        super(message);
    }
}
