package domain;

public class Division {
    
    //attributes of the class
    private int numerator;
    private int denominator;

    public Division(int numerator, int denominator) throws OperationException {

        if (denominator == 0) {
            //throw new IllegalArgumentException("Denominator equal to zero");
            throw new OperationException("Denominator equal to zero");
        }
        this.numerator = numerator;
        this.denominator = denominator;
    }

    public void visualizeOperation() {
        System.out.println("The division result is: " + numerator / denominator);
    }
}
