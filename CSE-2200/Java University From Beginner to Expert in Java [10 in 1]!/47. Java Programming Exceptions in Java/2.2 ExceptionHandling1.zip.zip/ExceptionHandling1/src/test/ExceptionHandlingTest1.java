package test;

import domain.*;

public class ExceptionHandlingTest1 {
    
    public static void main(String[] args) {

        try {
            Division division = new Division(10, 0);
            division.visualizeOperation();
        } catch (OperationException oe) {
            System.out.println("An error occurred!!!");
            oe.printStackTrace(System.out);
        }
    }
}
