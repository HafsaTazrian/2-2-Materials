package exceptions;

public class ReadDataAccessEx extends DataAccessEx{
    

    public ReadDataAccessEx(String message) {
        super(message);
    }
}
