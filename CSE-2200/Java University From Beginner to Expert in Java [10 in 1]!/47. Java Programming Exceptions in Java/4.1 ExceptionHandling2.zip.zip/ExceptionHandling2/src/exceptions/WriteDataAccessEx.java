package exceptions;

public class WriteDataAccessEx extends DataAccessEx{
    

    public WriteDataAccessEx(String message) {
        super(message);
    }
}