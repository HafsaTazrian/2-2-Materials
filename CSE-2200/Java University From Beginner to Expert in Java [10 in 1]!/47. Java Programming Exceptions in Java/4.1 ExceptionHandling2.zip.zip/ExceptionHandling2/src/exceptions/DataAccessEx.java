package exceptions;

public class DataAccessEx extends Exception{
    
    public DataAccessEx(String message){
        super(message);
    }
}