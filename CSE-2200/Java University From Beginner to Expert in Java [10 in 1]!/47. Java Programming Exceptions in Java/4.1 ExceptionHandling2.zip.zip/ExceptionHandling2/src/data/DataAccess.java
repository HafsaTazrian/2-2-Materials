package data;

import exceptions.DataAccessEx;

public interface DataAccess {

    public abstract void insert() throws DataAccessEx;
    
    public abstract void list() throws DataAccessEx;
    
    public abstract void simulateError(boolean simularError);
}
