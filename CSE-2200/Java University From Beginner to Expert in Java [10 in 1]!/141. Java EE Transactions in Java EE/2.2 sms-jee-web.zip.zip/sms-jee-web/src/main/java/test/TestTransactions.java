package test;

import javax.naming.Context;
import javax.naming.InitialContext;
import sms.domain.Person;
import sms.service.PersonServiceRemote;

public class TestTransactions {

    public static void main(String[] args) throws Exception {
        Context jndi = new InitialContext();
        PersonServiceRemote personService = 
             (PersonServiceRemote) jndi.lookup("java:global/sms-jee-web/PersonServiceImpl!sms.service.PersonServiceRemote");
        
        System.out.println("Starting a Transactional PersonService test");

        //We are looking for a person object
        Person person = new Person();
        person.setIdPerson(1);
        person = personService.findPerson(person);

        //We change the person
        //person.setName("Change with error....................................................................");
        person.setName("John2");

        personService.modifyPerson(person);
        System.out.println("Modified Object:" + person);
        System.out.println("End EJB PersonService test");
    }
}
