package web.actions;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.*;
import org.apache.struts2.convention.annotation.*;

@Results({
    @Result(name="success", location="/WEB-INF/content/welcome.jsp"),
    @Result(name="input", location="login", type="redirectAction")
})
public class ValidateUserAction extends ActionSupport {

    private String user;
    private String password;
    Logger log = LogManager.getLogger(ValidateUserAction.class);

    @Action("validateUser")
    @Override
    public String execute() {
        log.info("User:" + this.user);
        //If you are a valid user, we show the welcome.jsp page
        if ("admin".equals(this.user)) {
            return SUCCESS;
        } else {
            //If you are an invalid user, we return to login
            return INPUT;
        }
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}