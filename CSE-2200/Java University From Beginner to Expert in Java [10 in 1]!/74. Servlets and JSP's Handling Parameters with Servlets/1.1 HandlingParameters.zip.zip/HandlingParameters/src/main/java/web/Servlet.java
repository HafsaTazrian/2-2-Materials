package web;

import java.io.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/Servlet")
public class Servlet extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {
        try (PrintWriter out = res.getWriter()) {
            out.println("<html>");
            out.println("<body>");
            out.println("doGet method not supported in the Servlet");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        //We read the parameters of the form
        String user = req.getParameter("user");
        String password = req.getParameter("password");

        System.out.println("user:" + user);
        System.out.println("password:" + password);

        try (PrintWriter out = res.getWriter()) {
            out.println("<html>");
            out.println("<body>");
            out.println("The user parameter is: " + user);
            out.println("<br>");
            out.println("The password parameter is: " + password);
            out.println("</body>");
            out.println("</html>");
        }
    }
}