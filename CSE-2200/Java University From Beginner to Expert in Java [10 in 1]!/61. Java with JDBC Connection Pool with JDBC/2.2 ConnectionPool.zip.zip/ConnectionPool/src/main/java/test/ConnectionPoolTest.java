package test;

import java.sql.*;
import pool.MySqlConnectionPool;

public class ConnectionPoolTest {
     public static void main(String[] args) {
        Connection conn;
        PreparedStatement stmt;
        ResultSet rs;
        try {
            //Test the MySql pool and execute a query
            conn = MySqlConnectionPool.getConnection();
            System.out.println("We use the MySql connection pool:");
            stmt = conn.prepareStatement("SELECT * FROM person");
            rs = stmt.executeQuery();
            while(rs.next()){
                System.out.print(" " + rs.getInt(1));//id_person
                System.out.print(" " + rs.getString(2));//name
                System.out.println("");
            }
            //Close the connection to return it to the pool
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
    }
}