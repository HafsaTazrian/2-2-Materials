package competitors;

import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class Magician implements Diviner{
    
    private String thoughts;

    @Pointcut("execution(* competitors.Thinker.thinkAboutSomething(String)) && args(thoughts)")
    public void think(String thoughts) {
    }

    @Before("think(thoughts)")
    @Override
    public void interceptThoughts(String thoughts) {
        System.out.println("Magic....");
        System.out.println("These are the thoughts of the volunteer: " + thoughts);
        this.thoughts = thoughts;
    }

    @Override
    public String getThoughts() {
        return this.thoughts;
    }
}
