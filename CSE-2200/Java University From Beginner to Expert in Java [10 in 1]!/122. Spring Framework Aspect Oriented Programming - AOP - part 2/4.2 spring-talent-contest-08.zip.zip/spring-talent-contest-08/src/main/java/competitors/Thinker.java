package competitors;

public interface Thinker {
    
    void thinkAboutSomething(String thoughts);
}
