package competitors;

public interface Poem {
    
    void recite();
}
