package competitors;

public interface Diviner {
    
    public void interceptThoughts(String thoughts);

    public String getThoughts();
}
