package competitors;

import org.springframework.stereotype.Component;

@Component
public class Voluntary implements Thinker{
    
    private String thoughts;

    @Override
    public void thinkAboutSomething(String thoughts) {
        this.thoughts = thoughts;
    }

    public String getThoughts() {
        return this.thoughts;
    }
}
