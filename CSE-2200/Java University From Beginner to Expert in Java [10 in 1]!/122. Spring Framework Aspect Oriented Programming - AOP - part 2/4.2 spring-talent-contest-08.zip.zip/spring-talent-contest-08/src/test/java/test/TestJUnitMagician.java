package test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import competitors.*;
import org.apache.logging.log4j.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

@ExtendWith(SpringExtension.class)
@ContextConfiguration({ "/applicationContext.xml" })
public class TestJUnitMagician {
    
    private final Logger log = LogManager.getRootLogger();

    @Autowired
    private Thinker voluntary;

    @Autowired
    private Diviner magician;

    @Test
    public void testMagoAdivinador() {
        String thought = "Today I will win the lottery";
        log.info("Start of the divination");
        voluntary.thinkAboutSomething(thought);
        assertEquals(thought, magician.getThoughts());
        log.info("End of Divination");
    }
}