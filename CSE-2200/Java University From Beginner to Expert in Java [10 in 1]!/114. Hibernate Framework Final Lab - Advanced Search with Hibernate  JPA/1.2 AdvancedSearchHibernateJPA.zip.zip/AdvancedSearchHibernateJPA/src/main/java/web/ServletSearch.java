package web;

import java.io.IOException;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.*;
import service.StudentService;

@WebServlet("/ServletSearch")
public class ServletSearch extends HttpServlet {

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //1. We retrieve the search parameters
        //We retrieve the student's data
        String studentName = request.getParameter("studentName");
        studentName = "".equals(studentName) ? null : studentName.trim();
        Student studentDTO = null;
        if (studentName != null) {
            studentDTO = new Student();
            studentDTO.setName(studentName);
        }

        //We retrieve the Address data
        String streetName = request.getParameter("streetName");
        streetName = "".equals(streetName) ? null : streetName.trim();
        Address addressDTO = null;
        if (streetName != null) {
            addressDTO = new Address();
            addressDTO.setStreetName(streetName);
        }

        //We retrieve the course data
        String courseName = request.getParameter("courseName");
        courseName = "".equals(courseName) ? null : courseName.trim();
        Course courseDTO = null;
        if (courseName != null) {
            courseDTO = new Course();
            courseDTO.setName(courseName);
        }

        //2. We add the parameters to a map, this allows adding more filters if needed
        Map criteriaMap = new HashMap();
        criteriaMap.put("student", studentDTO);
        criteriaMap.put("address", addressDTO);
        criteriaMap.put("course", courseDTO);

        //3. We communicate with the service layer
        StudentService studentService = new StudentService();

        //4. We send the map of parameters to create the filter
        List<Student> students = studentService.searchStudentsByCriteria(criteriaMap);

        //5. We share the information (Model) with the view
        request.setAttribute("students", students);

        //6. We select the view to show the info of students
        request.getRequestDispatcher("/WEB-INF/listStudents.jsp").forward(request, response);
    }

}