package test;

import java.util.List;
import javax.persistence.*;
import model.*;
import org.hibernate.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.MatchMode;

public class TestQbeHibernate {

    public static void main(String[] args) {
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("HibernateJpaPU");
        EntityManager em = fabrica.createEntityManager();

        //Help variables 
        Session session = em.unwrap(Session.class);
        List<Student> students = null;
        Student student = null;

        // Query 1
        System.out.println("\nQuery 1");
        student = new Student();//DTO class
        student.setName("a");

        //Example class that wraps the DTO
        Example example = Example.create(student).ignoreCase().enableLike(MatchMode.END);
        students = session.createCriteria(Student.class)//Query by Criteria
                .add(example) //the query is filtered with the DTO wrapped in a class Example
                .list();

        printStudents(students);
    }

    private static void printStudents(List<Student> students) {
        for (Student s : students) {
            System.out.println(s);
        }
    }
}