package dao;

import static dao.GenericDAO.em;
import java.util.List;
import java.util.Map;
import javax.persistence.Query;
import model.*;
import org.apache.logging.log4j.*;
import org.hibernate.*;
import org.hibernate.criterion.*;
import org.hibernate.sql.JoinType;

public class StudentDAO extends GenericDAO {

    Logger log = LogManager.getRootLogger();

    public List<Student> list() {
        String hql = "SELECT s FROM Student s";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<Student> list = query.getResultList();
        for (Student s : list) {
            System.out.println(s);
        }
        return list;
    }

    public void insert(Student student) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(student);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error inserting object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void update(Student student) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(student);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error updating object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void delete(Student student) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.remove(em.merge(student));
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error removing object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public Student findById(Student student) {
        em = getEntityManager();
        return em.find(Student.class, student.getIdStudent());
    }

    public List searchStudentsByCriteria(Map criteriaMap) {
        log.debug("finding Student instances by different criteria");
        List list = null;
        //1. We obtain the criteria one by one according to the search that we program
        Student studentDTO = null;
        Address addressDTO = null;
        Course courseDTO = null;

        if (criteriaMap != null) {
            studentDTO = (Student) criteriaMap.get("student");
            addressDTO = (Address) criteriaMap.get("address");
            courseDTO = (Course) criteriaMap.get("course");
        }
        try {
            //2. We create the criteria object to execute the query. 
            //The Criteria API method of Hibernate has been depreciated 
            //in version 5.2, however JPA does not offer at the moment an 
            //option to QueryByExample. So until JPA offers an option for 
            //this type of queries you can use this version
            Criteria criteria = em.unwrap(Session.class).getSession().createCriteria(Student.class);

            //3. We add the criteria received
            if (studentDTO != null) {

                //We use a Student's DTO and a QBE (Query By Example). We wrap it in an Example
                Example exampleStudent = Example.create(studentDTO).enableLike(MatchMode.ANYWHERE);

                //we add the example to the criteria query
                criteria.add(exampleStudent);
            }
            if (addressDTO != null) {

                //We use an Address DTO and a QBE. We wrap it in an Example
                Example exampleAddress = Example.create(addressDTO).enableLike(MatchMode.ANYWHERE);

                //We add the address restriction
                criteria.createCriteria("address", JoinType.LEFT_OUTER_JOIN)
                        .setFetchMode("address", FetchMode.JOIN)
                        .add(exampleAddress);
            }
            if (courseDTO != null) {

                //We wrap it in an Example
                Example exampleCourse = Example.create(courseDTO).enableLike(MatchMode.ANYWHERE);

                //We add the restriction of the course, first accessing to assignments 
                //and then to course adding one criterion inside another (adding a criterion 
                //means that it becomes the pivot table or root at that moment of the query)
                criteria.createCriteria("assignations", JoinType.LEFT_OUTER_JOIN)
                        .setFetchMode("assignations", FetchMode.JOIN)
                        .createCriteria("course", JoinType.LEFT_OUTER_JOIN)
                        .setFetchMode("course", FetchMode.JOIN)
                        .add(exampleCourse);
            }

            //Restrict to obtain only the different elements
            criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

            //4. We get the list
            list = criteria.list();
        } catch (RuntimeException re) {
            log.error("find students by criteria failed", re);
            throw re;
        }
        return list;
    }
}
