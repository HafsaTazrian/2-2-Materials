package web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import model.*;
import service.StudentService;

@WebServlet("/ServletAdd")
public class ServletAdd extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //1. We retrieve the parameters of the form
        String name = request.getParameter("name");
        String streetName = request.getParameter("streetName");
        String streetNumber = request.getParameter("streetNumber");
        String country = request.getParameter("country");

        //2. We fill the Student's DTO object to insert
        //We create the Address object
        Address address = new Address();
        address.setStreetName(streetName);
        address.setStreetNumber(streetNumber);
        address.setCountry(country);

        Student student = new Student();
        student.setName(name);
        //We inject the dependency of the Address object
        student.setAddress(address);

        //3. We rely on the service layer
        StudentService studentService = new StudentService();
        studentService.saveStudent(student);

        //4. Redirect to the home page
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }
}