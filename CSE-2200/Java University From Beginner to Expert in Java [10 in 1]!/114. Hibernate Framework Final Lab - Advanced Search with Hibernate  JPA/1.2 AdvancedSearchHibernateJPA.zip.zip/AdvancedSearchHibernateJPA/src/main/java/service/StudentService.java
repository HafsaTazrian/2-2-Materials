package service;

import dao.StudentDAO;
import model.Student;
import java.util.List;
import java.util.Map;

public class StudentService {

    StudentDAO studentDao = new StudentDAO();

    public List<Student> listStudents() {
        return studentDao.list();
    }

    public boolean saveStudent(Student student) {
        if (student != null && student.getIdStudent() == null) {
            studentDao.insert(student);
        } else {
            studentDao.update(student);
        }

        return true;// If nothing fails, we return true
    }

    public boolean deleteStudent(Integer idStudent) {
        studentDao.delete(new Student(idStudent));
        return true;// If nothing fails, we return true
    }

    public Student findStudent(Integer idStudent) {
        return studentDao.findById(new Student(idStudent));
    }

    public List<Student> searchStudentsByCriteria(Map criterios) {
        return studentDao.searchStudentsByCriteria(criterios);
    }

}
