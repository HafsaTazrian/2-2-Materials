package web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ServletRedirect")
public class ServletRedirect extends HttpServlet {

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("action");
        if ("add".equals(accion)) {
            //Redirect to the Add Student page
            request.getRequestDispatcher("WEB-INF/addStudent.jsp").forward(request, response);
        } else if ("search".equals(accion)) {
            //We redirected to the Advanced Search page to use criteria
            request.getRequestDispatcher("WEB-INF/advancedSearch.jsp").forward(request, response);

        }

    }
}
