package beans.model;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import org.apache.logging.log4j.*;

@Named
@RequestScoped
public class Candidate {

    Logger log = LogManager.getRootLogger();

    private String name;

    public Candidate() {
        log.info("Creating the Candidate object");
        this.setName("Introduce your name");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        log.info("Modifying the name property:" + this.name);
    }

}
