package beans.backing;

import beans.model.Candidate;
import javax.inject.*;
import javax.enterprise.context.RequestScoped;
import org.apache.logging.log4j.*;

@Named
@RequestScoped
public class VacantForm {

    Logger log = LogManager.getRootLogger();

    @Inject
    private Candidate candidate;

    public VacantForm() {
        log.info("Creating VacantForm object");
    }

    public void setCandidate(Candidate candidate) {
        this.candidate = candidate;
    }

    public String send() {
        if (this.candidate.getName().equals("John")) {
            log.info("Entering the success case");
            return "success";
        } else {
            log.info("Entering the failure case");
            return "failure";
        }
    }
}
