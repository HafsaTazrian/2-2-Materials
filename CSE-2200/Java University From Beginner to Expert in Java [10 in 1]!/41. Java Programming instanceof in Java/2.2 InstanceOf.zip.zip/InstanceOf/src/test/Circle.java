package test;

public class Circle extends GeometricFigure {

    public void draw() {
        System.out.println("draw Circle");
    }
}
