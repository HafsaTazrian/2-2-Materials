package test;

public class GeometricFigure {
    
    public void draw(){
        System.out.println("Draw geometric figure");
    }
}

