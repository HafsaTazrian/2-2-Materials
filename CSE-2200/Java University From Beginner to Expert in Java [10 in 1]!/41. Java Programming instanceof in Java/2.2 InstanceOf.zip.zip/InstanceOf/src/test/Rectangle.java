package test;

public class Rectangle extends GeometricFigure {

    public void draw() {
        System.out.println("draw Rectangle");
    }
}
