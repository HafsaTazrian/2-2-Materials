package test;

public class Ellipse extends Circle {

    public void draw() {
        System.out.println("draw Ellipse");
    }
}
