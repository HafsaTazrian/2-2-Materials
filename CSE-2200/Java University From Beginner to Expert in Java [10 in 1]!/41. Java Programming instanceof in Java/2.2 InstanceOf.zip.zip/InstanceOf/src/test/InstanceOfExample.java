package test;

public class InstanceOfExample {

    public static void main(String[] args) {

        GeometricFigure figure;
        figure = new Ellipse();//you can test any other type

        //Determine only one type that corresponds to the hierarchy
        determineType(figure);

        //Determine all possible types
        System.out.println("\nAll its types:");
        determinesAllTypes(figure);
    }

    private static void determineType(GeometricFigure figure) {
        if (figure instanceof Ellipse) {
            //Process something particular of the Ellipse
            System.out.println("It is an Ellipse");
        } else if (figure instanceof Circle) {
            //Process something particular of the Circle
            System.out.println("It is a Circle");
        } else if (figure instanceof GeometricFigure) {
            //Process something particular of the Geometrical Figure
            System.out.println("It is a Geometrical Figure");
        } else if (figure instanceof Object) {
            //Process something particular from the Object class
            System.out.println("It is an Object");
        } else {
            System.out.println("The type was not found");
        }
    }

    private static void determinesAllTypes(GeometricFigure figure) {
        if (figure instanceof Ellipse) {
            System.out.println("It is an Ellipse");
        }
        if (figure instanceof Circle) {
            System.out.println("It is a Circle");
        }
        if (figure instanceof GeometricFigure) {
            System.out.println("It is a Geometrical Figure");
        }
        if (figure instanceof Object) {
            System.out.println("It is an Object");
        } else {
            System.out.println("The type was not found");
        }
    }
}
