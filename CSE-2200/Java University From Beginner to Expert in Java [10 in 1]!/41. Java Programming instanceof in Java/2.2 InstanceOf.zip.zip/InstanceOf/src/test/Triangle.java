package test;

public class Triangle extends GeometricFigure {

    public void draw() {
        System.out.println("draw Triangle");
    }
}