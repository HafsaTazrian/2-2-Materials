package mx.com.gm.movies.exceptions;

public class WriteDataAccessEx extends DataAccessEx{

    public WriteDataAccessEx(String mensaje) {
        super(mensaje);
    }
    
}
