package mx.com.gm.movies.exceptions;

public class ReadDataAccessEx extends DataAccessEx{

    public ReadDataAccessEx(String mensaje) {
        super(mensaje);
    }
    
}
