package mx.com.gm.movies.exceptions;

public class DataAccessEx extends Exception{
    String mensaje;

    public DataAccessEx(String mensaje) {
        this.mensaje = mensaje;
    }
            
}
