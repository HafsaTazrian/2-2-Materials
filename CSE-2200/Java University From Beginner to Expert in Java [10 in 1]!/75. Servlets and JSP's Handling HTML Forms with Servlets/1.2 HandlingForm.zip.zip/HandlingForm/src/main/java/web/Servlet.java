package web;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name = "Servlet", urlPatterns = {"/Servlet"})
public class Servlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String user = request.getParameter("user");
            String password = request.getParameter("password");
            // The technology element can have several
            // values, so we process it as an array
            String[] technologies = request.getParameterValues("technology");
            String gender = request.getParameter("gender");
            String occupation = request.getParameter("occupation");
            // The music component, indicates that you can
            // select multiple elements, therefore
            // we process it as an arrangement
            String[] music = request.getParameterValues("music");
            String comments = request.getParameter("comments");

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Result</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Parameters processed by the Servlet:</h1>");
            out.println("<table border='1'>");
            
            out.println("<tr>");
            out.println("<td>");
            out.println("User");
            out.println("</td>");
            out.println("<td>");
            out.println(user);
            out.println("</td>");
            out.println("</tr>");
            
            out.println("<tr>");
            out.println("<td>");
            out.println("Password");
            out.println("</td>");
            out.println("<td>");
            out.println(password);
            out.println("</td>");
            out.println("</tr>");
            
            out.println("<tr>");
            out.println("<td>");
            out.println("Technologies");
            out.println("</td>");
            out.println("<td>");
            for (String technology : technologies) {
                out.println(technology);
                out.println(" / ");
            }
            out.println("</td>");
            out.println("</tr>");
            
            out.println("<tr>");
            out.println("<td>");
            out.println("Gender");
            out.println("</td>");
            out.println("<td>");
            out.println(gender);
            out.println("</td>");
            out.println("</tr>");
            
            out.println("<tr>");
            out.println("<td>");
            out.println("Occupation");
            out.println("</td>");
            out.println("<td>");
            out.println(occupation);
            out.println("</td>");
            out.println("</tr>");
            
            out.println("<tr>");
            out.println("<td>");
            out.println("Favorite Music");
            out.println("</td>");
            out.println("<td>");
            if (music != null) {
                for (String m : music) {
                    out.println(m);
                    out.println(" / ");
                }
            }
            out.println("</td>");
            out.println("</tr>");
            
            out.println("<tr>");
            out.println("<td>");
            out.println("Comments");
            out.println("</td>");
            out.println("<td>");
            out.println(comments);
            out.println("</td>");
            out.println("</tr>");
            
            out.println("<table>");
            
            out.println("</body>");
            out.println("</html>");
        }
    }
}