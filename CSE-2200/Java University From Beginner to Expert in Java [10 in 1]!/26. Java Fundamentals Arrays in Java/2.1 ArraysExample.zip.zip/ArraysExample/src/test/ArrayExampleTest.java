package test;

import com.gm.domain.arrays.Person;

public class ArrayExampleTest {
    
    public static void main(String[] args) {
        //1. Declare an array of integers
        int ages[];
        //2. instantiate the integer array
        ages = new int[3];
        //3. Initialize the values of the integer array
        ages[0] = 30;
        ages[1] = 15;
        ages[2] = 20;

        //Print the values to the standard output
        //4. Read the values of each element of the array
        System.out.println("Array of integers, index 0: " + ages[0]);
        System.out.println("Array of integers, index 1: " + ages[1]);
        System.out.println("Array of integers, index 2: " + ages[2]);

        //1. Declare an array of Person type
        Person people[];
        //2. Instantiate the people array
        people = new Person[4];
        //3. Initialize the values of the people array
        people[0] = new Person("John");
        people[1] = new Person("Rita");
        people[2] = new Person("Sara");

        //Print the values to the standard output
        //4. Read the values of each element of the array
        System.out.println("");
        System.out.println("Array of people, index  0: " + people[0]);
        System.out.println("Array of people, index  1: " + people[1]);
        System.out.println("Array of people, index  2: " + people[2]);

        //1. String Array, simplified notation
        String names[] = {"Charly", "Linda", "Peter", "Mary"};
        //Print the values to the standard output
        //2. Iterate the String array with a for loop
        System.out.println("");
        for (int i = 0; i < names.length; i++) {
            System.out.println("Array of Strings, index " + i + ": " + names[i]);
        }
    }
}
