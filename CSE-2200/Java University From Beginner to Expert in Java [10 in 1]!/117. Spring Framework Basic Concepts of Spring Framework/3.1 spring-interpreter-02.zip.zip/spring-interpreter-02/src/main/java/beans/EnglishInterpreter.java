package beans;

public class EnglishInterpreter implements Interpreter{

    @Override
    public void sayHello() {
        System.out.println("Hello, my name is:");
    }

    @Override
    public void sayGoodbye() {
        System.out.println("See you soon...");
    }
}
