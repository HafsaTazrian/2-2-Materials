package beans;

public interface Interpreter {

    public void sayHello();

    public void sayGoodbye();
}
