package test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import beans.Translator;

public class TestInterpreterSpring {
    
    public static void main(String[] args) {
        BeanFactory factory = new ClassPathXmlApplicationContext("applicationContext.xml");

        Translator translator1 =  (Translator) factory.getBean("englishTranslator");
        translator1.speak();

        System.out.println();

        Translator translator2 = (Translator) factory.getBean("spanishTranslator");
        translator2.speak();
    }
}
