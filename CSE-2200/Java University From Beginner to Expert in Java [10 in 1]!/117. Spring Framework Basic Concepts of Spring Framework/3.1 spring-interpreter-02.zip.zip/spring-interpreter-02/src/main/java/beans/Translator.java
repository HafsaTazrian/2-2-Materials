package beans;

public class Translator {

    private Interpreter interpreter;
    private String name;

    public void speak() {
        this.interpreter.sayHello();
        System.out.println(name);
        this.interpreter.sayGoodbye();
    }

    public Interpreter getInterpreter() {
        return interpreter;
    }

    public void setInterpreter(Interpreter interpreter) {
        this.interpreter = interpreter;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
