package beans;

public class SpanishInterpreter implements Interpreter {
    
    @Override
    public void sayHello() {
        System.out.println("Hola, mi nombre es: ");
    }

    @Override
    public void sayGoodbye() {
        System.out.println("Hasta pronto!...");
    }
}
