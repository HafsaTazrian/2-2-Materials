package beans;

public class EnglishInterpreter {

    public void sayHello() {
        System.out.println("Hello, my name is:");
    }

    public void sayGoodbye() {
        System.out.println("See you soon...");
    }
}
