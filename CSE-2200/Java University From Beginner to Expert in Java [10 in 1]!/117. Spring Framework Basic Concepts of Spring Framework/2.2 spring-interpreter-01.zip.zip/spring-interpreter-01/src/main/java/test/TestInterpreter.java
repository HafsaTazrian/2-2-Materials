package test;

import beans.EnglishInterpreter;
import beans.Translator;

public class TestInterpreter {

    public static void main(String[] args) {
        Translator translator = new Translator();
        EnglishInterpreter interpreter = new EnglishInterpreter();

        //The interpreter is manually injected and can only receive an 
        //interpreter in English, Not an interpreter in Spanish or other languages
        translator.setInterpreter(interpreter);
        translator.setName("Charly");
        translator.speak();
    }
}
