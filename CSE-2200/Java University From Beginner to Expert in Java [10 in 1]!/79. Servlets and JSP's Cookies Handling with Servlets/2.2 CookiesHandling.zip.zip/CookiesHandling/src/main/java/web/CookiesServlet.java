package web;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CookiesServlet")
public class CookiesServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        //We assume that the user is visiting our site for the first time
        boolean newUser = true;

        //We obtain all cookies
        Cookie[] cookies = request.getCookies();

        //We look for if a previously created cookie already exists
        if (cookies != null) {
            for (Cookie c : cookies) {
                if (c.getName().equals("recurrentVisitor")
                        && c.getValue().equals("yes")) {
                    //In case there is already a cookie indicating
                    //that a previously registered user already exists
                    //we put the flag in false and we left the loop
                    newUser = false;
                    break;
                }
            }//end of for
        }//end of if

        //We check if the user is a new visitor
        String message = null;
        if (newUser) {
            //En caso de ser un usuario nuevo creamos el objeto Cookie
            Cookie cookieVisitor = new Cookie("recurrentVisitor", "yes");
            //Agregamos la cookie en la respuesta
            response.addCookie(cookieVisitor);
            message = "Thank you for visiting our site";
        } else {
            message = "Thank you for visiting our site AGAIN";
        }

        //write the output
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        //We omit HTML code to simplify the code
        out.println("Message:" + message);
    }
}