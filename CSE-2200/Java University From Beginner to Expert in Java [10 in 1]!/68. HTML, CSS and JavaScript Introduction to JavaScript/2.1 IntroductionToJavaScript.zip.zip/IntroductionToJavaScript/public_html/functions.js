/**
 * @author ubaldo
 */
function sayHello() {
    alert("Hello World with JavaScript from the file");
}

function writeMessage() {
    document.getElementById("htmlMessageElement").innerHTML = "Hello HTML from the JavaScript function";
}
