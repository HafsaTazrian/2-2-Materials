package sales;

import com.gm.sales.*;//Import all the classes of this package

public class Sales {
    
    public static void main(String[] args) {
        //create several Product objects
        Product p1 = new Product("T-Shirt",55.00);
        Product p2 = new Product("Cap",30.00);
        Product p3 = new Product("Jeans",150.00);
        
        //create an Order object
        Order order1 = new Order();
        
        //Add products to Order 1
        order1.addProduct(p1);
        order1.addProduct(p2);
        order1.addProduct(p3);
        
        //Print the first order
        order1.showOrder();
        
        //Create a second order
        Order order2 = new Order();
        
        //Create new products
        Product p4 = new Product("Shoes", 100);
        Product p5 = new Product("Shirt", 50);
        
        //Add products to order 2
        order2.addProduct(p1);
        order2.addProduct(p4);
        order2.addProduct(p5);
        order2.addProduct(p3);
        
        //Print the order 2
        System.out.println("");
        order2.showOrder();
    }
}