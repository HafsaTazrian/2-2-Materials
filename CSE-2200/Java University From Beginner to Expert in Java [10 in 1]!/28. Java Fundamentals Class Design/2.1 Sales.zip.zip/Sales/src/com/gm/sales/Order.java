package com.gm.sales;

public class Order {
    
    private final int idOrder;
    //Declare the products array
    private final Product products[];
    private static int ordersCounter;
    private int productsCounter;
    //define the maximum elements of the array
    private static final int MAX_PRODUCTS = 10;

    public Order() {
        this.idOrder = ++ordersCounter;
        //Instanciate the array of products
        products = new Product[MAX_PRODUCTS];
    }

    public void addProduct(Product product) {
        //Add the new products if it is possible
        if (productsCounter < MAX_PRODUCTS) {
            //Add the new product and increment the productsCounter
            products[productsCounter++] = product;
        }
        else{
            System.out.println("The maximum of products has been exceeded:: " + MAX_PRODUCTS);
        }
    }

    public double calculateTotal() {
        double total = 0;
        for (int i = 0; i < productsCounter; i++) {
            total += products[i].getPrice();
        }
        return total;
    }

    public void showOrder() {
        System.out.println("Order #:" + idOrder);
        System.out.println("Total of this order: $" + calculateTotal());
        System.out.println("Productos in the order: " + productsCounter);
        for (int i = 0; i < productsCounter; i++) {
            System.out.println(products[i]);
        }
    }
}