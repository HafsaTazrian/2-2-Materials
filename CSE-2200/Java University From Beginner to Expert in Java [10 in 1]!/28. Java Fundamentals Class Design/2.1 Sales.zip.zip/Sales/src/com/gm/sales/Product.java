package com.gm.sales;

public class Product {
    
    private int idProduct;
    private String name;
    private double price;
    private static int productsCounter;

    //Empty constructor
    private Product() {
        //Assign the idProduct that is unique to every created object
        this.idProduct = ++productsCounter;
    }

    //Overloaded constructor with 2 arguments
    public Product(String name, double price) {
        //Call the private constructor to assign the idProduct value
        this();
        this.name = name;
        this.price = price;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Product{" + "idProduct= " + idProduct + ", name=" + name + ", price=" + price + '}';
    }
}