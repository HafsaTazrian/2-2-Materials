package operations;

public class Arithmetic {

    //Attributes of the class
    int a;
    int b;

    //Empty Constructor
    //Remember that if we add a different constructor to the empty one
    //this constructor is not created anymore and we must create it if we need it
    Arithmetic() {
    }

    //Constructor with 2 arguments
    Arithmetic(int a, int b) {
        //Use of this operator
        this.a = a;
        this.b = b;
    }

    //This method takes the attributes of the class to do the addition
    int addition() {
        return a + b;
    }

    //Substraction method
    int substraction() {
        return a - b;
    }

    //Multiplication method
    int multiplication() {
        return a * b;
    }

    //Division method
    int division() {
        return a / b;
    }
}
