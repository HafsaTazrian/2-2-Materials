package competitors;

public interface Instrument {
    void play();
}
