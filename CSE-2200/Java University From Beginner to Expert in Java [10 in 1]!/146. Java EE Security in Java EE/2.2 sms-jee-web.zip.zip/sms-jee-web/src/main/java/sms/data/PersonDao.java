package sms.data;

import java.util.List;
import sms.domain.Person;

public interface PersonDao {

  public List<Person> findAllPeople();

  public Person findPerson(Person person);

  public void insertPerson(Person person);

  public void updatePerson(Person person);

  public void deletePerson(Person person);
}
