package sms.service;

import java.util.List;
import javax.ejb.Local;
import sms.domain.Person;

@Local
public interface PersonService {

    public List<Person> listPeople();

    public Person findPerson(Person person);

    public void addPerson(Person person);

    public void modifyPerson(Person person);

    public void deletePerson(Person person);
}
