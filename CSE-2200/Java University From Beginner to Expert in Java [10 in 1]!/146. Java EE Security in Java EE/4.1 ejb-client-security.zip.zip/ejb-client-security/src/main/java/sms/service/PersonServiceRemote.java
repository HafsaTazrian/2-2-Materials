package sms.service;

import java.util.List;
import sms.domain.Person;

public interface PersonServiceRemote {

    public List<Person> listPeople();

    public Person findPerson(Person person);

    public void addPerson(Person person);

    public void modifyPerson(Person person);

    public void deletePerson(Person person);
}
