package test;

import com.sun.enterprise.security.ee.auth.login.ProgrammaticLogin;
import java.util.List;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import sms.domain.Person;
import sms.service.PersonServiceRemote;

public class ClientPersonService {

    public static void main(String[] args) {

        System.out.println("Initiating EJB call from the client\n");

        String authFile = "login.conf";
        System.setProperty("java.security.auth.login.config", authFile);
        ProgrammaticLogin programmaticLogin = new ProgrammaticLogin();
        programmaticLogin.login("admin", "admin".toCharArray());

        try {
            Context jndi = new InitialContext();
            PersonServiceRemote personService = (PersonServiceRemote) jndi.lookup("java:global/sms-jee-web/PersonServiceImpl!sms.service.PersonServiceRemote");

            List<Person> people = personService.listPeople();

            for (Person person : people) {
                System.out.println(person);
            }
            System.out.println("\nEnd call to the EJB from the client");
        } catch (NamingException e) {
            e.printStackTrace(System.out);
        }
    }
}