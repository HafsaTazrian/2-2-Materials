package test;

import java.util.List;
import domain.Person;
import javax.ws.rs.client.*;
import javax.ws.rs.core.*;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;

public class TestPersonServiceRS {

    //Variables that we will use
    private static final String URL_BASE = "http://localhost:8080/sms-jee-web/webservice";
    private static Client client;
    private static WebTarget webTarget;
    private static Person person;
    private static List<Person> people;
    private static Invocation.Builder invocationBuilder;
    private static Response response;

    public static void main(String[] args) {

         HttpAuthenticationFeature feature = HttpAuthenticationFeature.basicBuilder()
                .nonPreemptive()
                .credentials("admin", "admin")
                .build();

        ClientConfig clientConfig = new ClientConfig();
        clientConfig.register(feature);

        client = ClientBuilder.newClient(clientConfig);
        
        //Read a person (get method)
        webTarget = client.target(URL_BASE).path("/people");
        //We provide a valid idPerson
        person = webTarget.path("/1").request(MediaType.APPLICATION_XML).get(Person.class);
        System.out.println("recovered Person: " + person);

        //Read all people (get method with readEntity of type List <>)
        people = webTarget.request(MediaType.APPLICATION_XML).get(Response.class).readEntity(new GenericType<List<Person>>() {});
        System.out.println("\nRecovered people:");
        printPeople(people);

        //Add a person (post method)     
        Person newPerson = new Person();
        newPerson.setName("Ana");
        invocationBuilder = webTarget.request(MediaType.APPLICATION_XML);
        response = invocationBuilder.post(Entity.entity(newPerson, MediaType.APPLICATION_XML));

        System.out.println("");
        System.out.println("add response status:" + response.getStatus());
        //We retrieve the newly added person and then modify it and finally eliminate it
        Person addedPerson = response.readEntity(Person.class);
        System.out.println("Person added: " + addedPerson);

        //Modify a person (put method)
        //person previously recovered
        Person modifiedPerson = addedPerson;
        modifiedPerson.setName("Ana Skelleton");
        String pathId = "/" + modifiedPerson.getIdPerson();
        invocationBuilder = webTarget.path(pathId).request(MediaType.APPLICATION_XML);
        response = invocationBuilder.put(Entity.entity(modifiedPerson, MediaType.APPLICATION_XML));

        System.out.println("");
        System.out.println("modify response status:" + response.getStatus());
        System.out.println("Modified person:" + response.readEntity(Person.class));

        //Delete a person      
        // person previously recovered       
        Person deletePerson = addedPerson;
        String pathDeleteId = "/" + deletePerson.getIdPerson();
        invocationBuilder = webTarget.path(pathDeleteId).request(MediaType.APPLICATION_XML);
        response = invocationBuilder.delete();

        System.out.println("");
        System.out.println("remove response status : " + response.getStatus());
        System.out.println("Person Removed: " + deletePerson);
    }

    private static void printPeople(List<Person> persons) {
        for (Person person : persons) {
            System.out.println("Person:" + person);
        }
    }
}
