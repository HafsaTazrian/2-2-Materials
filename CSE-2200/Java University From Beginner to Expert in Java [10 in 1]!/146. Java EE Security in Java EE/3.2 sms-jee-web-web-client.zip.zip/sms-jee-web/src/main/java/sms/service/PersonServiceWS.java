package sms.service;

import java.util.List;
import javax.jws.WebMethod;
import javax.jws.WebService;
import sms.domain.Person;

@WebService
public interface PersonServiceWS {

    @WebMethod
    public List<Person> listPeople();
}
