package test;

public class FinalExample {
    
    public static void main(String[] args) {
        //Sends an error, you cannot modify the value of a final variable
        //FinalClass.PRIMITIVE_VAR = 15;
        
        //Sends an error, you cannot modify the reference or value of a final variable
        //FinalClass.PERSON_OBJECT = new Persona();
        
         System.out.println("Person name: " + FinalClass.PERSON_OBJECT.getName());
        
        //But it is possible to modify the state of the object         
        //referenced by the final variable
        FinalClass.PERSON_OBJECT.setName("John");
        
        System.out.println("Person name: " + FinalClass.PERSON_OBJECT.getName());
    }   
}
