package test;

public final class FinalClass {
    
    //Variables marked as final
    public static final int PRIMITIVE_VAR = 10;
    
    public static final Person PERSON_OBJECT = new Person();     

    //final method, we will study the overwriting topic in another lesson
    public final void metodoFinal(){
    }      
}

//Sends an error: Cannot inherit from a final class
//class ChildClass extends FinalClass{ }
