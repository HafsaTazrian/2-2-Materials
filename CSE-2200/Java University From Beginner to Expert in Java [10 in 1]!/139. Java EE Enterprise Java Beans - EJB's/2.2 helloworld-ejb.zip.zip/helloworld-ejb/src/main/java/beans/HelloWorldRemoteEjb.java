package beans;

import javax.ejb.Remote;

@Remote
public interface HelloWorldRemoteEjb {
     public int add(int a, int b);
}
