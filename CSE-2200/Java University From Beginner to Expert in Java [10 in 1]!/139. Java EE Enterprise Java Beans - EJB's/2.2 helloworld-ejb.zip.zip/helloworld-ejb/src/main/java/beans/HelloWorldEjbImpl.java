package beans;

import javax.ejb.Stateless;

@Stateless
public class HelloWorldEjbImpl implements HelloWorldRemoteEjb{
    
    @Override
    public int add(int a, int b) {
        System.out.println("Executing add method on the server");
        return a + b;
    }
}