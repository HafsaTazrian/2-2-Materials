package test;

import beans.HelloWorldRemoteEjb;
import javax.naming.*;

public class TestHelloWorldEjb {

    public static void main(String[] args) {
        System.out.println("Initiating EJB call from the client\n");
        try {
            Context jndi = new InitialContext();
            HelloWorldRemoteEjb helloWorldEjb = 
                    (HelloWorldRemoteEjb) jndi.lookup("java:global/helloworld-ejb/HelloWorldEjbImpl!beans.HelloWorldRemoteEjb");
            int result = helloWorldEjb.add(5, 3);
            System.out.println("EJB Result of adding 5 + 3 = " + result);
        } catch (NamingException e) {
            e.printStackTrace(System.out);
        }
    }
}
