package sms.client;

import java.util.*;
import javax.naming.*;
import sms.domain.Person;
import sms.service.PersonServiceRemote;

public class ClientPersonServiceWithIP {
    public static void main(String[] args) {
        System.out.println("Initiating EJB call from the client with IP\n");
        try {
            Properties props = new Properties();
            props.setProperty("java.naming.factory.initial", "com.sun.enterprise.naming.SerialInitContextFactory");
            props.setProperty("java.naming.factory.url.pkgs", "com.sun.enterprise.naming");
            props.setProperty("java.naming.factory.state", "com.sun.corba.ee.impl.presentation.rmi.JNDIStateFactoryImpl");
            // optional Default localhost. Here the IP of the server where Glassfish is changed
            props.setProperty("org.omg.CORBA.ORBInitialHost", "127.0.0.1");
            // optional Port by Default 3700. You only need to change if the port is not 3700.
            //props.setProperty("org.omg.CORBA.ORBInitialPort", "3700");
            Context jndi = new InitialContext(props);
            PersonServiceRemote personService = 
                 (PersonServiceRemote) jndi.lookup("java:global/sms-jee/PersonServiceImpl!sms.service.PersonServiceRemote");

            List<Person> persons = personService.listPeople();
            for (Person person : persons) {
                System.out.println(person);
            }
            System.out.println("\nEnd call to the EJB from the client with IP");
        } catch (NamingException e) {
            e.printStackTrace(System.out);
        }
    }
}
