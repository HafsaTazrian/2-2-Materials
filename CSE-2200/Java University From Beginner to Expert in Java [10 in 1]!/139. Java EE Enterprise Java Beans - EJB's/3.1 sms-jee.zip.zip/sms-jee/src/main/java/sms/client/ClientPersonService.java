package sms.client;

import java.util.List;
import javax.naming.*;
import sms.domain.Person;
import sms.service.PersonServiceRemote;

public class ClientPersonService {

    public static void main(String[] args) {

        System.out.println("Initiating EJB call from the client\n");
        try {
            Context jndi = new InitialContext();
            PersonServiceRemote personService = 
                       (PersonServiceRemote) 
                       jndi.lookup("java:global/sms-jee/PersonServiceImpl!sms.service.PersonServiceRemote");

            List<Person> people = personService.listPeople();

            for (Person person : people) {
                System.out.println(person);
            }
            System.out.println("\nEnd call to the EJB from the client");
        } catch (NamingException e) {
            e.printStackTrace(System.out);
        }
    }
}
