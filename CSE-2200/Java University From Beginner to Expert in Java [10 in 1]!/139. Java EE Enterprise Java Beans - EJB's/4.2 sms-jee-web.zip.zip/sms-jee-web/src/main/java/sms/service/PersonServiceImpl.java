package sms.service;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import sms.domain.Person;

@Stateless
public class PersonServiceImpl implements PersonServiceRemote, PersonService {

    @Override
    public List<Person> listPeople() {
        List<Person> people = new ArrayList<>();
        people.add(new Person(1, "John"));
        people.add(new Person(2, "Samantha"));
        return people;
    }

    @Override
    public Person findPerson(Person person) {
        return null;
    }

    @Override
    public void addPerson(Person person) {}

    @Override
    public void modifyPerson(Person person) {}

    @Override
    public void deletePerson(Person person) {}
}