package sms.web;

import java.io.IOException;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import sms.domain.Person;
import sms.service.PersonService;

@WebServlet("/people")
public class PersonServlet extends HttpServlet {

    @Inject
    PersonService personServiceLocalEjb;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Person> people = personServiceLocalEjb.listPeople();
        System.out.println("people:" + people);
        request.setAttribute("people", people);
        request.getRequestDispatcher("/listPeople.jsp").forward(request, response);
    }
}
