package mx.com.gm.datalayer;

import java.util.List;
import mx.com.gm.datalayer.domain.Person;

public interface PersonDao {
    
    void insertPerson(Person person);

    void updatePerson(Person person);

    void deletePerson(Person person);

    Person findPersonById(long idPerson);

    List<Person> findAllPeople();

    long peopleCounter();

}
