package mx.com.gm.actions;

import com.opensymphony.xwork2.ActionSupport;
import java.util.List;
import mx.com.gm.businesslayer.PersonService;
import mx.com.gm.datalayer.domain.Person;
import org.apache.logging.log4j.*;
import org.apache.struts2.convention.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

public class PersonAction extends ActionSupport {

    private Person person;
    
    private List<Person> people;

    @Autowired
    private PersonService personService;

    Logger log = LogManager.getLogger(PersonAction.class);

    @Action(value = "/list", results = {
        @Result(name = "people", location = "/WEB-INF/content/people.jsp")})
    public String list() {
        this.people = personService.listPeople();
        return "people";
    }

    @Action(value = "/addPerson", results = {
        @Result(name = "person", location = "/WEB-INF/content/person.jsp")})
    public String add() {
        //We create a new object of type person
        person = new Person();
        return "person";
    }

    @Action(value = "/editPerson", results = {
        @Result(name = "person", location = "/WEB-INF/content/person.jsp")})
    public String edit() {
        person = personService.findPeople(person);
        return "person";
    }

    @Action(value = "/deletePerson", results = {
        @Result(name = "success", location = "list", type = "redirect")})
    public String delete() {
        //We retrieve the person object, since we only have the idPerson
        log.info("Method to eliminate person before recovering:" + person);
        person = personService.findPeople(person);
        log.info("Method to eliminate person after recovering:" + person);
        personService.deletePerson(person);
        return SUCCESS;
    }

    //It is not enough to send to the JSP, but to the action of list
    //for that reason we redirected to the action of list
    @Action(value = "/savePerson", results = {
        @Result(name = "success", location = "list", type = "redirect")})
    public String save() {
        //We differentiate the action of adding or editing with the idPerson
        if (person.getIdPerson() == null) {
            personService.addPerson(person);
        } else {
            personService.modifyPerson(person);
        }
        return SUCCESS;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public List<Person> getPeople() {
        return people;
    }

    public void setPeople(List<Person> people) {
        this.people = people;
    }
}