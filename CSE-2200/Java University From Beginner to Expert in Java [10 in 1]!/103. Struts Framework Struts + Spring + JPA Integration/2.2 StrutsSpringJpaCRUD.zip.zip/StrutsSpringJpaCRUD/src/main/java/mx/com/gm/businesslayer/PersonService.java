package mx.com.gm.businesslayer;

import java.util.List;
import mx.com.gm.datalayer.domain.Person;

public interface PersonService {
    
    public List<Person> listPeople();

    public Person findPeople(Person person);

    public void addPerson(Person person);

    public void modifyPerson(Person person);

    public void deletePerson(Person person);
    
    public long countPeople();
}

