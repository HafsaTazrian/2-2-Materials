package mx.com.gm.datalayer;

import java.util.List;
import javax.persistence.*;
import mx.com.gm.datalayer.domain.Person;
import org.apache.logging.log4j.*;
import org.springframework.stereotype.Repository;

@Repository
public class PersonDaoImpl implements PersonDao {

    Logger log = LogManager.getRootLogger();

    @PersistenceContext
    private EntityManager em;

    @Override
    public void insertPerson(Person person) {
        // Insert new object
        em.persist(person);
    }

    @Override
    public void updatePerson(Person person) {
        // Update the object
        em.merge(person);
    }

    @Override
    public void deletePerson(Person person) {
         em.remove(em.merge(person));
    }

    @Override
    public Person findPersonById(long idPerson) {
        return em.find(Person.class, idPerson);
    }

    @Override
    public List<Person> findAllPeople() {
        String jpql = "SELECT p FROM Person p";
        Query query = em.createQuery(jpql);
        //Force to go directly to the database to refresh data
        query.setHint("javax.persistence.cache.storeMode", CacheStoreMode.REFRESH);
        List<Person> people = query.getResultList();
        log.info("list of people:" + people);
        return people;
    }

    @Override
    public long peopleCounter() {
        String query = "select count(p) from Person p";
        Query q = em.createQuery(query);
        long counter = (long) q.getSingleResult();
        log.info("people Counter: " + counter);
        return counter;
    }

}