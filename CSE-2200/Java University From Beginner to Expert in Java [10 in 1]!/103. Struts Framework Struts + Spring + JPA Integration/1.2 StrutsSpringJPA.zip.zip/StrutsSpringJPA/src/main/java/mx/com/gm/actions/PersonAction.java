package mx.com.gm.actions;

import com.opensymphony.xwork2.ActionSupport;
import java.util.List;
import mx.com.gm.businesslayer.PersonService;
import mx.com.gm.datalayer.domain.Person;
import org.apache.logging.log4j.*;
import org.springframework.beans.factory.annotation.Autowired;

public class PersonAction extends ActionSupport {

    private long peopleCounter;

    Logger log = LogManager.getLogger(PersonAction.class);

    @Autowired
    private PersonService personService;

    private List<Person> people;

    @Override
    public String execute() {
        this.people = personService.listPeople();
        this.peopleCounter = personService.countPeople();
        return SUCCESS;
    }

    public List<Person> getPeople() {
        return people;
    }

    public void setPeople(List<Person> people) {
        this.people = people;
    }

    public long getPeopleCounter() {
        return peopleCounter;
    }

    public void setPeopleCounter(long peopleCounter) {
        this.peopleCounter = peopleCounter;
    }
}