package web;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/Servlet")
public class Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // We create the variables to process the title and
            // the message of our website
            String title = null, message = null;
            //We detected the type of browser that made the request
            String browserType = request.getHeader("User-Agent");
            System.out.println("Type of Browser: " + browserType);

            // We verify the type of browser and customize
            // the message to send
            if (browserType != null && browserType.contains("Trident")) {
                title = "Internet Explorer Browser";
                message = "You are browsing with Internet Explorer";
            } else if (browserType != null && browserType.contains("Firefox")) {
                title = "Firefox Browser";
                message = "You are browsing with Firefox";
            } else if (browserType != null && browserType.contains("Chrome")) {
                title = "Chrome Browser";
                message = "You are browsing with Google Chrome";
            }

            out.println("<html>");
            out.println("<head>");
            out.println("<title>" + title + "</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Type of Browser</h1>");
            out.println("<br>");
            out.println(message);
            out.println("</body>");
            out.println("</html>");
        }
    }

}