package web;

import java.io.*;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ServletHeaders")
public class Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // We process the headers related to the
            // information of the request
            String httpMethod = request.getMethod();
            String uri = request.getRequestURI();

            out.println("<html>");
            out.println("<head>");
            out.println("<title>HTTP Request Headers</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>HTTP Request Headers</h1>");
            out.println("Http Method: " + httpMethod);
            out.println("<br>");
            out.println("requested URI: " + uri);
            out.println("<br>");

            //We process some headers that are part of the request
            out.println("<br>");
            out.println("Host: " + request.getHeader("Host"));
            out.println("<br>");
            out.println("Browser: " + request.getHeader("User-Agent"));

            //We process all the headers
            //these may vary depending on the browser used
            out.println("<br>");
            out.println("<br>");
            Enumeration headers = request.getHeaderNames();
            while (headers.hasMoreElements()) {
                String headerName = (String) headers.nextElement();
                out.println("<b>" + headerName + "</b>: ");
                out.println(request.getHeader(headerName));
                out.println("<br>");
            }
            out.println("</body>");
            out.println("</html>");

        }
    }

}