package web.actions;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.*;

public class LoginAction extends ActionSupport {

    private String user;
    private String password;

    Logger log = LogManager.getLogger(LoginAction.class);

    @Override
    public String execute() {
        log.info("The user is:" + this.user);
        log.info("The password is:" + this.password);
        return SUCCESS;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getTitle() {
        return getText("form.title");
    }

    public String getValue() {
        return getText("form.value");
    }

    public String getButton() {
        return getText("form.button");
    }
    
    public String getFormUser(){
        return getText("form.user");
    }
    public String getFormPassword(){
        return getText("form.password");
    }
    
}
