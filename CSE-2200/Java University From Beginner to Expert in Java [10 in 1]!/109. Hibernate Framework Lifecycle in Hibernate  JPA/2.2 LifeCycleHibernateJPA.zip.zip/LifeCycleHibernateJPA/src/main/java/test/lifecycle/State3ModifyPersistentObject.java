package test.lifecycle;

import javax.persistence.*;
import model.Address;

public class State3ModifyPersistentObject {

    public static void main(String[] args) {
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("HibernateJpaPU");
        EntityManager em = factory.createEntityManager();

        /**
         * Objective: Modify a persistent object (reattaching) Move from a
         * detached to persistent state
         */
        //We recover a persistent object
        Address address = null;
        try {
            em.getTransaction().begin();
            //Identifier to recover, you can also use merge to retrieve an object
            address = (Address) em.find(Address.class, 1);
            em.getTransaction().commit(); //hacemos flush
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace(System.out);
        }

        //We print the values of the recovered object
        //state detached
        System.out.println("Address recovered:" + address);

        //We modify the object outside of a transaction
        if (address != null) {
            address.setStreetName("new street");
        }

        //We return to save the object in a new transaction
        //We change the state from detached to persistent (reattaching)
        try {
            em.getTransaction().begin();
            em.merge(address);
            em.getTransaction().commit(); //we make flush
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace(System.out);
        } finally {
            if (em != null) {
                em.close();
            }
        }

        System.out.println("Modified address object:" + address);
        //The address object changes to detached status when closing session
    }
}
