package test.lifecycle;

import javax.persistence.*;
import model.Address;

public class State4ModifyObjectLongSession {

    public static void main(String[] args) {
        /*We use the JPA Persistence Unit */
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("HibernateJpaPU");
        EntityManager em = fabrica.createEntityManager();

        //We recover a persistent object
        Address address = null;

        try {
            em.getTransaction().begin();
            //Identifier to recover, you can also use merge to retrieve an object
            address = (Address) em.find(Address.class, 1);
            System.out.println("Address unmodified:" + address);
            //We modify the object in the same transaction
            address.setStreetNumber("555");
            em.getTransaction().commit(); //hacemos flush
        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace(System.out);
        } finally {
            if (em != null) {
                em.close();
            }
        }

        //We print the values (status detached)
        System.out.println("Address recovered:" + address);
    }

}