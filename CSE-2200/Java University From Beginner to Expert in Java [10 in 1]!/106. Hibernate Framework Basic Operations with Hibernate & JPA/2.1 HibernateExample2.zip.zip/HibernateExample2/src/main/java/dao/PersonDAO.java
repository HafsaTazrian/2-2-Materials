package dao;

import java.util.List;
import javax.persistence.*;
import domain.Person;
import org.apache.logging.log4j.*;

public class PersonDAO {

    Logger log = LogManager.getLogger(PersonDAO.class);

    protected EntityManager em;
    private EntityManagerFactory emf = null;

    public PersonDAO() {
        // use the persistence unit defined in the persistence.xml file
        emf = Persistence.createEntityManagerFactory("HibernatePU");
    }

    public void list() {
        // Query to be executed
        // We do not need to create a new transaction
        String hql = "SELECT p FROM Person p";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<Person> list = query.getResultList();
        for (Person p : list) {
            log.info(p);
        }
    }

    public void insert(Person person) {
        try {
            log.info("person to insert: " + person);
            em = getEntityManager();
            // We start a transaction
            em.getTransaction().begin();
            // We insert the new person
            em.persist(person);
            // We finish the transaction
            em.getTransaction().commit();
        } catch (Exception ex) {
            log.error("Error inserting the object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void update(Person person) {
        try {
            log.info("person to update: " + person);
            em = getEntityManager();
            // We start a transaction
            em.getTransaction().begin();
            // We update to the person object
            em.merge(person);
            // We finish the transaction
            em.getTransaction().commit();
        } catch (Exception ex) {
            log.error("Error updating the object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void delete(Person person) {
        try {
            log.info("person to delete: " + person);
            em = getEntityManager();
            // We start a transaction
            em.getTransaction().begin();
            // We synchronize and eliminate the person
            em.remove(em.merge(person));
            // We finish the transaction
            em.getTransaction().commit();
        } catch (Exception ex) {
            log.error("Error deleting the object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public Person findById(Person p) {
        log.info("person to find: " + p);
        em = getEntityManager();
        return em.find(Person.class, p.getIdPerson());
    }

    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

}
