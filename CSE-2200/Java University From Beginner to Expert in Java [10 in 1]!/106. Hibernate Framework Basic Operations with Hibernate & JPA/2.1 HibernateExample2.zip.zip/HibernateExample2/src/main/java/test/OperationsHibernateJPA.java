package test;

import java.util.Scanner;
import dao.PersonDAO;
import domain.Person;

public class OperationsHibernateJPA {

    public static void main(String args[]) {
        PersonDAO personDao = new PersonDAO();
        Person person = null;
        int option = -1;
        Scanner scanner = new Scanner(System.in);
        String idStr, name;

        // Press 0 to exit
        while (option != 0) {
            try {
                System.out.println(
                        "Choose an option:\n1.- List People"
                        + "\n2.- Find person by id "
                        + "\n3.- Add a person"
                        + "\n4.- Modify a person\n"
                        + "5.- Delete a person\n"
                        + "0.- Exit");

                option = Integer.parseInt(scanner.nextLine());

                switch (option) {
                    case 1:
                        System.out.println("\n1.List People***********");
                        personDao.list();;
                        break;
                    case 2:
                        System.out.println("\n2.Find by id***********");
                        System.out.println("Enter the id of the person to search:");
                        idStr = scanner.nextLine();
                        person = new Person();
                        person.setIdPerson(new Integer(idStr));
                        person = personDao.findById(person);
                        System.out.println("Object found:" + person);
                        break;
                    case 3:
                        System.out.println("\n3.Insert***********");
                        System.out.println("Enter the name of the person to add:");
                        name = scanner.nextLine();
                        person = new Person();
                        person.setName(name);
                        // We save the new object
                        personDao.insert(person);
                        break;
                    case 4:
                        System.out.println("\n4.Modify***********");
                        // First we look for the person to modify
                        System.out.println("Enter the id of the person to search:");
                        idStr = scanner.nextLine();
                        person = new Person();
                        person.setIdPerson(new Integer(idStr));
                        person = personDao.findById(person);
                        System.out.println("Enter the name of the person to be modified:");
                        name = scanner.nextLine();
                        // Modificamos algun valor
                        person.setName(name);
                        personDao.update(person);
                        break;
                    case 5:
                        System.out.println("\n5. Delete***********");
                        // First we look for the person to eliminate
                        System.out.println("Enter the id of the person to be deleted:");
                        idStr = scanner.nextLine();
                        person = new Person();
                        person.setIdPerson(new Integer(idStr));
                        person = personDao.findById(person);
                        // Eliminamos el objeto encontrado
                        personDao.delete(person);
                        break;
                    case 0:
                        System.out.println("See you soon!");
                        break;
                    default:
                        System.out.println("Option not recognized");
                        break;
                }
                System.out.println("\n");

            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}