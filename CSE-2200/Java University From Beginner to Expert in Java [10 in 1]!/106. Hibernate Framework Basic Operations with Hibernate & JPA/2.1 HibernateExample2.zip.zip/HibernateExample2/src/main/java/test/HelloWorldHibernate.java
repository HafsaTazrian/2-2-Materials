package test;

import domain.Person;
import java.util.List;
import javax.persistence.*;
import org.apache.logging.log4j.*;

public class HelloWorldHibernate {

    static Logger log = LogManager.getLogger(HelloWorldHibernate.class);

    public static void main(String[] args) {
        String hql = "SELECT p FROM Person p";
        EntityManagerFactory factory = Persistence.createEntityManagerFactory("HibernateExample1");
        EntityManager entityManager = factory.createEntityManager();
        Query query = entityManager.createQuery(hql);
        List<Person> list = query.getResultList();
        for (Person p : list) {
            log.info("Person:" + p);
        }
    }
}
