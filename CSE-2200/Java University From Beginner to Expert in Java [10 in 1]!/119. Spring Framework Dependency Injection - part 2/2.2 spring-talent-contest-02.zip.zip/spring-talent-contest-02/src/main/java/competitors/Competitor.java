package competitors;

public interface Competitor {

    public void execute() throws ExecutionException;
}
