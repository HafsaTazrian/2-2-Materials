package test;

import competitors.*;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.apache.logging.log4j.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestJUnitTalentContest {

    Logger log = LogManager.getRootLogger();
    private Competitor competitor1;
    private Competitor competitor2;

    @BeforeEach
    public void before() {
        log.info("Starting Spring Framework");
        ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
        log.info("getting the first Competitor");
        competitor1 = (Competitor) ctx.getBean("juggler");
        competitor2 = (Competitor) ctx.getBean("jugglerReciter");

    }

    @Test
    public void testJuggler() {
        log.info("Start executing Juggler");

        int ballsTest = 10;
        competitor1.execute();
        assertEquals(ballsTest, ((Juggler) competitor1).getBalls());

        log.info("Finish executing Juggler");

        log.info("Start executing JugglerReciter");

        ballsTest = 15;
        competitor2.execute();
        assertEquals(ballsTest, ((Juggler) competitor2).getBalls());

        log.info("Finish executing JugglerReciter");

    }
}
