package test;

import java.util.*;

public class SystemPropertiesTest {

    public static void main(String[] args) {

        Properties properties = System.getProperties();
        Enumeration propertiesEnum = properties.propertyNames();
        while (propertiesEnum.hasMoreElements()) {
            String propertyName = (String) propertiesEnum.nextElement();
            String propertyValue = properties.getProperty(propertyName);
            System.out.println("Key:" + propertyName + ", value=" + propertyValue);
        }
    }
}    
