package web.actions;

import com.opensymphony.xwork2.ActionSupport;
import org.apache.logging.log4j.*;

public class ShowPersonAction extends ActionSupport {

    private String name;

    Logger log = LogManager.getLogger(ShowPersonAction.class);

    @Override
    public String execute() {
        log.info("The name is:" + this.name);
        return SUCCESS;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
