package test;

import java.util.*;
import javax.persistence.*;
import javax.persistence.criteria.*;
import model.*;

public class TestCriteriaApiHibernateJPA {

    public static void main(String[] args) {
        EntityManagerFactory fabrica = Persistence.createEntityManagerFactory("HibernateJpaPU");
        EntityManager em = fabrica.createEntityManager();

        //Help variables
        CriteriaBuilder cb = em.getCriteriaBuilder();
        List<Student> students = null;
        Student student = null;

        // Query 1
        // Select all Students
        //JPQL equivalent:SELECT a FROM Student a
        System.out.println("\nQuery 1");
        //The criteria query object is created
        CriteriaQuery<Student> q1 = cb.createQuery(Student.class);
        //Set the root of the query
        q1.from(Student.class);
        //The query is executed
        students = em.createQuery(q1).getResultList();
        //We print the students
        printStudents(students);
        
        // Query2
        // Select the Student with id = 1
        System.out.println("\nQuery 2");
        CriteriaQuery<Student> q2 = cb.createQuery(Student.class);
        Root<Student> c2 = q2.from(Student.class);
        ParameterExpression<Integer> pId = cb.parameter(Integer.class);
        q2.select(c2).where(cb.equal(c2.get("idStudent"), pId));
        //execute the query
        TypedQuery<Student> query = em.createQuery(q2);
        //set the value of the parameter
        query.setParameter(pId, 1);
        student = query.getSingleResult();
        System.out.println(student);
        
        // Query 3
        // Select the student with name
        System.out.println("\nQuery 3");
        CriteriaQuery<Student> q3 = cb.createQuery(Student.class);
        Root<Student> c3 = q3.from(Student.class);
        ParameterExpression<String> pNombre = cb.parameter(String.class);
        q3.select(c3).where(cb.equal(c3.get("name"), pNombre));
        //execute the query
        TypedQuery<Student> query3 = em.createQuery(q3);
        //set the value of the parameter
        query3.setParameter(pNombre, "Charly");
        students = query3.getResultList();
        printStudents(students);
        
        // Query 4
        // Select students restricting by the idStudent
        System.out.println("\nQuery 4");
        CriteriaQuery<Student> qb4 = cb.createQuery(Student.class);
        Root<Student> c4 = qb4.from(Student.class);
        qb4.where(c4.get("idStudent").in(cb.parameter(Collection.class)));

        TypedQuery<Student> q4 = em.createQuery(qb4);
        Integer[] idStudents = {1,2};//place valid id's
        for (ParameterExpression parameter : qb4.getParameters()) {
            q4.setParameter(parameter, Arrays.asList( idStudents ));
        }
        students = q4.getResultList();
        printStudents(students);
        
        // Query 5
        // Get the students whose name is not null
        System.out.println("\nQuery 5");
        CriteriaQuery<Student> qb5 = cb.createQuery(Student.class);
        Root<Student> c5 = qb5.from(Student.class);
        qb5.select(c5).where(cb.isNotNull(c5.get("name")));
        //Ejecutamos el query
        TypedQuery<Student> q5 = em.createQuery(qb5);
        students = q5.getResultList();
        printStudents(students);
        
        //Query 6
        System.out.println("\nQuery 6");
        //Get the students whose name starts with an "e"
        CriteriaQuery<Student> qb6 = cb.createQuery(Student.class);
        Root<Student> c6 = qb6.from(Student.class);
        Expression<String> path = c6.get("name");
        Expression<String> upperCase = cb.upper(path);
        String stringToSearch = "" + "e".toUpperCase() +"%";
        Predicate predicate = cb.like(upperCase, stringToSearch);
        qb6.where(cb.and(predicate));
        students = em.createQuery(qb6.select(c6)).getResultList();
        printStudents(students);
        
        //Query 7
        //Get the students whose name contains "a" with ignoreCase
        System.out.println("\nQuery 7");
        CriteriaQuery<Student> qb7 = cb.createQuery(Student.class);
        Root<Student> c7 = qb7.from(Student.class);
        String stringToSearch2 = "%" + "a".toUpperCase() + "%";
        qb7.where(cb.like(cb.upper(c7.get("name")), stringToSearch2));  
        students = em.createQuery(qb7).getResultList();
        printStudents(students);
        
        //Query 8
        //Get the students by adding several restrictions
        //they are added with 'and' by default
        System.out.println("\nQuery 8");
        CriteriaQuery<Student> qb8 = cb.createQuery(Student.class);
        Root<Student> c8 = qb8.from(Student.class);
        //We create the restrictions
        Predicate[] restrictions = new Predicate[]{
            cb.equal(c8.get("name"), "Charly"),
            cb.isNotNull(c8.get("version"))
        };
        //We add the restrictions
        qb8.where(cb.and(restrictions));
        //We execute the query
        students = em.createQuery(qb8).getResultList();
        printStudents(students);
        
        //Query 9
        //Get the students by adding several restrictions
        //they are added with 'or'
        System.out.println("\nQuery 9");
        CriteriaQuery<Student> qb9 = cb.createQuery(Student.class);
        Root<Student> c9 = qb9.from(Student.class);
        //We create the restrictions
        Predicate[] restrictions2 = new Predicate[]{
            cb.equal(c9.get("name"), "Charly"),
            cb.isNotNull(c9.get("version"))
        };
        //We add the restrictions
        qb9.where(cb.or(restrictions2));
        //We execute the query
        students = em.createQuery(qb9).getResultList();
        printStudents(students);

        //Query 10
        //Get the students whose name is not null
        //adding ordering by name asc and version desc
        System.out.println("\nQuery 10");
        CriteriaQuery<Student> qb10 = cb.createQuery(Student.class);
        Root<Student> c10 = qb10.from(Student.class);
        //We create the restrictions
        Predicate[] restrictions3 = new Predicate[]{
            cb.equal(c10.get("name"), "Charly"),
            cb.isNotNull(c10.get("version"))
        };
        //We add the restrictions
        qb10.where(cb.or(restrictions3));
        //We add order
        qb10.orderBy(cb.asc(c10.get("name")), cb.desc(c10.get("version")));
        //We execute the query
        students = em.createQuery(qb10).getResultList();
        printStudents(students);

    }

    private static void printStudents(List<Student> students) {
        for (Student s : students) {
            System.out.println(s);
        }
    }
}