package dao;

import static dao.GenericDAO.em;
import java.util.List;
import javax.persistence.Query;
import model.User;

public class UserDAO extends GenericDAO{
    
      public List<User> list() {
        String hql = "SELECT u FROM User u";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<User> list = query.getResultList();
        for(User u : list){
            System.out.println(u);
        }
        return list; 
    }

    public void insert(User user) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(user);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error inserting object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void update(User user) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(user);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error updating object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void delete(User user) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.remove(em.merge(user));
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error removing object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public Object findById(User user) {
        em = getEntityManager();
        return em.find(User.class, user.getIdUser());
    }
}