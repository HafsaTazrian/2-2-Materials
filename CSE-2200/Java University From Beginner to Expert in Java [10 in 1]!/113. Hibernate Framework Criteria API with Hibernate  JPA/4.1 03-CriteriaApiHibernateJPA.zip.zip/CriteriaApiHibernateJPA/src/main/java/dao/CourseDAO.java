package dao;

import static dao.GenericDAO.em;
import java.util.List;
import javax.persistence.Query;
import model.Course;

public class CourseDAO extends GenericDAO{
    
      public List<Course> list() {
        String hql = "SELECT c FROM Course c";
        em = getEntityManager();
        Query query = em.createQuery(hql);
        List<Course> list = query.getResultList();  
        for(Course c : list){
            System.out.println(c);
        }
        return list; 
    }

    public void insert(Course course) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(course);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error inserting object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void update(Course course) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(course);
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error updating object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public void delete(Course course) {
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.remove(em.merge(course));
            em.getTransaction().commit();
        } catch (Exception ex) {
            System.out.println("Error removing object:" + ex.getMessage());
        } finally {
            if (em != null) {
                em.close();
                em = null;
            }
        }
    }

    public Object findById(Course course) {
        em = getEntityManager();
        return em.find(Course.class, course.getIdCourse());
    }
}