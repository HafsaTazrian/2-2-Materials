package test;

public class ForLoopTest {
    public static void main(String[] args) {
        int limit = 10;
        for (int counter = 0; counter < limit; counter++) {
            System.out.println("counter = " + counter);
        }
    }
}