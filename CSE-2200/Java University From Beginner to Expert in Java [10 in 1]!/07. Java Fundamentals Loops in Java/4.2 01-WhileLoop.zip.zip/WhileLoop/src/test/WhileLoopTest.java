package test;

public class WhileLoopTest {

    public static void main(String[] args) {

        int counter = 0;
        int limit = 10;
        //Prints from 0 to 9 (10 elements)
        while (counter < limit) {
            System.out.println("counter = " + counter);
            counter++;
        }
    }
}
