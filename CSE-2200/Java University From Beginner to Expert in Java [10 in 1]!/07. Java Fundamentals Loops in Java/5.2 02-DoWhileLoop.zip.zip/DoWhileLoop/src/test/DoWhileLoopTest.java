package test;

public class DoWhileLoopTest {

    public static void main(String[] args) {
        int counter = 0;
        int limit = 10;
        do {
            //At least executed the first time 
            System.out.println("counter = " + counter);
            counter++;
        } while (counter < limit);
    }
}
