package web.actions;

import org.apache.logging.log4j.*;

public class GreetingsAction {
    
    Logger log = LogManager.getLogger(GreetingsAction.class);
    
    private String greetings;
    
    public String execute(){
        log.info("Struts 2 execute method");
        setGreetings("Hello from Struts2 using Conventions");
        return "success";
    }

    public String getGreetings() {
        return greetings;
    }

    public void setGreetings(String greetings) {
        this.greetings = greetings;
    }
}
