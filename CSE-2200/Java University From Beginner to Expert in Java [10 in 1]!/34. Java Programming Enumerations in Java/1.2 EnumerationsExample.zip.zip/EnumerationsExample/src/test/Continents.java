package test;

public enum Continents {
    AFRICA(53),
    EUROPE(46),
    ASIA(44),
    AMERICA(34),
    OCEANIA(14);

    // Attribute of each item in an enumeration
    private final int countries;

    // Constructor of each element of the enumeration
    Continents(int countries) {
        this.countries = countries;
    }

    public int getCountries() {
        return countries;
    }
}
