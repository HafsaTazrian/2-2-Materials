package test;

public class EnumerationTest {

    public static void main(String[] args) {

        // Values ​​of the enumeration
        System.out.println("Value 1:" + Days.MONDAY);

        //Do a test of the day used
        indicateDay(Days.MONDAY);

        //Use the country list
        System.out.println("Continent Number 4:" + Continents.AMERICA);
        System.out.println("Countries in America:" + Continents.AMERICA.getCountries());

        //Test the number of countries per continent
        System.out.println("");
        indicateCountries(Continents.AFRICA);

        //Print the continents
        System.out.println("");
        printContinents();
    }

    public static void indicateDay(Days days) {

        switch (days) {
            // We can use some constant value of the enumeration directly
            case MONDAY:
                System.out.println("First day of the week");
                break;
            case TUESDAY:
                System.out.println("Second day of the week");
                break;
            default:
                System.out.println("And so we continue with the other days");
        }
    }

    public static void indicateCountries(Continents continents) {

        switch (continents) {
            // We can use some constant value of the enumeration directly
            case AFRICA:
                System.out.println("No. Countries in: " + continents + ": " + continents.getCountries());
                break;
            default:
                System.out.println("And so we continue with the other continents");
        }
    }

    public static void printContinents() {
        // We use a forEach
        for (Continents c : Continents.values()) {
            System.out.println("Continent: " + c + " contains " + c.getCountries() + " countries.");
        }
    }
}
