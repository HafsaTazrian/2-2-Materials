package test;

public enum Days {
    // They are constant values, that is why they are capitalized
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY
}