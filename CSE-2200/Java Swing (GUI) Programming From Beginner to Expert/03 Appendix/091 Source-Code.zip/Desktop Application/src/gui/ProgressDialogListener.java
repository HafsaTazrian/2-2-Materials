package gui;

public interface ProgressDialogListener {
	public void progressDialogCancelled();
}
